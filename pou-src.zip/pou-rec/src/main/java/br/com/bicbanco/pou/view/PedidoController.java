package br.com.bicbanco.pou.view;

import java.util.LinkedList;
import java.util.List;
import java.util.logging.Logger;

import javax.faces.model.SelectItem;

import org.ajax4jsf.model.KeepAlive;

import com.ccb.br.pou.planos.client.PedidoClient;
import com.ccb.br.pou.planos.enums.StatusPedidoEnum;
import com.ccb.br.pou.planos.service.InformacoesPedidoService;
import com.ccb.br.pou.planos.to.InformacoesPedidoTO;
import com.ccb.br.pou.planos.to.PedidoFiltroTO;
import com.ccb.br.pou.planos.to.PedidoTO;

import br.com.bicbanco.bicbase.exceptions.ServiceException;
import br.com.bicbanco.bicbase.view.component.PaginatingDataModel;
import br.com.bicbanco.bicbase.view.controller.BaseController;

@KeepAlive
public class PedidoController extends BaseController {
	private static final long serialVersionUID = 1L;
	private static final String BUNDLE = "Pedido";
	private static final String PAGE_LIST = "PedidoFilterList";
	private static final String PAGE_DETAIL = "PesquisaPedidoDetail";
	private static final Logger logger = Logger.getLogger(PedidoController.class);
	private PaginatingDataModel<InformacoesPedidoTO, InformacoesPedidoService> scrollableTable;
	private Integer totalLinhas = new Integer(7);
	private PedidoFiltroTO pedidoFiltro;
	private PedidoTO pedido;
	private List<SelectItem> listStatusPedido;

	public PedidoController() {
	}

	public String init() {
		pedidoFiltro = new PedidoFiltroTO();
		populeStatusPedidoList();
		setPaginatingDataModel();

		return "PedidoFilterList";
	}

	public String getBundleName() {
		return "Pedido";
	}

	public String applyFilterList() throws ServiceException {
		return "PedidoFilterList";
	}

	public String viewDetail() throws ServiceException {
		PedidoClient client = new PedidoClient();

		pedido = client.obterPedido();

		System.out.println(pedido);

		return "PesquisaPedidoDetail";
	}

	public String returnToFilterList() {
		return "PedidoFilterList";
	}

	private void setPaginatingDataModel() {
    scrollableTable = new PaginatingDataModel();
    scrollableTable.setPaginatedExecution(new PedidoController.1(this));
  }

	public void populeStatusPedidoList() {
		List<SelectItem> list = new LinkedList();
		list.add(new SelectItem("", "[ SELECIONE ]"));
		for (StatusPedidoEnum tipo : StatusPedidoEnum.values()) {
			list.add(new SelectItem(tipo.getCodigo(), tipo.getLabel()));
		}
		listStatusPedido = list;
	}

	public PaginatingDataModel<InformacoesPedidoTO, InformacoesPedidoService> getScrollableTable() {
		return scrollableTable;
	}

	public Integer getTotalLinhas() {
		return totalLinhas;
	}

	public void setTotalLinhas(Integer totalLinhas) {
		this.totalLinhas = totalLinhas;
	}

	public PedidoFiltroTO getPedidoFiltro() {
		return pedidoFiltro;
	}

	public void setPedidoFiltro(PedidoFiltroTO pedidoFiltro) {
		this.pedidoFiltro = pedidoFiltro;
	}

	public List<SelectItem> getListStatusPedido() {
		return listStatusPedido;
	}

	public void setListStatusPedido(List<SelectItem> listStatusPedido) {
		this.listStatusPedido = listStatusPedido;
	}

	public PedidoTO getPedido() {
		return pedido;
	}

	public void setPedido(PedidoTO pedido) {
		this.pedido = pedido;
	}
}