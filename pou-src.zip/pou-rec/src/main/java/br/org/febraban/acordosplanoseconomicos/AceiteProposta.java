/**
 * AceiteProposta.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf031428.03 v72314182347
 */

package br.org.febraban.acordosplanoseconomicos;

public class AceiteProposta  {
    private java.lang.String guidPedido;
    private java.lang.String identificadorProposta;
    private java.lang.String identificadorPropostaBanco;
    private java.lang.String data;
    private br.org.febraban.acordosplanoseconomicos.AceitePropostaEnum aceite;
    private java.lang.String motivoRecusa;

    public AceiteProposta() {
    }

    public java.lang.String getGuidPedido() {
        return guidPedido;
    }

    public void setGuidPedido(java.lang.String guidPedido) {
        this.guidPedido = guidPedido;
    }

    public java.lang.String getIdentificadorProposta() {
        return identificadorProposta;
    }

    public void setIdentificadorProposta(java.lang.String identificadorProposta) {
        this.identificadorProposta = identificadorProposta;
    }

    public java.lang.String getIdentificadorPropostaBanco() {
        return identificadorPropostaBanco;
    }

    public void setIdentificadorPropostaBanco(java.lang.String identificadorPropostaBanco) {
        this.identificadorPropostaBanco = identificadorPropostaBanco;
    }

    public java.lang.String getData() {
        return data;
    }

    public void setData(java.lang.String data) {
        this.data = data;
    }

    public br.org.febraban.acordosplanoseconomicos.AceitePropostaEnum getAceite() {
        return aceite;
    }

    public void setAceite(br.org.febraban.acordosplanoseconomicos.AceitePropostaEnum aceite) {
        this.aceite = aceite;
    }

    public java.lang.String getMotivoRecusa() {
        return motivoRecusa;
    }

    public void setMotivoRecusa(java.lang.String motivoRecusa) {
        this.motivoRecusa = motivoRecusa;
    }

}
