/**
 * AcordoPlanoEconomicosService.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf031428.03 v72314182347
 */

package br.org.febraban.acordosplanoseconomicos;

public interface AcordoPlanoEconomicosService extends javax.xml.rpc.Service {
    public br.org.febraban.acordosplanoseconomicos.IDominioService getDominio() throws javax.xml.rpc.ServiceException;

    public java.lang.String getDominioAddress();

    public br.org.febraban.acordosplanoseconomicos.IDominioService getDominio(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
    public br.org.febraban.acordosplanoseconomicos.IPedidoService getPedido() throws javax.xml.rpc.ServiceException;

    public java.lang.String getPedidoAddress();

    public br.org.febraban.acordosplanoseconomicos.IPedidoService getPedido(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
    public br.org.febraban.acordosplanoseconomicos.IDocumentoService getDocumento() throws javax.xml.rpc.ServiceException;

    public java.lang.String getDocumentoAddress();

    public br.org.febraban.acordosplanoseconomicos.IDocumentoService getDocumento(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
    public br.org.febraban.acordosplanoseconomicos.IAcordoService getAcordo() throws javax.xml.rpc.ServiceException;

    public java.lang.String getAcordoAddress();

    public br.org.febraban.acordosplanoseconomicos.IAcordoService getAcordo(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
