/**
 * AcordoPlanoEconomicosServiceInformation.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf031428.03 v72314182347
 */

package br.org.febraban.acordosplanoseconomicos;

public class AcordoPlanoEconomicosServiceInformation implements com.ibm.ws.webservices.multiprotocol.ServiceInformation {

    private static java.util.Map operationDescriptions;
    private static java.util.Map typeMappings;

    static {
         initOperationDescriptions();
         initTypeMappings();
    }

    private static void initOperationDescriptions() { 
        operationDescriptions = new java.util.HashMap();

        java.util.Map inner0 = new java.util.HashMap();

        java.util.List list0 = new java.util.ArrayList();
        inner0.put("confirmarRecebimentoArquivo", list0);

        com.ibm.ws.webservices.engine.description.OperationDesc confirmarRecebimentoArquivo0Op = _confirmarRecebimentoArquivo0Op();
        list0.add(confirmarRecebimentoArquivo0Op);

        java.util.List list1 = new java.util.ArrayList();
        inner0.put("obterArquivo", list1);

        com.ibm.ws.webservices.engine.description.OperationDesc obterArquivo1Op = _obterArquivo1Op();
        list1.add(obterArquivo1Op);

        java.util.List list2 = new java.util.ArrayList();
        inner0.put("obterDocumento", list2);

        com.ibm.ws.webservices.engine.description.OperationDesc obterDocumento2Op = _obterDocumento2Op();
        list2.add(obterDocumento2Op);

        operationDescriptions.put("documento",inner0);
        java.util.Map inner1 = new java.util.HashMap();

        java.util.List list3 = new java.util.ArrayList();
        inner1.put("obterDominio", list3);

        com.ibm.ws.webservices.engine.description.OperationDesc obterDominio3Op = _obterDominio3Op();
        list3.add(obterDominio3Op);

        operationDescriptions.put("dominio",inner1);
        java.util.Map inner2 = new java.util.HashMap();

        java.util.List list4 = new java.util.ArrayList();
        inner2.put("confirmarRecebimentoPedido", list4);

        com.ibm.ws.webservices.engine.description.OperationDesc confirmarRecebimentoPedido4Op = _confirmarRecebimentoPedido4Op();
        list4.add(confirmarRecebimentoPedido4Op);

        java.util.List list5 = new java.util.ArrayList();
        inner2.put("obterPedido", list5);

        com.ibm.ws.webservices.engine.description.OperationDesc obterPedido5Op = _obterPedido5Op();
        list5.add(obterPedido5Op);

        operationDescriptions.put("pedido",inner2);
        java.util.Map inner3 = new java.util.HashMap();

        java.util.List list6 = new java.util.ArrayList();
        inner3.put("cadastrarResultadoAnalisePedido", list6);

        com.ibm.ws.webservices.engine.description.OperationDesc cadastrarResultadoAnalisePedido6Op = _cadastrarResultadoAnalisePedido6Op();
        list6.add(cadastrarResultadoAnalisePedido6Op);

        java.util.List list7 = new java.util.ArrayList();
        inner3.put("informarPagamento", list7);

        com.ibm.ws.webservices.engine.description.OperationDesc informarPagamento7Op = _informarPagamento7Op();
        list7.add(informarPagamento7Op);

        java.util.List list8 = new java.util.ArrayList();
        inner3.put("obterRespostaProposta", list8);

        com.ibm.ws.webservices.engine.description.OperationDesc obterRespostaProposta8Op = _obterRespostaProposta8Op();
        list8.add(obterRespostaProposta8Op);

        operationDescriptions.put("acordo",inner3);
        operationDescriptions = java.util.Collections.unmodifiableMap(operationDescriptions);
    }

    private static com.ibm.ws.webservices.engine.description.OperationDesc _confirmarRecebimentoArquivo0Op() {
        com.ibm.ws.webservices.engine.description.OperationDesc confirmarRecebimentoArquivo0Op = null;
        com.ibm.ws.webservices.engine.description.ParameterDesc[]  _params0 = new com.ibm.ws.webservices.engine.description.ParameterDesc[] {
         new com.ibm.ws.webservices.engine.description.ParameterDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "requisicao"), com.ibm.ws.webservices.engine.description.ParameterDesc.IN, com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/documentos/requisicoes", "RequisicaoConfirmacaoRecebimentoArquivo"), br.org.febraban.acordosplanoseconomicos.RequisicaoConfirmacaoRecebimentoArquivo.class, false, false, false, true, true, false), 
          };
        _params0[0].setOption("partQNameString","{http://acordosplanoseconomicos.febraban.org.br/contratos/documentos/requisicoes}RequisicaoConfirmacaoRecebimentoArquivo");
        _params0[0].setOption("inputPosition","0");
        _params0[0].setOption("partName","RequisicaoConfirmacaoRecebimentoArquivo");
        com.ibm.ws.webservices.engine.description.ParameterDesc  _returnDesc0 = new com.ibm.ws.webservices.engine.description.ParameterDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "ConfirmarRecebimentoArquivoResult"), com.ibm.ws.webservices.engine.description.ParameterDesc.OUT, com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/documentos/respostas", "ArrayOfRespostaOperacaoConfirmarRecebimentoArquivo"), br.org.febraban.acordosplanoseconomicos.RespostaOperacaoConfirmarRecebimentoArquivo[].class, true, false, false, true, true, false); 
        _returnDesc0.setOption("partQNameString","{http://acordosplanoseconomicos.febraban.org.br/contratos/documentos/respostas}ArrayOfRespostaOperacaoConfirmarRecebimentoArquivo");
        _returnDesc0.setOption("outputPosition","0");
        _returnDesc0.setOption("partName","ArrayOfRespostaOperacaoConfirmarRecebimentoArquivo");
        com.ibm.ws.webservices.engine.description.FaultDesc[]  _faults0 = new com.ibm.ws.webservices.engine.description.FaultDesc[] {
          };
        confirmarRecebimentoArquivo0Op = new com.ibm.ws.webservices.engine.description.OperationDesc("confirmarRecebimentoArquivo", com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "ConfirmarRecebimentoArquivo"), _params0, _returnDesc0, _faults0, null);
        confirmarRecebimentoArquivo0Op.setOption("buildNum","cf031428.03");
        confirmarRecebimentoArquivo0Op.setOption("ResponseNamespace","http://acordosplanoseconomicos.febraban.org.br");
        confirmarRecebimentoArquivo0Op.setOption("targetNamespace","http://acordosplanoseconomicos.febraban.org.br");
        confirmarRecebimentoArquivo0Op.setOption("outputMessageQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "IDocumentoService_ConfirmarRecebimentoArquivo_OutputMessage"));
        confirmarRecebimentoArquivo0Op.setOption("inputWSAAction","http://acordosplanoseconomicos.febraban.org.br/IDocumentoService/ConfirmarRecebimentoArquivo");
        confirmarRecebimentoArquivo0Op.setOption("portTypeQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "IDocumentoService"));
        confirmarRecebimentoArquivo0Op.setOption("outputWSAAction","http://acordosplanoseconomicos.febraban.org.br/IDocumentoService/ConfirmarRecebimentoArquivoResponse");
        confirmarRecebimentoArquivo0Op.setOption("ServiceQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "AcordoPlanoEconomicosService"));
        confirmarRecebimentoArquivo0Op.setOption("ResponseLocalPart","ConfirmarRecebimentoArquivoResponse");
        confirmarRecebimentoArquivo0Op.setOption("inputMessageQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "IDocumentoService_ConfirmarRecebimentoArquivo_InputMessage"));
        confirmarRecebimentoArquivo0Op.setStyle(com.ibm.ws.webservices.engine.enumtype.Style.WRAPPED);
        return confirmarRecebimentoArquivo0Op;

    }

    private static com.ibm.ws.webservices.engine.description.OperationDesc _obterArquivo1Op() {
        com.ibm.ws.webservices.engine.description.OperationDesc obterArquivo1Op = null;
        com.ibm.ws.webservices.engine.description.ParameterDesc[]  _params0 = new com.ibm.ws.webservices.engine.description.ParameterDesc[] {
         new com.ibm.ws.webservices.engine.description.ParameterDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "requisicao"), com.ibm.ws.webservices.engine.description.ParameterDesc.IN, com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/documentos/requisicoes", "IdentificadorArquivo"), br.org.febraban.acordosplanoseconomicos.IdentificadorArquivo.class, false, false, false, true, true, false), 
          };
        _params0[0].setOption("partQNameString","{http://acordosplanoseconomicos.febraban.org.br/contratos/documentos/requisicoes}IdentificadorArquivo");
        _params0[0].setOption("inputPosition","0");
        _params0[0].setOption("partName","IdentificadorArquivo");
        com.ibm.ws.webservices.engine.description.ParameterDesc  _returnDesc0 = new com.ibm.ws.webservices.engine.description.ParameterDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "ObterArquivoResult"), com.ibm.ws.webservices.engine.description.ParameterDesc.OUT, com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/documentos", "Arquivo"), br.org.febraban.acordosplanoseconomicos.Arquivo.class, true, false, false, true, true, false); 
        _returnDesc0.setOption("partQNameString","{http://acordosplanoseconomicos.febraban.org.br/contratos/documentos}Arquivo");
        _returnDesc0.setOption("outputPosition","0");
        _returnDesc0.setOption("partName","Arquivo");
        com.ibm.ws.webservices.engine.description.FaultDesc[]  _faults0 = new com.ibm.ws.webservices.engine.description.FaultDesc[] {
          };
        obterArquivo1Op = new com.ibm.ws.webservices.engine.description.OperationDesc("obterArquivo", com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "ObterArquivo"), _params0, _returnDesc0, _faults0, null);
        obterArquivo1Op.setOption("buildNum","cf031428.03");
        obterArquivo1Op.setOption("ResponseNamespace","http://acordosplanoseconomicos.febraban.org.br");
        obterArquivo1Op.setOption("targetNamespace","http://acordosplanoseconomicos.febraban.org.br");
        obterArquivo1Op.setOption("outputMessageQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "IDocumentoService_ObterArquivo_OutputMessage"));
        obterArquivo1Op.setOption("inputWSAAction","http://acordosplanoseconomicos.febraban.org.br/IDocumentoService/ObterArquivo");
        obterArquivo1Op.setOption("portTypeQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "IDocumentoService"));
        obterArquivo1Op.setOption("outputWSAAction","http://acordosplanoseconomicos.febraban.org.br/IDocumentoService/ObterArquivoResponse");
        obterArquivo1Op.setOption("ServiceQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "AcordoPlanoEconomicosService"));
        obterArquivo1Op.setOption("ResponseLocalPart","ObterArquivoResponse");
        obterArquivo1Op.setOption("inputMessageQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "IDocumentoService_ObterArquivo_InputMessage"));
        obterArquivo1Op.setStyle(com.ibm.ws.webservices.engine.enumtype.Style.WRAPPED);
        return obterArquivo1Op;

    }

    private static com.ibm.ws.webservices.engine.description.OperationDesc _obterDocumento2Op() {
        com.ibm.ws.webservices.engine.description.OperationDesc obterDocumento2Op = null;
        com.ibm.ws.webservices.engine.description.ParameterDesc[]  _params0 = new com.ibm.ws.webservices.engine.description.ParameterDesc[] {
         new com.ibm.ws.webservices.engine.description.ParameterDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "guidPedido"), com.ibm.ws.webservices.engine.description.ParameterDesc.IN, com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false, false, true, true, false), 
          };
        _params0[0].setOption("partQNameString","{http://www.w3.org/2001/XMLSchema}string");
        _params0[0].setOption("inputPosition","0");
        _params0[0].setOption("partName","string");
        com.ibm.ws.webservices.engine.description.ParameterDesc  _returnDesc0 = new com.ibm.ws.webservices.engine.description.ParameterDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "ObterDocumentoResult"), com.ibm.ws.webservices.engine.description.ParameterDesc.OUT, com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/documentos", "ArrayOfDocumento"), br.org.febraban.acordosplanoseconomicos.Documento[].class, true, false, false, true, true, false); 
        _returnDesc0.setOption("partQNameString","{http://acordosplanoseconomicos.febraban.org.br/contratos/documentos}ArrayOfDocumento");
        _returnDesc0.setOption("outputPosition","0");
        _returnDesc0.setOption("partName","ArrayOfDocumento");
        com.ibm.ws.webservices.engine.description.FaultDesc[]  _faults0 = new com.ibm.ws.webservices.engine.description.FaultDesc[] {
          };
        obterDocumento2Op = new com.ibm.ws.webservices.engine.description.OperationDesc("obterDocumento", com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "ObterDocumento"), _params0, _returnDesc0, _faults0, null);
        obterDocumento2Op.setOption("buildNum","cf031428.03");
        obterDocumento2Op.setOption("ResponseNamespace","http://acordosplanoseconomicos.febraban.org.br");
        obterDocumento2Op.setOption("targetNamespace","http://acordosplanoseconomicos.febraban.org.br");
        obterDocumento2Op.setOption("outputMessageQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "IDocumentoService_ObterDocumento_OutputMessage"));
        obterDocumento2Op.setOption("inputWSAAction","http://acordosplanoseconomicos.febraban.org.br/IDocumentoService/ObterDocumento");
        obterDocumento2Op.setOption("portTypeQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "IDocumentoService"));
        obterDocumento2Op.setOption("outputWSAAction","http://acordosplanoseconomicos.febraban.org.br/IDocumentoService/ObterDocumentoResponse");
        obterDocumento2Op.setOption("ServiceQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "AcordoPlanoEconomicosService"));
        obterDocumento2Op.setOption("ResponseLocalPart","ObterDocumentoResponse");
        obterDocumento2Op.setOption("inputMessageQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "IDocumentoService_ObterDocumento_InputMessage"));
        obterDocumento2Op.setStyle(com.ibm.ws.webservices.engine.enumtype.Style.WRAPPED);
        return obterDocumento2Op;

    }

    private static com.ibm.ws.webservices.engine.description.OperationDesc _obterDominio3Op() {
        com.ibm.ws.webservices.engine.description.OperationDesc obterDominio3Op = null;
        com.ibm.ws.webservices.engine.description.ParameterDesc[]  _params0 = new com.ibm.ws.webservices.engine.description.ParameterDesc[] {
          };
        com.ibm.ws.webservices.engine.description.ParameterDesc  _returnDesc0 = new com.ibm.ws.webservices.engine.description.ParameterDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "ObterDominioResult"), com.ibm.ws.webservices.engine.description.ParameterDesc.OUT, com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/dominios", "ArrayOfDominio"), br.org.febraban.acordosplanoseconomicos.Dominio[].class, true, false, false, true, true, false); 
        _returnDesc0.setOption("partQNameString","{http://acordosplanoseconomicos.febraban.org.br/contratos/dominios}ArrayOfDominio");
        _returnDesc0.setOption("outputPosition","0");
        _returnDesc0.setOption("partName","ArrayOfDominio");
        com.ibm.ws.webservices.engine.description.FaultDesc[]  _faults0 = new com.ibm.ws.webservices.engine.description.FaultDesc[] {
          };
        obterDominio3Op = new com.ibm.ws.webservices.engine.description.OperationDesc("obterDominio", com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "ObterDominio"), _params0, _returnDesc0, _faults0, null);
        obterDominio3Op.setOption("buildNum","cf031428.03");
        obterDominio3Op.setOption("ResponseNamespace","http://acordosplanoseconomicos.febraban.org.br");
        obterDominio3Op.setOption("targetNamespace","http://acordosplanoseconomicos.febraban.org.br");
        obterDominio3Op.setOption("outputMessageQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "IDominioService_ObterDominio_OutputMessage"));
        obterDominio3Op.setOption("inputWSAAction","http://acordosplanoseconomicos.febraban.org.br/IDominioService/ObterDominio");
        obterDominio3Op.setOption("portTypeQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "IDominioService"));
        obterDominio3Op.setOption("outputWSAAction","http://acordosplanoseconomicos.febraban.org.br/IDominioService/ObterDominioResponse");
        obterDominio3Op.setOption("ServiceQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "AcordoPlanoEconomicosService"));
        obterDominio3Op.setOption("ResponseLocalPart","ObterDominioResponse");
        obterDominio3Op.setOption("inputMessageQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "IDominioService_ObterDominio_InputMessage"));
        obterDominio3Op.setStyle(com.ibm.ws.webservices.engine.enumtype.Style.WRAPPED);
        return obterDominio3Op;

    }

    private static com.ibm.ws.webservices.engine.description.OperationDesc _confirmarRecebimentoPedido4Op() {
        com.ibm.ws.webservices.engine.description.OperationDesc confirmarRecebimentoPedido4Op = null;
        com.ibm.ws.webservices.engine.description.ParameterDesc[]  _params0 = new com.ibm.ws.webservices.engine.description.ParameterDesc[] {
         new com.ibm.ws.webservices.engine.description.ParameterDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "pedidosRecebidos"), com.ibm.ws.webservices.engine.description.ParameterDesc.IN, com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/requisicoes", "ConfirmacaoPedidosRecebidos"), br.org.febraban.acordosplanoseconomicos.ConfirmacaoPedidosRecebidos.class, false, false, false, true, true, false), 
          };
        _params0[0].setOption("partQNameString","{http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/requisicoes}ConfirmacaoPedidosRecebidos");
        _params0[0].setOption("inputPosition","0");
        _params0[0].setOption("partName","ConfirmacaoPedidosRecebidos");
        com.ibm.ws.webservices.engine.description.ParameterDesc  _returnDesc0 = new com.ibm.ws.webservices.engine.description.ParameterDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "ConfirmarRecebimentoPedidoResult"), com.ibm.ws.webservices.engine.description.ParameterDesc.OUT, com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/respostas", "ArrayOfRespostaConfirmacaoRecebimentoPedido"), br.org.febraban.acordosplanoseconomicos.RespostaConfirmacaoRecebimentoPedido[].class, true, false, false, true, true, false); 
        _returnDesc0.setOption("partQNameString","{http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/respostas}ArrayOfRespostaConfirmacaoRecebimentoPedido");
        _returnDesc0.setOption("outputPosition","0");
        _returnDesc0.setOption("partName","ArrayOfRespostaConfirmacaoRecebimentoPedido");
        com.ibm.ws.webservices.engine.description.FaultDesc[]  _faults0 = new com.ibm.ws.webservices.engine.description.FaultDesc[] {
          };
        confirmarRecebimentoPedido4Op = new com.ibm.ws.webservices.engine.description.OperationDesc("confirmarRecebimentoPedido", com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "ConfirmarRecebimentoPedido"), _params0, _returnDesc0, _faults0, null);
        confirmarRecebimentoPedido4Op.setOption("buildNum","cf031428.03");
        confirmarRecebimentoPedido4Op.setOption("ResponseNamespace","http://acordosplanoseconomicos.febraban.org.br");
        confirmarRecebimentoPedido4Op.setOption("targetNamespace","http://acordosplanoseconomicos.febraban.org.br");
        confirmarRecebimentoPedido4Op.setOption("outputMessageQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "IPedidoService_ConfirmarRecebimentoPedido_OutputMessage"));
        confirmarRecebimentoPedido4Op.setOption("inputWSAAction","http://acordosplanoseconomicos.febraban.org.br/IPedidoService/ConfirmarRecebimentoPedido");
        confirmarRecebimentoPedido4Op.setOption("portTypeQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "IPedidoService"));
        confirmarRecebimentoPedido4Op.setOption("outputWSAAction","http://acordosplanoseconomicos.febraban.org.br/IPedidoService/ConfirmarRecebimentoPedidoResponse");
        confirmarRecebimentoPedido4Op.setOption("ServiceQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "AcordoPlanoEconomicosService"));
        confirmarRecebimentoPedido4Op.setOption("ResponseLocalPart","ConfirmarRecebimentoPedidoResponse");
        confirmarRecebimentoPedido4Op.setOption("inputMessageQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "IPedidoService_ConfirmarRecebimentoPedido_InputMessage"));
        confirmarRecebimentoPedido4Op.setStyle(com.ibm.ws.webservices.engine.enumtype.Style.WRAPPED);
        return confirmarRecebimentoPedido4Op;

    }

    private static com.ibm.ws.webservices.engine.description.OperationDesc _obterPedido5Op() {
        com.ibm.ws.webservices.engine.description.OperationDesc obterPedido5Op = null;
        com.ibm.ws.webservices.engine.description.ParameterDesc[]  _params0 = new com.ibm.ws.webservices.engine.description.ParameterDesc[] {
         new com.ibm.ws.webservices.engine.description.ParameterDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "solicitacao"), com.ibm.ws.webservices.engine.description.ParameterDesc.IN, com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/filtros", "PedidoFiltro"), br.org.febraban.acordosplanoseconomicos.PedidoFiltro.class, false, false, false, true, true, false), 
          };
        _params0[0].setOption("partQNameString","{http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/filtros}PedidoFiltro");
        _params0[0].setOption("inputPosition","0");
        _params0[0].setOption("partName","PedidoFiltro");
        com.ibm.ws.webservices.engine.description.ParameterDesc  _returnDesc0 = new com.ibm.ws.webservices.engine.description.ParameterDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "ObterPedidoResult"), com.ibm.ws.webservices.engine.description.ParameterDesc.OUT, com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/respostas", "RespostaObterPedido"), br.org.febraban.acordosplanoseconomicos.RespostaObterPedido.class, true, false, false, true, true, false); 
        _returnDesc0.setOption("partQNameString","{http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/respostas}RespostaObterPedido");
        _returnDesc0.setOption("outputPosition","0");
        _returnDesc0.setOption("partName","RespostaObterPedido");
        com.ibm.ws.webservices.engine.description.FaultDesc[]  _faults0 = new com.ibm.ws.webservices.engine.description.FaultDesc[] {
          };
        obterPedido5Op = new com.ibm.ws.webservices.engine.description.OperationDesc("obterPedido", com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "ObterPedido"), _params0, _returnDesc0, _faults0, null);
        obterPedido5Op.setOption("buildNum","cf031428.03");
        obterPedido5Op.setOption("ResponseNamespace","http://acordosplanoseconomicos.febraban.org.br");
        obterPedido5Op.setOption("targetNamespace","http://acordosplanoseconomicos.febraban.org.br");
        obterPedido5Op.setOption("outputMessageQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "IPedidoService_ObterPedido_OutputMessage"));
        obterPedido5Op.setOption("inputWSAAction","http://acordosplanoseconomicos.febraban.org.br/IPedidoService/ObterPedido");
        obterPedido5Op.setOption("portTypeQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "IPedidoService"));
        obterPedido5Op.setOption("outputWSAAction","http://acordosplanoseconomicos.febraban.org.br/IPedidoService/ObterPedidoResponse");
        obterPedido5Op.setOption("ServiceQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "AcordoPlanoEconomicosService"));
        obterPedido5Op.setOption("ResponseLocalPart","ObterPedidoResponse");
        obterPedido5Op.setOption("inputMessageQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "IPedidoService_ObterPedido_InputMessage"));
        obterPedido5Op.setStyle(com.ibm.ws.webservices.engine.enumtype.Style.WRAPPED);
        return obterPedido5Op;

    }

    private static com.ibm.ws.webservices.engine.description.OperationDesc _cadastrarResultadoAnalisePedido6Op() {
        com.ibm.ws.webservices.engine.description.OperationDesc cadastrarResultadoAnalisePedido6Op = null;
        com.ibm.ws.webservices.engine.description.ParameterDesc[]  _params0 = new com.ibm.ws.webservices.engine.description.ParameterDesc[] {
         new com.ibm.ws.webservices.engine.description.ParameterDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "resultadoAnalisePedido"), com.ibm.ws.webservices.engine.description.ParameterDesc.IN, com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/acordos", "ResultadoAnalisePedido"), br.org.febraban.acordosplanoseconomicos.ResultadoAnalisePedido.class, false, false, false, true, true, false), 
          };
        _params0[0].setOption("partQNameString","{http://acordosplanoseconomicos.febraban.org.br/contratos/acordos}ResultadoAnalisePedido");
        _params0[0].setOption("inputPosition","0");
        _params0[0].setOption("partName","ResultadoAnalisePedido");
        com.ibm.ws.webservices.engine.description.ParameterDesc  _returnDesc0 = new com.ibm.ws.webservices.engine.description.ParameterDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "CadastrarResultadoAnalisePedidoResult"), com.ibm.ws.webservices.engine.description.ParameterDesc.OUT, com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "RespostaOperacao"), br.org.febraban.acordosplanoseconomicos.RespostaOperacao.class, true, false, false, true, true, false); 
        _returnDesc0.setOption("partQNameString","{http://acordosplanoseconomicos.febraban.org.br}RespostaOperacao");
        _returnDesc0.setOption("outputPosition","0");
        _returnDesc0.setOption("partName","RespostaOperacao");
        com.ibm.ws.webservices.engine.description.FaultDesc[]  _faults0 = new com.ibm.ws.webservices.engine.description.FaultDesc[] {
          };
        cadastrarResultadoAnalisePedido6Op = new com.ibm.ws.webservices.engine.description.OperationDesc("cadastrarResultadoAnalisePedido", com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "CadastrarResultadoAnalisePedido"), _params0, _returnDesc0, _faults0, null);
        cadastrarResultadoAnalisePedido6Op.setOption("buildNum","cf031428.03");
        cadastrarResultadoAnalisePedido6Op.setOption("ResponseNamespace","http://acordosplanoseconomicos.febraban.org.br");
        cadastrarResultadoAnalisePedido6Op.setOption("targetNamespace","http://acordosplanoseconomicos.febraban.org.br");
        cadastrarResultadoAnalisePedido6Op.setOption("outputMessageQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "IAcordoService_CadastrarResultadoAnalisePedido_OutputMessage"));
        cadastrarResultadoAnalisePedido6Op.setOption("inputWSAAction","http://acordosplanoseconomicos.febraban.org.br/IAcordoService/CadastrarResultadoAnalisePedido");
        cadastrarResultadoAnalisePedido6Op.setOption("portTypeQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "IAcordoService"));
        cadastrarResultadoAnalisePedido6Op.setOption("outputWSAAction","http://acordosplanoseconomicos.febraban.org.br/IAcordoService/CadastrarResultadoAnalisePedidoResponse");
        cadastrarResultadoAnalisePedido6Op.setOption("ServiceQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "AcordoPlanoEconomicosService"));
        cadastrarResultadoAnalisePedido6Op.setOption("ResponseLocalPart","CadastrarResultadoAnalisePedidoResponse");
        cadastrarResultadoAnalisePedido6Op.setOption("inputMessageQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "IAcordoService_CadastrarResultadoAnalisePedido_InputMessage"));
        cadastrarResultadoAnalisePedido6Op.setStyle(com.ibm.ws.webservices.engine.enumtype.Style.WRAPPED);
        return cadastrarResultadoAnalisePedido6Op;

    }

    private static com.ibm.ws.webservices.engine.description.OperationDesc _informarPagamento7Op() {
        com.ibm.ws.webservices.engine.description.OperationDesc informarPagamento7Op = null;
        com.ibm.ws.webservices.engine.description.ParameterDesc[]  _params0 = new com.ibm.ws.webservices.engine.description.ParameterDesc[] {
         new com.ibm.ws.webservices.engine.description.ParameterDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "pagamento"), com.ibm.ws.webservices.engine.description.ParameterDesc.IN, com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/acordos", "PagamentoAcordo"), br.org.febraban.acordosplanoseconomicos.PagamentoAcordo.class, false, false, false, true, true, false), 
          };
        _params0[0].setOption("partQNameString","{http://acordosplanoseconomicos.febraban.org.br/contratos/acordos}PagamentoAcordo");
        _params0[0].setOption("inputPosition","0");
        _params0[0].setOption("partName","PagamentoAcordo");
        com.ibm.ws.webservices.engine.description.ParameterDesc  _returnDesc0 = new com.ibm.ws.webservices.engine.description.ParameterDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "InformarPagamentoResult"), com.ibm.ws.webservices.engine.description.ParameterDesc.OUT, com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "RespostaOperacao"), br.org.febraban.acordosplanoseconomicos.RespostaOperacao.class, true, false, false, true, true, false); 
        _returnDesc0.setOption("partQNameString","{http://acordosplanoseconomicos.febraban.org.br}RespostaOperacao");
        _returnDesc0.setOption("outputPosition","0");
        _returnDesc0.setOption("partName","RespostaOperacao");
        com.ibm.ws.webservices.engine.description.FaultDesc[]  _faults0 = new com.ibm.ws.webservices.engine.description.FaultDesc[] {
          };
        informarPagamento7Op = new com.ibm.ws.webservices.engine.description.OperationDesc("informarPagamento", com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "InformarPagamento"), _params0, _returnDesc0, _faults0, null);
        informarPagamento7Op.setOption("buildNum","cf031428.03");
        informarPagamento7Op.setOption("ResponseNamespace","http://acordosplanoseconomicos.febraban.org.br");
        informarPagamento7Op.setOption("targetNamespace","http://acordosplanoseconomicos.febraban.org.br");
        informarPagamento7Op.setOption("outputMessageQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "IAcordoService_InformarPagamento_OutputMessage"));
        informarPagamento7Op.setOption("inputWSAAction","http://acordosplanoseconomicos.febraban.org.br/IAcordoService/InformarPagamento");
        informarPagamento7Op.setOption("portTypeQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "IAcordoService"));
        informarPagamento7Op.setOption("outputWSAAction","http://acordosplanoseconomicos.febraban.org.br/IAcordoService/InformarPagamentoResponse");
        informarPagamento7Op.setOption("ServiceQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "AcordoPlanoEconomicosService"));
        informarPagamento7Op.setOption("ResponseLocalPart","InformarPagamentoResponse");
        informarPagamento7Op.setOption("inputMessageQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "IAcordoService_InformarPagamento_InputMessage"));
        informarPagamento7Op.setStyle(com.ibm.ws.webservices.engine.enumtype.Style.WRAPPED);
        return informarPagamento7Op;

    }

    private static com.ibm.ws.webservices.engine.description.OperationDesc _obterRespostaProposta8Op() {
        com.ibm.ws.webservices.engine.description.OperationDesc obterRespostaProposta8Op = null;
        com.ibm.ws.webservices.engine.description.ParameterDesc[]  _params0 = new com.ibm.ws.webservices.engine.description.ParameterDesc[] {
         new com.ibm.ws.webservices.engine.description.ParameterDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "filtro"), com.ibm.ws.webservices.engine.description.ParameterDesc.IN, com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/acordos/filtros", "RespostaPropostaFiltro"), br.org.febraban.acordosplanoseconomicos.RespostaPropostaFiltro.class, false, false, false, true, true, false), 
          };
        _params0[0].setOption("partQNameString","{http://acordosplanoseconomicos.febraban.org.br/contratos/acordos/filtros}RespostaPropostaFiltro");
        _params0[0].setOption("inputPosition","0");
        _params0[0].setOption("partName","RespostaPropostaFiltro");
        com.ibm.ws.webservices.engine.description.ParameterDesc  _returnDesc0 = new com.ibm.ws.webservices.engine.description.ParameterDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "ObterRespostaPropostaResult"), com.ibm.ws.webservices.engine.description.ParameterDesc.OUT, com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/acordos", "ArrayOfAceiteProposta"), br.org.febraban.acordosplanoseconomicos.AceiteProposta[].class, true, false, false, true, true, false); 
        _returnDesc0.setOption("partQNameString","{http://acordosplanoseconomicos.febraban.org.br/contratos/acordos}ArrayOfAceiteProposta");
        _returnDesc0.setOption("outputPosition","0");
        _returnDesc0.setOption("partName","ArrayOfAceiteProposta");
        com.ibm.ws.webservices.engine.description.FaultDesc[]  _faults0 = new com.ibm.ws.webservices.engine.description.FaultDesc[] {
          };
        obterRespostaProposta8Op = new com.ibm.ws.webservices.engine.description.OperationDesc("obterRespostaProposta", com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "ObterRespostaProposta"), _params0, _returnDesc0, _faults0, null);
        obterRespostaProposta8Op.setOption("buildNum","cf031428.03");
        obterRespostaProposta8Op.setOption("ResponseNamespace","http://acordosplanoseconomicos.febraban.org.br");
        obterRespostaProposta8Op.setOption("targetNamespace","http://acordosplanoseconomicos.febraban.org.br");
        obterRespostaProposta8Op.setOption("outputMessageQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "IAcordoService_ObterRespostaProposta_OutputMessage"));
        obterRespostaProposta8Op.setOption("inputWSAAction","http://acordosplanoseconomicos.febraban.org.br/IAcordoService/ObterRespostaProposta");
        obterRespostaProposta8Op.setOption("portTypeQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "IAcordoService"));
        obterRespostaProposta8Op.setOption("outputWSAAction","http://acordosplanoseconomicos.febraban.org.br/IAcordoService/ObterRespostaPropostaResponse");
        obterRespostaProposta8Op.setOption("ServiceQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "AcordoPlanoEconomicosService"));
        obterRespostaProposta8Op.setOption("ResponseLocalPart","ObterRespostaPropostaResponse");
        obterRespostaProposta8Op.setOption("inputMessageQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "IAcordoService_ObterRespostaProposta_InputMessage"));
        obterRespostaProposta8Op.setStyle(com.ibm.ws.webservices.engine.enumtype.Style.WRAPPED);
        return obterRespostaProposta8Op;

    }


    private static void initTypeMappings() {
        typeMappings = new java.util.HashMap();
        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/filtros", "PedidoFiltro"),
                         br.org.febraban.acordosplanoseconomicos.PedidoFiltro.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/respostas", "RespostaObterPedido"),
                         br.org.febraban.acordosplanoseconomicos.RespostaObterPedido.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/requisicoes", "ConfirmacaoPedidosRecebidos"),
                         br.org.febraban.acordosplanoseconomicos.ConfirmacaoPedidosRecebidos.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/respostas", "ArrayOfRespostaConfirmacaoRecebimentoPedido"),
                         br.org.febraban.acordosplanoseconomicos.RespostaConfirmacaoRecebimentoPedido[].class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "RespostaOperacao"),
                         br.org.febraban.acordosplanoseconomicos.RespostaOperacao.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/enums", "RetornoProcessamentoEnum"),
                         br.org.febraban.acordosplanoseconomicos.RetornoProcessamentoEnum.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/acordos", "ResultadoAnalisePedido"),
                         br.org.febraban.acordosplanoseconomicos.ResultadoAnalisePedido.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/acordos/filtros", "RespostaPropostaFiltro"),
                         br.org.febraban.acordosplanoseconomicos.RespostaPropostaFiltro.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/acordos", "ArrayOfAceiteProposta"),
                         br.org.febraban.acordosplanoseconomicos.AceiteProposta[].class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/acordos", "PagamentoAcordo"),
                         br.org.febraban.acordosplanoseconomicos.PagamentoAcordo.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/documentos", "ArrayOfDocumento"),
                         br.org.febraban.acordosplanoseconomicos.Documento[].class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/documentos/requisicoes", "IdentificadorArquivo"),
                         br.org.febraban.acordosplanoseconomicos.IdentificadorArquivo.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/documentos", "Arquivo"),
                         br.org.febraban.acordosplanoseconomicos.Arquivo.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/documentos/requisicoes", "RequisicaoConfirmacaoRecebimentoArquivo"),
                         br.org.febraban.acordosplanoseconomicos.RequisicaoConfirmacaoRecebimentoArquivo.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/documentos/respostas", "ArrayOfRespostaOperacaoConfirmarRecebimentoArquivo"),
                         br.org.febraban.acordosplanoseconomicos.RespostaOperacaoConfirmarRecebimentoArquivo[].class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/dominios", "ArrayOfDominio"),
                         br.org.febraban.acordosplanoseconomicos.Dominio[].class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://schemas.microsoft.com/2003/10/Serialization/", "guid"),
                         java.lang.String.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/enums", "StatusPedidoEnum"),
                         br.org.febraban.acordosplanoseconomicos.StatusPedidoEnum.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/enums", "DestinatarioContaEnum"),
                         br.org.febraban.acordosplanoseconomicos.DestinatarioContaEnum.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/enums", "TipoIdentidadeEnum"),
                         br.org.febraban.acordosplanoseconomicos.TipoIdentidadeEnum.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/enums", "QualificacaoEnvolvidoEnum"),
                         br.org.febraban.acordosplanoseconomicos.QualificacaoEnvolvidoEnum.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/enums", "EsferaEnum"),
                         br.org.febraban.acordosplanoseconomicos.EsferaEnum.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/enums", "QualificacaoPatronoEnum"),
                         br.org.febraban.acordosplanoseconomicos.QualificacaoPatronoEnum.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/enums", "TipoProcessoEnum"),
                         br.org.febraban.acordosplanoseconomicos.TipoProcessoEnum.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/enums", "TipoAcaoEnum"),
                         br.org.febraban.acordosplanoseconomicos.TipoAcaoEnum.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/enums", "ResultadoAnaliseBPOEnum"),
                         br.org.febraban.acordosplanoseconomicos.ResultadoAnaliseBPOEnum.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/enums", "ArrayOfMotivoNCEnum"),
                         br.org.febraban.acordosplanoseconomicos.MotivoNCEnum[].class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/enums", "MotivoNCEnum"),
                         br.org.febraban.acordosplanoseconomicos.MotivoNCEnum.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/enums", "MotivoRecusaPedidoEnum"),
                         br.org.febraban.acordosplanoseconomicos.MotivoRecusaPedidoEnum.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/", "ArrayOfPedido"),
                         br.org.febraban.acordosplanoseconomicos.Pedido[].class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/respostas", "RespostaConfirmacaoRecebimentoPedido"),
                         br.org.febraban.acordosplanoseconomicos.RespostaConfirmacaoRecebimentoPedido.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/", "Pedido"),
                         br.org.febraban.acordosplanoseconomicos.Pedido.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/", "Parte"),
                         br.org.febraban.acordosplanoseconomicos.Parte.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/", "ArrayOfParte"),
                         br.org.febraban.acordosplanoseconomicos.Parte[].class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/", "Advogado"),
                         br.org.febraban.acordosplanoseconomicos.Advogado.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/", "ContaPagamento"),
                         br.org.febraban.acordosplanoseconomicos.ContaPagamento.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/", "Processo"),
                         br.org.febraban.acordosplanoseconomicos.Processo.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/", "ArrayOfContaPlano"),
                         br.org.febraban.acordosplanoseconomicos.ContaPlano[].class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/", "BPO"),
                         br.org.febraban.acordosplanoseconomicos.BPO.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/tipos", "Identidade"),
                         br.org.febraban.acordosplanoseconomicos.Identidade.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/tipos", "Endereco"),
                         br.org.febraban.acordosplanoseconomicos.Endereco.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/", "Contato"),
                         br.org.febraban.acordosplanoseconomicos.Contato.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/tipos", "Telefone"),
                         br.org.febraban.acordosplanoseconomicos.Telefone.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/tipos", "IdentidadePatrono"),
                         br.org.febraban.acordosplanoseconomicos.IdentidadePatrono.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/tipos", "Conta"),
                         br.org.febraban.acordosplanoseconomicos.Conta.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/tipos", "DepositoJudicial"),
                         br.org.febraban.acordosplanoseconomicos.DepositoJudicial.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/", "ContaPlano"),
                         br.org.febraban.acordosplanoseconomicos.ContaPlano.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/enums", "PlanoEnum"),
                         br.org.febraban.acordosplanoseconomicos.PlanoEnum.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/", "ArrayOfHabilitacao"),
                         br.org.febraban.acordosplanoseconomicos.Habilitacao[].class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/", "Habilitacao"),
                         br.org.febraban.acordosplanoseconomicos.Habilitacao.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/", "ArrayOfResultadoAnaliseBPO"),
                         br.org.febraban.acordosplanoseconomicos.ResultadoAnaliseBPO[].class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/", "ResultadoAnaliseBPO"),
                         br.org.febraban.acordosplanoseconomicos.ResultadoAnaliseBPO.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/enums", "ContextoEnum"),
                         br.org.febraban.acordosplanoseconomicos.ContextoEnum.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/enums", "TipoDocumentoEnum"),
                         br.org.febraban.acordosplanoseconomicos.TipoDocumentoEnum.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/tipos/enums", "TipoContaEnum"),
                         br.org.febraban.acordosplanoseconomicos.TipoContaEnum.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/documentos", "Documento"),
                         br.org.febraban.acordosplanoseconomicos.Documento.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://schemas.microsoft.com/2003/10/Serialization/Arrays", "ArrayOfstring"),
                         java.lang.String[].class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/acordos/enums", "TipoResultadoAnaliseHabilitacaoEnum"),
                         br.org.febraban.acordosplanoseconomicos.TipoResultadoAnaliseHabilitacaoEnum.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/acordos", "Proposta"),
                         br.org.febraban.acordosplanoseconomicos.Proposta.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/acordos", "AceiteProposta"),
                         br.org.febraban.acordosplanoseconomicos.AceiteProposta.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/acordos/enums", "AceitePropostaEnum"),
                         br.org.febraban.acordosplanoseconomicos.AceitePropostaEnum.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/acordos/enums", "StatusPagamentoEnum"),
                         br.org.febraban.acordosplanoseconomicos.StatusPagamentoEnum.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/documentos/requisicoes", "ArrayOfIdentificadorArquivo"),
                         br.org.febraban.acordosplanoseconomicos.IdentificadorArquivo[].class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/documentos/respostas", "RespostaOperacaoConfirmarRecebimentoArquivo"),
                         br.org.febraban.acordosplanoseconomicos.RespostaOperacaoConfirmarRecebimentoArquivo.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/dominios", "Dominio"),
                         br.org.febraban.acordosplanoseconomicos.Dominio.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/dominios", "ArrayOfDominioItem"),
                         br.org.febraban.acordosplanoseconomicos.DominioItem[].class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/dominios", "DominioItem"),
                         br.org.febraban.acordosplanoseconomicos.DominioItem.class);

        typeMappings = java.util.Collections.unmodifiableMap(typeMappings);
    }

    public java.util.Map getTypeMappings() {
        return typeMappings;
    }

    public Class getJavaType(javax.xml.namespace.QName xmlName) {
        return (Class) typeMappings.get(xmlName);
    }

    public java.util.Map getOperationDescriptions(String portName) {
        return (java.util.Map) operationDescriptions.get(portName);
    }

    public java.util.List getOperationDescriptions(String portName, String operationName) {
        java.util.Map map = (java.util.Map) operationDescriptions.get(portName);
        if (map != null) {
            return (java.util.List) map.get(operationName);
        }
        return null;
    }

}
