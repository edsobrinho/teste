/**
 * AcordoPlanoEconomicosServiceLocator.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf031428.03 v72314182347
 */

package br.org.febraban.acordosplanoseconomicos;

public class AcordoPlanoEconomicosServiceLocator extends com.ibm.ws.webservices.multiprotocol.AgnosticService implements com.ibm.ws.webservices.multiprotocol.GeneratedService, br.org.febraban.acordosplanoseconomicos.AcordoPlanoEconomicosService {

    public AcordoPlanoEconomicosServiceLocator() {
        super(com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
           "http://acordosplanoseconomicos.febraban.org.br",
           "AcordoPlanoEconomicosService"));

        context.setLocatorName("br.org.febraban.acordosplanoseconomicos.AcordoPlanoEconomicosServiceLocator");
    }

    public AcordoPlanoEconomicosServiceLocator(com.ibm.ws.webservices.multiprotocol.ServiceContext ctx) {
        super(ctx);
        context.setLocatorName("br.org.febraban.acordosplanoseconomicos.AcordoPlanoEconomicosServiceLocator");
    }

    // Utilize para obter uma classe proxy para dominio
    private final java.lang.String dominio_address = "http://localhost:8733/Design_Time_Addresses/WebService/Service1/dominio";

    public java.lang.String getDominioAddress() {
        if (context.getOverriddingEndpointURIs() == null) {
            return dominio_address;
        }
        String overriddingEndpoint = (String) context.getOverriddingEndpointURIs().get("dominio");
        if (overriddingEndpoint != null) {
            return overriddingEndpoint;
        }
        else {
            return dominio_address;
        }
    }

    private java.lang.String dominioPortName = "dominio";

    // The WSDD port name defaults to the port name.
    private java.lang.String dominioWSDDPortName = "dominio";

    public java.lang.String getDominioWSDDPortName() {
        return dominioWSDDPortName;
    }

    public void setDominioWSDDPortName(java.lang.String name) {
        dominioWSDDPortName = name;
    }

    public br.org.febraban.acordosplanoseconomicos.IDominioService getDominio() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(getDominioAddress());
        }
        catch (java.net.MalformedURLException e) {
            return null; // é improvável que o URL tenha sido validado em WSDL2Java
        }
        return getDominio(endpoint);
    }

    public br.org.febraban.acordosplanoseconomicos.IDominioService getDominio(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        br.org.febraban.acordosplanoseconomicos.IDominioService _stub =
            (br.org.febraban.acordosplanoseconomicos.IDominioService) getStub(
                dominioPortName,
                (String) getPort2NamespaceMap().get(dominioPortName),
                br.org.febraban.acordosplanoseconomicos.IDominioService.class,
                "br.org.febraban.acordosplanoseconomicos.DominioStub",
                portAddress.toString());
        if (_stub instanceof com.ibm.ws.webservices.engine.client.Stub) {
            ((com.ibm.ws.webservices.engine.client.Stub) _stub).setPortName(dominioWSDDPortName);
        }
        return _stub;
    }


    // Utilize para obter uma classe proxy para pedido
    private final java.lang.String pedido_address = "http://localhost:8733/Design_Time_Addresses/WebService/Service1/pedido";

    public java.lang.String getPedidoAddress() {
        if (context.getOverriddingEndpointURIs() == null) {
            return pedido_address;
        }
        String overriddingEndpoint = (String) context.getOverriddingEndpointURIs().get("pedido");
        if (overriddingEndpoint != null) {
            return overriddingEndpoint;
        }
        else {
            return pedido_address;
        }
    }

    private java.lang.String pedidoPortName = "pedido";

    // The WSDD port name defaults to the port name.
    private java.lang.String pedidoWSDDPortName = "pedido";

    public java.lang.String getPedidoWSDDPortName() {
        return pedidoWSDDPortName;
    }

    public void setPedidoWSDDPortName(java.lang.String name) {
        pedidoWSDDPortName = name;
    }

    public br.org.febraban.acordosplanoseconomicos.IPedidoService getPedido() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(getPedidoAddress());
        }
        catch (java.net.MalformedURLException e) {
            return null; // é improvável que o URL tenha sido validado em WSDL2Java
        }
        return getPedido(endpoint);
    }

    public br.org.febraban.acordosplanoseconomicos.IPedidoService getPedido(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        br.org.febraban.acordosplanoseconomicos.IPedidoService _stub =
            (br.org.febraban.acordosplanoseconomicos.IPedidoService) getStub(
                pedidoPortName,
                (String) getPort2NamespaceMap().get(pedidoPortName),
                br.org.febraban.acordosplanoseconomicos.IPedidoService.class,
                "br.org.febraban.acordosplanoseconomicos.PedidoStub",
                portAddress.toString());
        if (_stub instanceof com.ibm.ws.webservices.engine.client.Stub) {
            ((com.ibm.ws.webservices.engine.client.Stub) _stub).setPortName(pedidoWSDDPortName);
        }
        return _stub;
    }


    // Utilize para obter uma classe proxy para documento
    private final java.lang.String documento_address = "http://localhost:8733/Design_Time_Addresses/WebService/Service1/documento";

    public java.lang.String getDocumentoAddress() {
        if (context.getOverriddingEndpointURIs() == null) {
            return documento_address;
        }
        String overriddingEndpoint = (String) context.getOverriddingEndpointURIs().get("documento");
        if (overriddingEndpoint != null) {
            return overriddingEndpoint;
        }
        else {
            return documento_address;
        }
    }

    private java.lang.String documentoPortName = "documento";

    // The WSDD port name defaults to the port name.
    private java.lang.String documentoWSDDPortName = "documento";

    public java.lang.String getDocumentoWSDDPortName() {
        return documentoWSDDPortName;
    }

    public void setDocumentoWSDDPortName(java.lang.String name) {
        documentoWSDDPortName = name;
    }

    public br.org.febraban.acordosplanoseconomicos.IDocumentoService getDocumento() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(getDocumentoAddress());
        }
        catch (java.net.MalformedURLException e) {
            return null; // é improvável que o URL tenha sido validado em WSDL2Java
        }
        return getDocumento(endpoint);
    }

    public br.org.febraban.acordosplanoseconomicos.IDocumentoService getDocumento(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        br.org.febraban.acordosplanoseconomicos.IDocumentoService _stub =
            (br.org.febraban.acordosplanoseconomicos.IDocumentoService) getStub(
                documentoPortName,
                (String) getPort2NamespaceMap().get(documentoPortName),
                br.org.febraban.acordosplanoseconomicos.IDocumentoService.class,
                "br.org.febraban.acordosplanoseconomicos.DocumentoStub",
                portAddress.toString());
        if (_stub instanceof com.ibm.ws.webservices.engine.client.Stub) {
            ((com.ibm.ws.webservices.engine.client.Stub) _stub).setPortName(documentoWSDDPortName);
        }
        return _stub;
    }


    // Utilize para obter uma classe proxy para acordo
    private final java.lang.String acordo_address = "http://localhost:8733/Design_Time_Addresses/WebService/Service1/acordo";

    public java.lang.String getAcordoAddress() {
        if (context.getOverriddingEndpointURIs() == null) {
            return acordo_address;
        }
        String overriddingEndpoint = (String) context.getOverriddingEndpointURIs().get("acordo");
        if (overriddingEndpoint != null) {
            return overriddingEndpoint;
        }
        else {
            return acordo_address;
        }
    }

    private java.lang.String acordoPortName = "acordo";

    // The WSDD port name defaults to the port name.
    private java.lang.String acordoWSDDPortName = "acordo";

    public java.lang.String getAcordoWSDDPortName() {
        return acordoWSDDPortName;
    }

    public void setAcordoWSDDPortName(java.lang.String name) {
        acordoWSDDPortName = name;
    }

    public br.org.febraban.acordosplanoseconomicos.IAcordoService getAcordo() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(getAcordoAddress());
        }
        catch (java.net.MalformedURLException e) {
            return null; // é improvável que o URL tenha sido validado em WSDL2Java
        }
        return getAcordo(endpoint);
    }

    public br.org.febraban.acordosplanoseconomicos.IAcordoService getAcordo(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        br.org.febraban.acordosplanoseconomicos.IAcordoService _stub =
            (br.org.febraban.acordosplanoseconomicos.IAcordoService) getStub(
                acordoPortName,
                (String) getPort2NamespaceMap().get(acordoPortName),
                br.org.febraban.acordosplanoseconomicos.IAcordoService.class,
                "br.org.febraban.acordosplanoseconomicos.AcordoStub",
                portAddress.toString());
        if (_stub instanceof com.ibm.ws.webservices.engine.client.Stub) {
            ((com.ibm.ws.webservices.engine.client.Stub) _stub).setPortName(acordoWSDDPortName);
        }
        return _stub;
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        try {
            if (br.org.febraban.acordosplanoseconomicos.IDocumentoService.class.isAssignableFrom(serviceEndpointInterface)) {
                return getDocumento();
            }
            if (br.org.febraban.acordosplanoseconomicos.IDominioService.class.isAssignableFrom(serviceEndpointInterface)) {
                return getDominio();
            }
            if (br.org.febraban.acordosplanoseconomicos.IPedidoService.class.isAssignableFrom(serviceEndpointInterface)) {
                return getPedido();
            }
            if (br.org.febraban.acordosplanoseconomicos.IAcordoService.class.isAssignableFrom(serviceEndpointInterface)) {
                return getAcordo();
            }
        }
        catch (java.lang.Throwable t) {
            throw new javax.xml.rpc.ServiceException(t);
        }
        throw new javax.xml.rpc.ServiceException("WSWS3273E: Erro: Não há implementação stub para a interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(javax.xml.namespace.QName portName, Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        String inputPortName = portName.getLocalPart();
        if ("dominio".equals(inputPortName)) {
            return getDominio();
        }
        else if ("pedido".equals(inputPortName)) {
            return getPedido();
        }
        else if ("documento".equals(inputPortName)) {
            return getDocumento();
        }
        else if ("acordo".equals(inputPortName)) {
            return getAcordo();
        }
        else  {
            throw new javax.xml.rpc.ServiceException();
        }
    }

    public void setPortNamePrefix(java.lang.String prefix) {
        dominioWSDDPortName = prefix + "/" + dominioPortName;
        pedidoWSDDPortName = prefix + "/" + pedidoPortName;
        documentoWSDDPortName = prefix + "/" + documentoPortName;
        acordoWSDDPortName = prefix + "/" + acordoPortName;
    }

    public javax.xml.namespace.QName getServiceName() {
        return com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "AcordoPlanoEconomicosService");
    }

    private java.util.Map port2NamespaceMap = null;

    protected synchronized java.util.Map getPort2NamespaceMap() {
        if (port2NamespaceMap == null) {
            port2NamespaceMap = new java.util.HashMap();
            port2NamespaceMap.put(
               "dominio",
               "http://schemas.xmlsoap.org/wsdl/soap/");
            port2NamespaceMap.put(
               "pedido",
               "http://schemas.xmlsoap.org/wsdl/soap/");
            port2NamespaceMap.put(
               "documento",
               "http://schemas.xmlsoap.org/wsdl/soap/");
            port2NamespaceMap.put(
               "acordo",
               "http://schemas.xmlsoap.org/wsdl/soap/");
        }
        return port2NamespaceMap;
    }

    private java.util.HashSet ports = null;

    public java.util.Iterator getPorts() {
        if (ports == null) {
            ports = new java.util.HashSet();
            String serviceNamespace = getServiceName().getNamespaceURI();
            for (java.util.Iterator i = getPort2NamespaceMap().keySet().iterator(); i.hasNext(); ) {
                ports.add(
                    com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                        serviceNamespace,
                        (String) i.next()));
            }
        }
        return ports.iterator();
    }

    public javax.xml.rpc.Call[] getCalls(javax.xml.namespace.QName portName) throws javax.xml.rpc.ServiceException {
        if (portName == null) {
            throw new javax.xml.rpc.ServiceException("WSWS3062E: Erro: portName não deve ser nulo.");
        }
        if  (portName.getLocalPart().equals("dominio")) {
            return new javax.xml.rpc.Call[] {
                createCall(portName, "ObterDominio", "null"),
            };
        }
        else if  (portName.getLocalPart().equals("pedido")) {
            return new javax.xml.rpc.Call[] {
                createCall(portName, "ObterPedido", "null"),
                createCall(portName, "ConfirmarRecebimentoPedido", "null"),
            };
        }
        else if  (portName.getLocalPart().equals("documento")) {
            return new javax.xml.rpc.Call[] {
                createCall(portName, "ObterDocumento", "null"),
                createCall(portName, "ObterArquivo", "null"),
                createCall(portName, "ConfirmarRecebimentoArquivo", "null"),
            };
        }
        else if  (portName.getLocalPart().equals("acordo")) {
            return new javax.xml.rpc.Call[] {
                createCall(portName, "CadastrarResultadoAnalisePedido", "null"),
                createCall(portName, "ObterRespostaProposta", "null"),
                createCall(portName, "InformarPagamento", "null"),
            };
        }
        else {
            throw new javax.xml.rpc.ServiceException("WSWS3062E: Erro: portName não deve ser nulo.");
        }
    }
}
