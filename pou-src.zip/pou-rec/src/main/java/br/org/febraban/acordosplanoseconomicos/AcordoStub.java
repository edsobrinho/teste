/**
 * AcordoStub.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf031428.03 v72314182347
 */

package br.org.febraban.acordosplanoseconomicos;

public class AcordoStub extends com.ibm.ws.webservices.engine.client.Stub implements br.org.febraban.acordosplanoseconomicos.IAcordoService {
    public AcordoStub(java.net.URL endpointURL, javax.xml.rpc.Service service) throws com.ibm.ws.webservices.engine.WebServicesFault {
        if (service == null) {
            super.service = new com.ibm.ws.webservices.engine.client.Service();
        }
        else {
            super.service = service;
        }
        super.engine = ((com.ibm.ws.webservices.engine.client.Service) super.service).getEngine();
        super.messageContexts = new com.ibm.ws.webservices.engine.MessageContext[3];
        java.lang.String theOption = (java.lang.String)super._getProperty("lastStubMapping");
        if (theOption == null || !theOption.equals("br.org.febraban.acordosplanoseconomicos.Acordo")) {
                initTypeMapping();
                super._setProperty("lastStubMapping","br.org.febraban.acordosplanoseconomicos.Acordo");
        }
        super.cachedEndpoint = endpointURL;
        super.connection = ((com.ibm.ws.webservices.engine.client.Service) super.service).getConnection(endpointURL);
    }

    private void initTypeMapping() {
        javax.xml.rpc.encoding.TypeMapping tm = super.getTypeMapping(com.ibm.ws.webservices.engine.Constants.URI_LITERAL_ENC);
        java.lang.Class javaType = null;
        javax.xml.namespace.QName xmlType = null;
        javax.xml.namespace.QName compQName = null;
        javax.xml.namespace.QName compTypeQName = null;
        com.ibm.ws.webservices.engine.encoding.SerializerFactory sf = null;
        com.ibm.ws.webservices.engine.encoding.DeserializerFactory df = null;
        javaType = br.org.febraban.acordosplanoseconomicos.RespostaOperacao.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "RespostaOperacao");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = br.org.febraban.acordosplanoseconomicos.RetornoProcessamentoEnum.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/enums", "RetornoProcessamentoEnum");
        compTypeQName = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.w3.org/2001/XMLSchema", "string");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.EnumSerializerFactory.class, javaType, xmlType, null, compTypeQName);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.EnumDeserializerFactory.class, javaType, xmlType, null, compTypeQName);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = br.org.febraban.acordosplanoseconomicos.ResultadoAnalisePedido.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/acordos", "ResultadoAnalisePedido");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = br.org.febraban.acordosplanoseconomicos.RespostaPropostaFiltro.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/acordos/filtros", "RespostaPropostaFiltro");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = br.org.febraban.acordosplanoseconomicos.AceiteProposta[].class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/acordos", "ArrayOfAceiteProposta");
        compQName = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/acordos", "AceiteProposta");
        compTypeQName = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/acordos", "AceiteProposta");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.ArraySerializerFactory.class, javaType, xmlType, compQName, compTypeQName);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.ArrayDeserializerFactory.class, javaType, xmlType, compQName, compTypeQName);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = br.org.febraban.acordosplanoseconomicos.PagamentoAcordo.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/acordos", "PagamentoAcordo");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = br.org.febraban.acordosplanoseconomicos.Arquivo.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/documentos", "Arquivo");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = br.org.febraban.acordosplanoseconomicos.MotivoRecusaPedidoEnum.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/enums", "MotivoRecusaPedidoEnum");
        compTypeQName = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.w3.org/2001/XMLSchema", "string");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.EnumSerializerFactory.class, javaType, xmlType, null, compTypeQName);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.EnumDeserializerFactory.class, javaType, xmlType, null, compTypeQName);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = br.org.febraban.acordosplanoseconomicos.RespostaConfirmacaoRecebimentoPedido.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/respostas", "RespostaConfirmacaoRecebimentoPedido");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = br.org.febraban.acordosplanoseconomicos.ContaPagamento.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/", "ContaPagamento");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = br.org.febraban.acordosplanoseconomicos.Conta.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/tipos", "Conta");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = br.org.febraban.acordosplanoseconomicos.DepositoJudicial.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/tipos", "DepositoJudicial");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = br.org.febraban.acordosplanoseconomicos.ContaPlano.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/", "ContaPlano");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = br.org.febraban.acordosplanoseconomicos.PlanoEnum.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/enums", "PlanoEnum");
        compTypeQName = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.w3.org/2001/XMLSchema", "string");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.EnumSerializerFactory.class, javaType, xmlType, null, compTypeQName);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.EnumDeserializerFactory.class, javaType, xmlType, null, compTypeQName);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = br.org.febraban.acordosplanoseconomicos.Habilitacao[].class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/", "ArrayOfHabilitacao");
        compQName = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/", "Habilitacao");
        compTypeQName = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/", "Habilitacao");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.ArraySerializerFactory.class, javaType, xmlType, compQName, compTypeQName);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.ArrayDeserializerFactory.class, javaType, xmlType, compQName, compTypeQName);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = br.org.febraban.acordosplanoseconomicos.Habilitacao.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/", "Habilitacao");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = br.org.febraban.acordosplanoseconomicos.TipoContaEnum.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/tipos/enums", "TipoContaEnum");
        compTypeQName = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.w3.org/2001/XMLSchema", "string");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.EnumSerializerFactory.class, javaType, xmlType, null, compTypeQName);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.EnumDeserializerFactory.class, javaType, xmlType, null, compTypeQName);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = br.org.febraban.acordosplanoseconomicos.TipoResultadoAnaliseHabilitacaoEnum.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/acordos/enums", "TipoResultadoAnaliseHabilitacaoEnum");
        compTypeQName = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.w3.org/2001/XMLSchema", "string");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.EnumSerializerFactory.class, javaType, xmlType, null, compTypeQName);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.EnumDeserializerFactory.class, javaType, xmlType, null, compTypeQName);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = br.org.febraban.acordosplanoseconomicos.Proposta.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/acordos", "Proposta");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = br.org.febraban.acordosplanoseconomicos.AceiteProposta.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/acordos", "AceiteProposta");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = br.org.febraban.acordosplanoseconomicos.AceitePropostaEnum.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/acordos/enums", "AceitePropostaEnum");
        compTypeQName = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.w3.org/2001/XMLSchema", "string");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.EnumSerializerFactory.class, javaType, xmlType, null, compTypeQName);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.EnumDeserializerFactory.class, javaType, xmlType, null, compTypeQName);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = br.org.febraban.acordosplanoseconomicos.StatusPagamentoEnum.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/acordos/enums", "StatusPagamentoEnum");
        compTypeQName = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.w3.org/2001/XMLSchema", "string");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.EnumSerializerFactory.class, javaType, xmlType, null, compTypeQName);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.EnumDeserializerFactory.class, javaType, xmlType, null, compTypeQName);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = br.org.febraban.acordosplanoseconomicos.RespostaOperacaoConfirmarRecebimentoArquivo.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/documentos/respostas", "RespostaOperacaoConfirmarRecebimentoArquivo");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

    }

    private static com.ibm.ws.webservices.engine.description.OperationDesc _cadastrarResultadoAnalisePedidoOperation0 = null;
    private static com.ibm.ws.webservices.engine.description.OperationDesc _getcadastrarResultadoAnalisePedidoOperation0() {
        com.ibm.ws.webservices.engine.description.ParameterDesc[]  _params0 = new com.ibm.ws.webservices.engine.description.ParameterDesc[] {
         new com.ibm.ws.webservices.engine.description.ParameterDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "resultadoAnalisePedido"), com.ibm.ws.webservices.engine.description.ParameterDesc.IN, com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/acordos", "ResultadoAnalisePedido"), br.org.febraban.acordosplanoseconomicos.ResultadoAnalisePedido.class, false, false, false, true, true, false), 
          };
        _params0[0].setOption("partQNameString","{http://acordosplanoseconomicos.febraban.org.br/contratos/acordos}ResultadoAnalisePedido");
        _params0[0].setOption("inputPosition","0");
        _params0[0].setOption("partName","ResultadoAnalisePedido");
        com.ibm.ws.webservices.engine.description.ParameterDesc  _returnDesc0 = new com.ibm.ws.webservices.engine.description.ParameterDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "CadastrarResultadoAnalisePedidoResult"), com.ibm.ws.webservices.engine.description.ParameterDesc.OUT, com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "RespostaOperacao"), br.org.febraban.acordosplanoseconomicos.RespostaOperacao.class, true, false, false, true, true, false); 
        _returnDesc0.setOption("partQNameString","{http://acordosplanoseconomicos.febraban.org.br}RespostaOperacao");
        _returnDesc0.setOption("outputPosition","0");
        _returnDesc0.setOption("partName","RespostaOperacao");
        com.ibm.ws.webservices.engine.description.FaultDesc[]  _faults0 = new com.ibm.ws.webservices.engine.description.FaultDesc[] {
          };
        _cadastrarResultadoAnalisePedidoOperation0 = new com.ibm.ws.webservices.engine.description.OperationDesc("cadastrarResultadoAnalisePedido", com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "CadastrarResultadoAnalisePedido"), _params0, _returnDesc0, _faults0, "http://acordosplanoseconomicos.febraban.org.br/IAcordoService/CadastrarResultadoAnalisePedido");
        _cadastrarResultadoAnalisePedidoOperation0.setOption("buildNum","cf031428.03");
        _cadastrarResultadoAnalisePedidoOperation0.setOption("ResponseNamespace","http://acordosplanoseconomicos.febraban.org.br");
        _cadastrarResultadoAnalisePedidoOperation0.setOption("targetNamespace","http://acordosplanoseconomicos.febraban.org.br");
        _cadastrarResultadoAnalisePedidoOperation0.setOption("outputMessageQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "IAcordoService_CadastrarResultadoAnalisePedido_OutputMessage"));
        _cadastrarResultadoAnalisePedidoOperation0.setOption("inputWSAAction","http://acordosplanoseconomicos.febraban.org.br/IAcordoService/CadastrarResultadoAnalisePedido");
        _cadastrarResultadoAnalisePedidoOperation0.setOption("portTypeQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "IAcordoService"));
        _cadastrarResultadoAnalisePedidoOperation0.setOption("outputWSAAction","http://acordosplanoseconomicos.febraban.org.br/IAcordoService/CadastrarResultadoAnalisePedidoResponse");
        _cadastrarResultadoAnalisePedidoOperation0.setOption("ServiceQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "AcordoPlanoEconomicosService"));
        _cadastrarResultadoAnalisePedidoOperation0.setOption("ResponseLocalPart","CadastrarResultadoAnalisePedidoResponse");
        _cadastrarResultadoAnalisePedidoOperation0.setOption("inputMessageQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "IAcordoService_CadastrarResultadoAnalisePedido_InputMessage"));
        _cadastrarResultadoAnalisePedidoOperation0.setUse(com.ibm.ws.webservices.engine.enumtype.Use.LITERAL);
        _cadastrarResultadoAnalisePedidoOperation0.setStyle(com.ibm.ws.webservices.engine.enumtype.Style.WRAPPED);
        return _cadastrarResultadoAnalisePedidoOperation0;

    }

    private int _cadastrarResultadoAnalisePedidoIndex0 = 0;
    private synchronized com.ibm.ws.webservices.engine.client.Stub.Invoke _getcadastrarResultadoAnalisePedidoInvoke0(Object[] parameters) throws com.ibm.ws.webservices.engine.WebServicesFault  {
        com.ibm.ws.webservices.engine.MessageContext mc = super.messageContexts[_cadastrarResultadoAnalisePedidoIndex0];
        if (mc == null) {
            mc = new com.ibm.ws.webservices.engine.MessageContext(super.engine);
            mc.setOperation(AcordoStub._cadastrarResultadoAnalisePedidoOperation0);
            mc.setUseSOAPAction(true);
            mc.setSOAPActionURI("http://acordosplanoseconomicos.febraban.org.br/IAcordoService/CadastrarResultadoAnalisePedido");
            mc.setEncodingStyle(com.ibm.ws.webservices.engine.Constants.URI_LITERAL_ENC);
            mc.setProperty(com.ibm.wsspi.webservices.Constants.SEND_TYPE_ATTR_PROPERTY, Boolean.FALSE);
            mc.setProperty(com.ibm.wsspi.webservices.Constants.ENGINE_DO_MULTI_REFS_PROPERTY, Boolean.FALSE);
            super.primeMessageContext(mc);
            super.messageContexts[_cadastrarResultadoAnalisePedidoIndex0] = mc;
        }
        try {
            mc = (com.ibm.ws.webservices.engine.MessageContext) mc.clone();
        }
        catch (CloneNotSupportedException cnse) {
            throw com.ibm.ws.webservices.engine.WebServicesFault.makeFault(cnse);
        }
        return new com.ibm.ws.webservices.engine.client.Stub.Invoke(connection, mc, parameters);
    }

    public br.org.febraban.acordosplanoseconomicos.RespostaOperacao cadastrarResultadoAnalisePedido(br.org.febraban.acordosplanoseconomicos.ResultadoAnalisePedido resultadoAnalisePedido) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new com.ibm.ws.webservices.engine.NoEndPointException();
        }
        java.util.Vector _resp = null;
        try {
            _resp = _getcadastrarResultadoAnalisePedidoInvoke0(new java.lang.Object[] {resultadoAnalisePedido}).invoke();

        } catch (com.ibm.ws.webservices.engine.WebServicesFault wsf) {
            Exception e = wsf.getUserException();
            throw wsf;
        } 
        try {
            return (br.org.febraban.acordosplanoseconomicos.RespostaOperacao) ((com.ibm.ws.webservices.engine.xmlsoap.ext.ParamValue) _resp.get(0)).getValue();
        } catch (java.lang.Exception _exception) {
            return (br.org.febraban.acordosplanoseconomicos.RespostaOperacao) super.convert(((com.ibm.ws.webservices.engine.xmlsoap.ext.ParamValue) _resp.get(0)).getValue(), br.org.febraban.acordosplanoseconomicos.RespostaOperacao.class);
        }
    }

    private static com.ibm.ws.webservices.engine.description.OperationDesc _obterRespostaPropostaOperation1 = null;
    private static com.ibm.ws.webservices.engine.description.OperationDesc _getobterRespostaPropostaOperation1() {
        com.ibm.ws.webservices.engine.description.ParameterDesc[]  _params1 = new com.ibm.ws.webservices.engine.description.ParameterDesc[] {
         new com.ibm.ws.webservices.engine.description.ParameterDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "filtro"), com.ibm.ws.webservices.engine.description.ParameterDesc.IN, com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/acordos/filtros", "RespostaPropostaFiltro"), br.org.febraban.acordosplanoseconomicos.RespostaPropostaFiltro.class, false, false, false, true, true, false), 
          };
        _params1[0].setOption("partQNameString","{http://acordosplanoseconomicos.febraban.org.br/contratos/acordos/filtros}RespostaPropostaFiltro");
        _params1[0].setOption("inputPosition","0");
        _params1[0].setOption("partName","RespostaPropostaFiltro");
        com.ibm.ws.webservices.engine.description.ParameterDesc  _returnDesc1 = new com.ibm.ws.webservices.engine.description.ParameterDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "ObterRespostaPropostaResult"), com.ibm.ws.webservices.engine.description.ParameterDesc.OUT, com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/acordos", "ArrayOfAceiteProposta"), br.org.febraban.acordosplanoseconomicos.AceiteProposta[].class, true, false, false, true, true, false); 
        _returnDesc1.setOption("partQNameString","{http://acordosplanoseconomicos.febraban.org.br/contratos/acordos}ArrayOfAceiteProposta");
        _returnDesc1.setOption("outputPosition","0");
        _returnDesc1.setOption("partName","ArrayOfAceiteProposta");
        com.ibm.ws.webservices.engine.description.FaultDesc[]  _faults1 = new com.ibm.ws.webservices.engine.description.FaultDesc[] {
          };
        _obterRespostaPropostaOperation1 = new com.ibm.ws.webservices.engine.description.OperationDesc("obterRespostaProposta", com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "ObterRespostaProposta"), _params1, _returnDesc1, _faults1, "http://acordosplanoseconomicos.febraban.org.br/IAcordoService/ObterRespostaProposta");
        _obterRespostaPropostaOperation1.setOption("buildNum","cf031428.03");
        _obterRespostaPropostaOperation1.setOption("ResponseNamespace","http://acordosplanoseconomicos.febraban.org.br");
        _obterRespostaPropostaOperation1.setOption("targetNamespace","http://acordosplanoseconomicos.febraban.org.br");
        _obterRespostaPropostaOperation1.setOption("outputMessageQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "IAcordoService_ObterRespostaProposta_OutputMessage"));
        _obterRespostaPropostaOperation1.setOption("inputWSAAction","http://acordosplanoseconomicos.febraban.org.br/IAcordoService/ObterRespostaProposta");
        _obterRespostaPropostaOperation1.setOption("portTypeQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "IAcordoService"));
        _obterRespostaPropostaOperation1.setOption("outputWSAAction","http://acordosplanoseconomicos.febraban.org.br/IAcordoService/ObterRespostaPropostaResponse");
        _obterRespostaPropostaOperation1.setOption("ServiceQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "AcordoPlanoEconomicosService"));
        _obterRespostaPropostaOperation1.setOption("ResponseLocalPart","ObterRespostaPropostaResponse");
        _obterRespostaPropostaOperation1.setOption("inputMessageQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "IAcordoService_ObterRespostaProposta_InputMessage"));
        _obterRespostaPropostaOperation1.setUse(com.ibm.ws.webservices.engine.enumtype.Use.LITERAL);
        _obterRespostaPropostaOperation1.setStyle(com.ibm.ws.webservices.engine.enumtype.Style.WRAPPED);
        return _obterRespostaPropostaOperation1;

    }

    private int _obterRespostaPropostaIndex1 = 1;
    private synchronized com.ibm.ws.webservices.engine.client.Stub.Invoke _getobterRespostaPropostaInvoke1(Object[] parameters) throws com.ibm.ws.webservices.engine.WebServicesFault  {
        com.ibm.ws.webservices.engine.MessageContext mc = super.messageContexts[_obterRespostaPropostaIndex1];
        if (mc == null) {
            mc = new com.ibm.ws.webservices.engine.MessageContext(super.engine);
            mc.setOperation(AcordoStub._obterRespostaPropostaOperation1);
            mc.setUseSOAPAction(true);
            mc.setSOAPActionURI("http://acordosplanoseconomicos.febraban.org.br/IAcordoService/ObterRespostaProposta");
            mc.setEncodingStyle(com.ibm.ws.webservices.engine.Constants.URI_LITERAL_ENC);
            mc.setProperty(com.ibm.wsspi.webservices.Constants.SEND_TYPE_ATTR_PROPERTY, Boolean.FALSE);
            mc.setProperty(com.ibm.wsspi.webservices.Constants.ENGINE_DO_MULTI_REFS_PROPERTY, Boolean.FALSE);
            super.primeMessageContext(mc);
            super.messageContexts[_obterRespostaPropostaIndex1] = mc;
        }
        try {
            mc = (com.ibm.ws.webservices.engine.MessageContext) mc.clone();
        }
        catch (CloneNotSupportedException cnse) {
            throw com.ibm.ws.webservices.engine.WebServicesFault.makeFault(cnse);
        }
        return new com.ibm.ws.webservices.engine.client.Stub.Invoke(connection, mc, parameters);
    }

    public br.org.febraban.acordosplanoseconomicos.AceiteProposta[] obterRespostaProposta(br.org.febraban.acordosplanoseconomicos.RespostaPropostaFiltro filtro) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new com.ibm.ws.webservices.engine.NoEndPointException();
        }
        java.util.Vector _resp = null;
        try {
            _resp = _getobterRespostaPropostaInvoke1(new java.lang.Object[] {filtro}).invoke();

        } catch (com.ibm.ws.webservices.engine.WebServicesFault wsf) {
            Exception e = wsf.getUserException();
            throw wsf;
        } 
        try {
            return (br.org.febraban.acordosplanoseconomicos.AceiteProposta[]) ((com.ibm.ws.webservices.engine.xmlsoap.ext.ParamValue) _resp.get(0)).getValue();
        } catch (java.lang.Exception _exception) {
            return (br.org.febraban.acordosplanoseconomicos.AceiteProposta[]) super.convert(((com.ibm.ws.webservices.engine.xmlsoap.ext.ParamValue) _resp.get(0)).getValue(), br.org.febraban.acordosplanoseconomicos.AceiteProposta[].class);
        }
    }

    private static com.ibm.ws.webservices.engine.description.OperationDesc _informarPagamentoOperation2 = null;
    private static com.ibm.ws.webservices.engine.description.OperationDesc _getinformarPagamentoOperation2() {
        com.ibm.ws.webservices.engine.description.ParameterDesc[]  _params2 = new com.ibm.ws.webservices.engine.description.ParameterDesc[] {
         new com.ibm.ws.webservices.engine.description.ParameterDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "pagamento"), com.ibm.ws.webservices.engine.description.ParameterDesc.IN, com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/acordos", "PagamentoAcordo"), br.org.febraban.acordosplanoseconomicos.PagamentoAcordo.class, false, false, false, true, true, false), 
          };
        _params2[0].setOption("partQNameString","{http://acordosplanoseconomicos.febraban.org.br/contratos/acordos}PagamentoAcordo");
        _params2[0].setOption("inputPosition","0");
        _params2[0].setOption("partName","PagamentoAcordo");
        com.ibm.ws.webservices.engine.description.ParameterDesc  _returnDesc2 = new com.ibm.ws.webservices.engine.description.ParameterDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "InformarPagamentoResult"), com.ibm.ws.webservices.engine.description.ParameterDesc.OUT, com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "RespostaOperacao"), br.org.febraban.acordosplanoseconomicos.RespostaOperacao.class, true, false, false, true, true, false); 
        _returnDesc2.setOption("partQNameString","{http://acordosplanoseconomicos.febraban.org.br}RespostaOperacao");
        _returnDesc2.setOption("outputPosition","0");
        _returnDesc2.setOption("partName","RespostaOperacao");
        com.ibm.ws.webservices.engine.description.FaultDesc[]  _faults2 = new com.ibm.ws.webservices.engine.description.FaultDesc[] {
          };
        _informarPagamentoOperation2 = new com.ibm.ws.webservices.engine.description.OperationDesc("informarPagamento", com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "InformarPagamento"), _params2, _returnDesc2, _faults2, "http://acordosplanoseconomicos.febraban.org.br/IAcordoService/InformarPagamento");
        _informarPagamentoOperation2.setOption("buildNum","cf031428.03");
        _informarPagamentoOperation2.setOption("ResponseNamespace","http://acordosplanoseconomicos.febraban.org.br");
        _informarPagamentoOperation2.setOption("targetNamespace","http://acordosplanoseconomicos.febraban.org.br");
        _informarPagamentoOperation2.setOption("outputMessageQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "IAcordoService_InformarPagamento_OutputMessage"));
        _informarPagamentoOperation2.setOption("inputWSAAction","http://acordosplanoseconomicos.febraban.org.br/IAcordoService/InformarPagamento");
        _informarPagamentoOperation2.setOption("portTypeQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "IAcordoService"));
        _informarPagamentoOperation2.setOption("outputWSAAction","http://acordosplanoseconomicos.febraban.org.br/IAcordoService/InformarPagamentoResponse");
        _informarPagamentoOperation2.setOption("ServiceQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "AcordoPlanoEconomicosService"));
        _informarPagamentoOperation2.setOption("ResponseLocalPart","InformarPagamentoResponse");
        _informarPagamentoOperation2.setOption("inputMessageQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "IAcordoService_InformarPagamento_InputMessage"));
        _informarPagamentoOperation2.setUse(com.ibm.ws.webservices.engine.enumtype.Use.LITERAL);
        _informarPagamentoOperation2.setStyle(com.ibm.ws.webservices.engine.enumtype.Style.WRAPPED);
        return _informarPagamentoOperation2;

    }

    private int _informarPagamentoIndex2 = 2;
    private synchronized com.ibm.ws.webservices.engine.client.Stub.Invoke _getinformarPagamentoInvoke2(Object[] parameters) throws com.ibm.ws.webservices.engine.WebServicesFault  {
        com.ibm.ws.webservices.engine.MessageContext mc = super.messageContexts[_informarPagamentoIndex2];
        if (mc == null) {
            mc = new com.ibm.ws.webservices.engine.MessageContext(super.engine);
            mc.setOperation(AcordoStub._informarPagamentoOperation2);
            mc.setUseSOAPAction(true);
            mc.setSOAPActionURI("http://acordosplanoseconomicos.febraban.org.br/IAcordoService/InformarPagamento");
            mc.setEncodingStyle(com.ibm.ws.webservices.engine.Constants.URI_LITERAL_ENC);
            mc.setProperty(com.ibm.wsspi.webservices.Constants.SEND_TYPE_ATTR_PROPERTY, Boolean.FALSE);
            mc.setProperty(com.ibm.wsspi.webservices.Constants.ENGINE_DO_MULTI_REFS_PROPERTY, Boolean.FALSE);
            super.primeMessageContext(mc);
            super.messageContexts[_informarPagamentoIndex2] = mc;
        }
        try {
            mc = (com.ibm.ws.webservices.engine.MessageContext) mc.clone();
        }
        catch (CloneNotSupportedException cnse) {
            throw com.ibm.ws.webservices.engine.WebServicesFault.makeFault(cnse);
        }
        return new com.ibm.ws.webservices.engine.client.Stub.Invoke(connection, mc, parameters);
    }

    public br.org.febraban.acordosplanoseconomicos.RespostaOperacao informarPagamento(br.org.febraban.acordosplanoseconomicos.PagamentoAcordo pagamento) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new com.ibm.ws.webservices.engine.NoEndPointException();
        }
        java.util.Vector _resp = null;
        try {
            _resp = _getinformarPagamentoInvoke2(new java.lang.Object[] {pagamento}).invoke();

        } catch (com.ibm.ws.webservices.engine.WebServicesFault wsf) {
            Exception e = wsf.getUserException();
            throw wsf;
        } 
        try {
            return (br.org.febraban.acordosplanoseconomicos.RespostaOperacao) ((com.ibm.ws.webservices.engine.xmlsoap.ext.ParamValue) _resp.get(0)).getValue();
        } catch (java.lang.Exception _exception) {
            return (br.org.febraban.acordosplanoseconomicos.RespostaOperacao) super.convert(((com.ibm.ws.webservices.engine.xmlsoap.ext.ParamValue) _resp.get(0)).getValue(), br.org.febraban.acordosplanoseconomicos.RespostaOperacao.class);
        }
    }

    private static void _staticInit() {
        _cadastrarResultadoAnalisePedidoOperation0 = _getcadastrarResultadoAnalisePedidoOperation0();
        _obterRespostaPropostaOperation1 = _getobterRespostaPropostaOperation1();
        _informarPagamentoOperation2 = _getinformarPagamentoOperation2();
    }

    static {
       _staticInit();
    }
}
