/**
 * Advogado.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf031428.03 v72314182347
 */

package br.org.febraban.acordosplanoseconomicos;

public class Advogado  {
    private int id;
    private java.lang.String CPF;
    private java.lang.String nome;
    private br.org.febraban.acordosplanoseconomicos.IdentidadePatrono OAB;
    private br.org.febraban.acordosplanoseconomicos.IdentidadePatrono OABSuplementar;
    private br.org.febraban.acordosplanoseconomicos.IdentidadePatrono matriculaDefensor;
    private br.org.febraban.acordosplanoseconomicos.Contato contato;
    private br.org.febraban.acordosplanoseconomicos.QualificacaoPatronoEnum qualificacaoPatrono;

    public Advogado() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public java.lang.String getCPF() {
        return CPF;
    }

    public void setCPF(java.lang.String CPF) {
        this.CPF = CPF;
    }

    public java.lang.String getNome() {
        return nome;
    }

    public void setNome(java.lang.String nome) {
        this.nome = nome;
    }

    public br.org.febraban.acordosplanoseconomicos.IdentidadePatrono getOAB() {
        return OAB;
    }

    public void setOAB(br.org.febraban.acordosplanoseconomicos.IdentidadePatrono OAB) {
        this.OAB = OAB;
    }

    public br.org.febraban.acordosplanoseconomicos.IdentidadePatrono getOABSuplementar() {
        return OABSuplementar;
    }

    public void setOABSuplementar(br.org.febraban.acordosplanoseconomicos.IdentidadePatrono OABSuplementar) {
        this.OABSuplementar = OABSuplementar;
    }

    public br.org.febraban.acordosplanoseconomicos.IdentidadePatrono getMatriculaDefensor() {
        return matriculaDefensor;
    }

    public void setMatriculaDefensor(br.org.febraban.acordosplanoseconomicos.IdentidadePatrono matriculaDefensor) {
        this.matriculaDefensor = matriculaDefensor;
    }

    public br.org.febraban.acordosplanoseconomicos.Contato getContato() {
        return contato;
    }

    public void setContato(br.org.febraban.acordosplanoseconomicos.Contato contato) {
        this.contato = contato;
    }

    public br.org.febraban.acordosplanoseconomicos.QualificacaoPatronoEnum getQualificacaoPatrono() {
        return qualificacaoPatrono;
    }

    public void setQualificacaoPatrono(br.org.febraban.acordosplanoseconomicos.QualificacaoPatronoEnum qualificacaoPatrono) {
        this.qualificacaoPatrono = qualificacaoPatrono;
    }

}
