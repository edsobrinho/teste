/**
 * Advogado_Deser.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf031428.03 v72314182347
 */

package br.org.febraban.acordosplanoseconomicos;

public class Advogado_Deser extends com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializer {
    /**
     * Constructor
     */
    public Advogado_Deser(
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType, 
           com.ibm.ws.webservices.engine.description.TypeDesc _typeDesc) {
        super(_javaType, _xmlType, _typeDesc);
    }
    /**
     * Create instance of java bean
     */
    public void createValue() {
        value = new Advogado();
    }
    protected boolean tryElementSetFromString(javax.xml.namespace.QName qName, java.lang.String strValue) {
        if (qName==QName_4_66) {
          ((Advogado)value).setId(com.ibm.ws.webservices.engine.encoding.ser.SimpleDeserializer.parseint(strValue));
          return true;}
        else if (qName==QName_4_79) {
          ((Advogado)value).setCPF(strValue);
          return true;}
        else if (qName==QName_4_68) {
          ((Advogado)value).setNome(strValue);
          return true;}
        return false;
    }
    protected boolean tryAttributeSetFromString(javax.xml.namespace.QName qName, java.lang.String strValue) {
        return false;
    }
    protected boolean tryElementSetFromObject(javax.xml.namespace.QName qName, java.lang.Object objValue) {
        if (qName==QName_4_80) {
          ((Advogado)value).setOAB((br.org.febraban.acordosplanoseconomicos.IdentidadePatrono)objValue);
          return true;}
        else if (qName==QName_4_81) {
          ((Advogado)value).setOABSuplementar((br.org.febraban.acordosplanoseconomicos.IdentidadePatrono)objValue);
          return true;}
        else if (qName==QName_4_82) {
          ((Advogado)value).setMatriculaDefensor((br.org.febraban.acordosplanoseconomicos.IdentidadePatrono)objValue);
          return true;}
        else if (qName==QName_4_74) {
          ((Advogado)value).setContato((br.org.febraban.acordosplanoseconomicos.Contato)objValue);
          return true;}
        else if (qName==QName_4_83) {
          ((Advogado)value).setQualificacaoPatrono((br.org.febraban.acordosplanoseconomicos.QualificacaoPatronoEnum)objValue);
          return true;}
        return false;
    }
    protected boolean tryElementSetFromList(javax.xml.namespace.QName qName, java.util.List listValue) {
        return false;
    }
    private final static javax.xml.namespace.QName QName_4_83 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "QualificacaoPatrono");
    private final static javax.xml.namespace.QName QName_4_68 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "Nome");
    private final static javax.xml.namespace.QName QName_4_82 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "MatriculaDefensor");
    private final static javax.xml.namespace.QName QName_4_80 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "OAB");
    private final static javax.xml.namespace.QName QName_4_81 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "OABSuplementar");
    private final static javax.xml.namespace.QName QName_4_74 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "Contato");
    private final static javax.xml.namespace.QName QName_4_66 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "Id");
    private final static javax.xml.namespace.QName QName_4_79 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "CPF");
}
