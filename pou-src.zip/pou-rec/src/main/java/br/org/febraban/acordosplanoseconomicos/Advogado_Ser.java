/**
 * Advogado_Ser.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf031428.03 v72314182347
 */

package br.org.febraban.acordosplanoseconomicos;

public class Advogado_Ser extends com.ibm.ws.webservices.engine.encoding.ser.BeanSerializer {
    /**
     * Constructor
     */
    public Advogado_Ser(
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType, 
           com.ibm.ws.webservices.engine.description.TypeDesc _typeDesc) {
        super(_javaType, _xmlType, _typeDesc);
    }
    public void serialize(
        javax.xml.namespace.QName name,
        org.xml.sax.Attributes attributes,
        java.lang.Object value,
        com.ibm.ws.webservices.engine.encoding.SerializationContext context)
        throws java.io.IOException
    {
        context.startElement(name, addAttributes(attributes, value, context));
        addElements(value, context);
        context.endElement();
    }
    protected org.xml.sax.Attributes addAttributes(
        org.xml.sax.Attributes attributes,
        java.lang.Object value,
        com.ibm.ws.webservices.engine.encoding.SerializationContext context)
        throws java.io.IOException
    {
           javax.xml.namespace.QName
           elemQName = QName_4_66;
           context.qName2String(elemQName, true);
           elemQName = QName_4_79;
           context.qName2String(elemQName, true);
           elemQName = QName_4_68;
           context.qName2String(elemQName, true);
           elemQName = QName_4_80;
           context.qName2String(elemQName, true);
           elemQName = QName_4_81;
           context.qName2String(elemQName, true);
           elemQName = QName_4_82;
           context.qName2String(elemQName, true);
           elemQName = QName_4_74;
           context.qName2String(elemQName, true);
           elemQName = QName_4_83;
           context.qName2String(elemQName, true);
        return attributes;
    }
    protected void addElements(
        java.lang.Object value,
        com.ibm.ws.webservices.engine.encoding.SerializationContext context)
        throws java.io.IOException
    {
        Advogado bean = (Advogado) value;
        java.lang.Object propValue;
        javax.xml.namespace.QName propQName;
        {
          propQName = QName_4_66;
          propValue = new java.lang.Integer(bean.getId());
          serializeChild(propQName, null, 
              propValue, 
              QName_1_6,
              true,null,context);
          propQName = QName_4_79;
          propValue = bean.getCPF();
          if (propValue != null && !context.shouldSendXSIType()) {
            context.simpleElement(propQName, null, propValue.toString()); 
          } else {
            serializeChild(propQName, null, 
              propValue, 
              QName_1_5,
              true,null,context);
          }
          propQName = QName_4_68;
          propValue = bean.getNome();
          if (propValue != null && !context.shouldSendXSIType()) {
            context.simpleElement(propQName, null, propValue.toString()); 
          } else {
            serializeChild(propQName, null, 
              propValue, 
              QName_1_5,
              true,null,context);
          }
          propQName = QName_4_80;
          propValue = bean.getOAB();
          serializeChild(propQName, null, 
              propValue, 
              QName_15_84,
              false,null,context);
          propQName = QName_4_81;
          propValue = bean.getOABSuplementar();
          serializeChild(propQName, null, 
              propValue, 
              QName_15_84,
              false,null,context);
          propQName = QName_4_82;
          propValue = bean.getMatriculaDefensor();
          serializeChild(propQName, null, 
              propValue, 
              QName_15_84,
              false,null,context);
          propQName = QName_4_74;
          propValue = bean.getContato();
          serializeChild(propQName, null, 
              propValue, 
              QName_4_74,
              true,null,context);
          propQName = QName_4_83;
          propValue = bean.getQualificacaoPatrono();
          serializeChild(propQName, null, 
              propValue, 
              QName_2_85,
              true,null,context);
        }
    }
    private final static javax.xml.namespace.QName QName_15_84 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/tipos",
                  "IdentidadePatrono");
    private final static javax.xml.namespace.QName QName_4_81 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "OABSuplementar");
    private final static javax.xml.namespace.QName QName_1_6 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://www.w3.org/2001/XMLSchema",
                  "int");
    private final static javax.xml.namespace.QName QName_2_85 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/enums",
                  "QualificacaoPatronoEnum");
    private final static javax.xml.namespace.QName QName_4_68 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "Nome");
    private final static javax.xml.namespace.QName QName_4_66 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "Id");
    private final static javax.xml.namespace.QName QName_1_5 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://www.w3.org/2001/XMLSchema",
                  "string");
    private final static javax.xml.namespace.QName QName_4_79 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "CPF");
    private final static javax.xml.namespace.QName QName_4_83 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "QualificacaoPatrono");
    private final static javax.xml.namespace.QName QName_4_82 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "MatriculaDefensor");
    private final static javax.xml.namespace.QName QName_4_74 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "Contato");
    private final static javax.xml.namespace.QName QName_4_80 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "OAB");
}
