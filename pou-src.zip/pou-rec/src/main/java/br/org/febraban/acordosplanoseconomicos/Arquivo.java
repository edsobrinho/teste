/**
 * Arquivo.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf031428.03 v72314182347
 */

package br.org.febraban.acordosplanoseconomicos;

public class Arquivo  {
    private java.lang.String guidPedido;
    private int identificadorDocumento;
    private java.lang.String nomeArquivo;
    private java.lang.String conteudo;

    public Arquivo() {
    }

    public java.lang.String getGuidPedido() {
        return guidPedido;
    }

    public void setGuidPedido(java.lang.String guidPedido) {
        this.guidPedido = guidPedido;
    }

    public int getIdentificadorDocumento() {
        return identificadorDocumento;
    }

    public void setIdentificadorDocumento(int identificadorDocumento) {
        this.identificadorDocumento = identificadorDocumento;
    }

    public java.lang.String getNomeArquivo() {
        return nomeArquivo;
    }

    public void setNomeArquivo(java.lang.String nomeArquivo) {
        this.nomeArquivo = nomeArquivo;
    }

    public java.lang.String getConteudo() {
        return conteudo;
    }

    public void setConteudo(java.lang.String conteudo) {
        this.conteudo = conteudo;
    }

}
