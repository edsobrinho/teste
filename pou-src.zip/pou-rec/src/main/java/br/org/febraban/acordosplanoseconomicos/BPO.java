/**
 * BPO.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf031428.03 v72314182347
 */

package br.org.febraban.acordosplanoseconomicos;

public class BPO  {
    private java.lang.String GUIDPedido;
    private int sequencialAnaliseBPO;
    private int identificadorAnaliseBPO;
    private java.lang.String dataSubmissaoBPO;
    private java.lang.String dataLiberacaoBPO;
    private br.org.febraban.acordosplanoseconomicos.ResultadoAnaliseBPO[] itensBPO;

    public BPO() {
    }

    public java.lang.String getGUIDPedido() {
        return GUIDPedido;
    }

    public void setGUIDPedido(java.lang.String GUIDPedido) {
        this.GUIDPedido = GUIDPedido;
    }

    public int getSequencialAnaliseBPO() {
        return sequencialAnaliseBPO;
    }

    public void setSequencialAnaliseBPO(int sequencialAnaliseBPO) {
        this.sequencialAnaliseBPO = sequencialAnaliseBPO;
    }

    public int getIdentificadorAnaliseBPO() {
        return identificadorAnaliseBPO;
    }

    public void setIdentificadorAnaliseBPO(int identificadorAnaliseBPO) {
        this.identificadorAnaliseBPO = identificadorAnaliseBPO;
    }

    public java.lang.String getDataSubmissaoBPO() {
        return dataSubmissaoBPO;
    }

    public void setDataSubmissaoBPO(java.lang.String dataSubmissaoBPO) {
        this.dataSubmissaoBPO = dataSubmissaoBPO;
    }

    public java.lang.String getDataLiberacaoBPO() {
        return dataLiberacaoBPO;
    }

    public void setDataLiberacaoBPO(java.lang.String dataLiberacaoBPO) {
        this.dataLiberacaoBPO = dataLiberacaoBPO;
    }

    public br.org.febraban.acordosplanoseconomicos.ResultadoAnaliseBPO[] getItensBPO() {
        return itensBPO;
    }

    public void setItensBPO(br.org.febraban.acordosplanoseconomicos.ResultadoAnaliseBPO[] itensBPO) {
        this.itensBPO = itensBPO;
    }

}
