/**
 * BPO_Deser.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf031428.03 v72314182347
 */

package br.org.febraban.acordosplanoseconomicos;

public class BPO_Deser extends com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializer {
    /**
     * Constructor
     */
    public BPO_Deser(
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType, 
           com.ibm.ws.webservices.engine.description.TypeDesc _typeDesc) {
        super(_javaType, _xmlType, _typeDesc);
    }
    /**
     * Create instance of java bean
     */
    public void createValue() {
        value = new BPO();
    }
    protected boolean tryElementSetFromString(javax.xml.namespace.QName qName, java.lang.String strValue) {
        if (qName==QName_4_103) {
          ((BPO)value).setGUIDPedido(strValue);
          return true;}
        else if (qName==QName_4_104) {
          ((BPO)value).setSequencialAnaliseBPO(com.ibm.ws.webservices.engine.encoding.ser.SimpleDeserializer.parseint(strValue));
          return true;}
        else if (qName==QName_4_105) {
          ((BPO)value).setIdentificadorAnaliseBPO(com.ibm.ws.webservices.engine.encoding.ser.SimpleDeserializer.parseint(strValue));
          return true;}
        else if (qName==QName_4_106) {
          ((BPO)value).setDataSubmissaoBPO(strValue);
          return true;}
        else if (qName==QName_4_107) {
          ((BPO)value).setDataLiberacaoBPO(strValue);
          return true;}
        return false;
    }
    protected boolean tryAttributeSetFromString(javax.xml.namespace.QName qName, java.lang.String strValue) {
        return false;
    }
    protected boolean tryElementSetFromObject(javax.xml.namespace.QName qName, java.lang.Object objValue) {
        if (qName==QName_4_108) {
          if (objValue instanceof java.util.List) {
            br.org.febraban.acordosplanoseconomicos.ResultadoAnaliseBPO[] array = new br.org.febraban.acordosplanoseconomicos.ResultadoAnaliseBPO[((java.util.List)objValue).size()];
            ((java.util.List)objValue).toArray(array);
            ((BPO)value).setItensBPO(array);
          } else { 
            ((BPO)value).setItensBPO((br.org.febraban.acordosplanoseconomicos.ResultadoAnaliseBPO[])objValue);}
          return true;}
        return false;
    }
    protected boolean tryElementSetFromList(javax.xml.namespace.QName qName, java.util.List listValue) {
        return false;
    }
    private final static javax.xml.namespace.QName QName_4_105 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "IdentificadorAnaliseBPO");
    private final static javax.xml.namespace.QName QName_4_104 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "SequencialAnaliseBPO");
    private final static javax.xml.namespace.QName QName_4_106 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "DataSubmissaoBPO");
    private final static javax.xml.namespace.QName QName_4_107 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "DataLiberacaoBPO");
    private final static javax.xml.namespace.QName QName_4_108 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "ItensBPO");
    private final static javax.xml.namespace.QName QName_4_103 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "GUIDPedido");
}
