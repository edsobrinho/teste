/**
 * BPO_Ser.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf031428.03 v72314182347
 */

package br.org.febraban.acordosplanoseconomicos;

public class BPO_Ser extends com.ibm.ws.webservices.engine.encoding.ser.BeanSerializer {
    /**
     * Constructor
     */
    public BPO_Ser(
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType, 
           com.ibm.ws.webservices.engine.description.TypeDesc _typeDesc) {
        super(_javaType, _xmlType, _typeDesc);
    }
    public void serialize(
        javax.xml.namespace.QName name,
        org.xml.sax.Attributes attributes,
        java.lang.Object value,
        com.ibm.ws.webservices.engine.encoding.SerializationContext context)
        throws java.io.IOException
    {
        context.startElement(name, addAttributes(attributes, value, context));
        addElements(value, context);
        context.endElement();
    }
    protected org.xml.sax.Attributes addAttributes(
        org.xml.sax.Attributes attributes,
        java.lang.Object value,
        com.ibm.ws.webservices.engine.encoding.SerializationContext context)
        throws java.io.IOException
    {
           javax.xml.namespace.QName
           elemQName = QName_4_103;
           context.qName2String(elemQName, true);
           elemQName = QName_4_104;
           context.qName2String(elemQName, true);
           elemQName = QName_4_105;
           context.qName2String(elemQName, true);
           elemQName = QName_4_106;
           context.qName2String(elemQName, true);
           elemQName = QName_4_107;
           context.qName2String(elemQName, true);
           elemQName = QName_4_108;
           context.qName2String(elemQName, true);
        return attributes;
    }
    protected void addElements(
        java.lang.Object value,
        com.ibm.ws.webservices.engine.encoding.SerializationContext context)
        throws java.io.IOException
    {
        BPO bean = (BPO) value;
        java.lang.Object propValue;
        javax.xml.namespace.QName propQName;
        {
          propQName = QName_4_103;
          propValue = bean.getGUIDPedido();
          if (propValue != null && !context.shouldSendXSIType()) {
            context.simpleElement(propQName, null, propValue.toString()); 
          } else {
            serializeChild(propQName, null, 
              propValue, 
              QName_14_58,
              true,null,context);
          }
          propQName = QName_4_104;
          propValue = new java.lang.Integer(bean.getSequencialAnaliseBPO());
          serializeChild(propQName, null, 
              propValue, 
              QName_1_6,
              true,null,context);
          propQName = QName_4_105;
          propValue = new java.lang.Integer(bean.getIdentificadorAnaliseBPO());
          serializeChild(propQName, null, 
              propValue, 
              QName_1_6,
              true,null,context);
          propQName = QName_4_106;
          propValue = bean.getDataSubmissaoBPO();
          if (propValue != null && !context.shouldSendXSIType()) {
            context.simpleElement(propQName, null, propValue.toString()); 
          } else {
            serializeChild(propQName, null, 
              propValue, 
              QName_1_5,
              true,null,context);
          }
          propQName = QName_4_107;
          propValue = bean.getDataLiberacaoBPO();
          if (propValue != null && !context.shouldSendXSIType()) {
            context.simpleElement(propQName, null, propValue.toString()); 
          } else {
            serializeChild(propQName, null, 
              propValue, 
              QName_1_5,
              true,null,context);
          }
          propQName = QName_4_108;
          propValue = bean.getItensBPO();
          serializeChild(propQName, null, 
              propValue, 
              QName_4_109,
              true,null,context);
        }
    }
    private final static javax.xml.namespace.QName QName_1_6 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://www.w3.org/2001/XMLSchema",
                  "int");
    private final static javax.xml.namespace.QName QName_4_109 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "ArrayOfResultadoAnaliseBPO");
    private final static javax.xml.namespace.QName QName_14_58 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://schemas.microsoft.com/2003/10/Serialization/",
                  "guid");
    private final static javax.xml.namespace.QName QName_4_108 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "ItensBPO");
    private final static javax.xml.namespace.QName QName_4_106 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "DataSubmissaoBPO");
    private final static javax.xml.namespace.QName QName_4_107 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "DataLiberacaoBPO");
    private final static javax.xml.namespace.QName QName_4_104 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "SequencialAnaliseBPO");
    private final static javax.xml.namespace.QName QName_4_105 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "IdentificadorAnaliseBPO");
    private final static javax.xml.namespace.QName QName_4_103 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "GUIDPedido");
    private final static javax.xml.namespace.QName QName_1_5 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://www.w3.org/2001/XMLSchema",
                  "string");
}
