/**
 * ConfirmacaoPedidosRecebidos.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf031428.03 v72314182347
 */

package br.org.febraban.acordosplanoseconomicos;

public class ConfirmacaoPedidosRecebidos  {
    private java.lang.String[] listaGuidPedidosRecebidos;

    public ConfirmacaoPedidosRecebidos() {
    }

    public java.lang.String[] getListaGuidPedidosRecebidos() {
        return listaGuidPedidosRecebidos;
    }

    public void setListaGuidPedidosRecebidos(java.lang.String[] listaGuidPedidosRecebidos) {
        this.listaGuidPedidosRecebidos = listaGuidPedidosRecebidos;
    }

}
