/**
 * Conta.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf031428.03 v72314182347
 */

package br.org.febraban.acordosplanoseconomicos;

public class Conta  {
    private java.lang.String nomeTitular;
    private java.lang.String cpfCnpj;
    private int banco;
    private java.lang.String nomeBanco;
    private java.lang.String agencia;
    private java.lang.String agenciaDV;
    private java.lang.String numeroConta;
    private java.lang.String numeroContaDV;
    private br.org.febraban.acordosplanoseconomicos.TipoContaEnum tipoConta;

    public Conta() {
    }

    public java.lang.String getNomeTitular() {
        return nomeTitular;
    }

    public void setNomeTitular(java.lang.String nomeTitular) {
        this.nomeTitular = nomeTitular;
    }

    public java.lang.String getCpfCnpj() {
        return cpfCnpj;
    }

    public void setCpfCnpj(java.lang.String cpfCnpj) {
        this.cpfCnpj = cpfCnpj;
    }

    public int getBanco() {
        return banco;
    }

    public void setBanco(int banco) {
        this.banco = banco;
    }

    public java.lang.String getNomeBanco() {
        return nomeBanco;
    }

    public void setNomeBanco(java.lang.String nomeBanco) {
        this.nomeBanco = nomeBanco;
    }

    public java.lang.String getAgencia() {
        return agencia;
    }

    public void setAgencia(java.lang.String agencia) {
        this.agencia = agencia;
    }

    public java.lang.String getAgenciaDV() {
        return agenciaDV;
    }

    public void setAgenciaDV(java.lang.String agenciaDV) {
        this.agenciaDV = agenciaDV;
    }

    public java.lang.String getNumeroConta() {
        return numeroConta;
    }

    public void setNumeroConta(java.lang.String numeroConta) {
        this.numeroConta = numeroConta;
    }

    public java.lang.String getNumeroContaDV() {
        return numeroContaDV;
    }

    public void setNumeroContaDV(java.lang.String numeroContaDV) {
        this.numeroContaDV = numeroContaDV;
    }

    public br.org.febraban.acordosplanoseconomicos.TipoContaEnum getTipoConta() {
        return tipoConta;
    }

    public void setTipoConta(br.org.febraban.acordosplanoseconomicos.TipoContaEnum tipoConta) {
        this.tipoConta = tipoConta;
    }

}
