/**
 * ContaPagamento.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf031428.03 v72314182347
 */

package br.org.febraban.acordosplanoseconomicos;

public class ContaPagamento  {
    private br.org.febraban.acordosplanoseconomicos.Conta contaBancaria;
    private br.org.febraban.acordosplanoseconomicos.DepositoJudicial contaJudicial;

    public ContaPagamento() {
    }

    public br.org.febraban.acordosplanoseconomicos.Conta getContaBancaria() {
        return contaBancaria;
    }

    public void setContaBancaria(br.org.febraban.acordosplanoseconomicos.Conta contaBancaria) {
        this.contaBancaria = contaBancaria;
    }

    public br.org.febraban.acordosplanoseconomicos.DepositoJudicial getContaJudicial() {
        return contaJudicial;
    }

    public void setContaJudicial(br.org.febraban.acordosplanoseconomicos.DepositoJudicial contaJudicial) {
        this.contaJudicial = contaJudicial;
    }

}
