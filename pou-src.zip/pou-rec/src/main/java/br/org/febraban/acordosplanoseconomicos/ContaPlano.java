/**
 * ContaPlano.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf031428.03 v72314182347
 */

package br.org.febraban.acordosplanoseconomicos;

public class ContaPlano  extends br.org.febraban.acordosplanoseconomicos.Conta  {
    private java.lang.Integer id;
    private br.org.febraban.acordosplanoseconomicos.PlanoEnum plano;
    private java.lang.Double saldoBase;
    private java.lang.Double valorSimulado;
    private double diaAniversarioConta;
    private br.org.febraban.acordosplanoseconomicos.Habilitacao[] pedidoEmOutrasHabilitacoes;

    public ContaPlano() {
    }

    public java.lang.Integer getId() {
        return id;
    }

    public void setId(java.lang.Integer id) {
        this.id = id;
    }

    public br.org.febraban.acordosplanoseconomicos.PlanoEnum getPlano() {
        return plano;
    }

    public void setPlano(br.org.febraban.acordosplanoseconomicos.PlanoEnum plano) {
        this.plano = plano;
    }

    public java.lang.Double getSaldoBase() {
        return saldoBase;
    }

    public void setSaldoBase(java.lang.Double saldoBase) {
        this.saldoBase = saldoBase;
    }

    public java.lang.Double getValorSimulado() {
        return valorSimulado;
    }

    public void setValorSimulado(java.lang.Double valorSimulado) {
        this.valorSimulado = valorSimulado;
    }

    public double getDiaAniversarioConta() {
        return diaAniversarioConta;
    }

    public void setDiaAniversarioConta(double diaAniversarioConta) {
        this.diaAniversarioConta = diaAniversarioConta;
    }

    public br.org.febraban.acordosplanoseconomicos.Habilitacao[] getPedidoEmOutrasHabilitacoes() {
        return pedidoEmOutrasHabilitacoes;
    }

    public void setPedidoEmOutrasHabilitacoes(br.org.febraban.acordosplanoseconomicos.Habilitacao[] pedidoEmOutrasHabilitacoes) {
        this.pedidoEmOutrasHabilitacoes = pedidoEmOutrasHabilitacoes;
    }

}
