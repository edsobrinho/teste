/**
 * ContaPlano_Deser.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf031428.03 v72314182347
 */

package br.org.febraban.acordosplanoseconomicos;

public class ContaPlano_Deser extends br.org.febraban.acordosplanoseconomicos.Conta_Deser {
    /**
     * Constructor
     */
    public ContaPlano_Deser(
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType, 
           com.ibm.ws.webservices.engine.description.TypeDesc _typeDesc) {
        super(_javaType, _xmlType, _typeDesc);
    }
    /**
     * Create instance of java bean
     */
    public void createValue() {
        value = new ContaPlano();
    }
    protected boolean tryElementSetFromString(javax.xml.namespace.QName qName, java.lang.String strValue) {
        if (qName==QName_4_66) {
          ((ContaPlano)value).setId(com.ibm.ws.webservices.engine.encoding.ser.SimpleDeserializer.parseInteger(strValue));
          return true;}
        else if (qName==QName_4_142) {
          ((ContaPlano)value).setSaldoBase(com.ibm.ws.webservices.engine.encoding.ser.SimpleDeserializer.parseDouble(strValue));
          return true;}
        else if (qName==QName_4_143) {
          ((ContaPlano)value).setValorSimulado(com.ibm.ws.webservices.engine.encoding.ser.SimpleDeserializer.parseDouble(strValue));
          return true;}
        else if (qName==QName_4_144) {
          ((ContaPlano)value).setDiaAniversarioConta(com.ibm.ws.webservices.engine.encoding.ser.SimpleDeserializer.parsedouble(strValue));
          return true;}
        return super.tryElementSetFromString(qName, strValue);
    }
    protected boolean tryAttributeSetFromString(javax.xml.namespace.QName qName, java.lang.String strValue) {
        return super.tryAttributeSetFromString(qName, strValue);
    }
    protected boolean tryElementSetFromObject(javax.xml.namespace.QName qName, java.lang.Object objValue) {
        if (qName==QName_4_141) {
          ((ContaPlano)value).setPlano((br.org.febraban.acordosplanoseconomicos.PlanoEnum)objValue);
          return true;}
        else if (qName==QName_4_145) {
          if (objValue instanceof java.util.List) {
            br.org.febraban.acordosplanoseconomicos.Habilitacao[] array = new br.org.febraban.acordosplanoseconomicos.Habilitacao[((java.util.List)objValue).size()];
            ((java.util.List)objValue).toArray(array);
            ((ContaPlano)value).setPedidoEmOutrasHabilitacoes(array);
          } else { 
            ((ContaPlano)value).setPedidoEmOutrasHabilitacoes((br.org.febraban.acordosplanoseconomicos.Habilitacao[])objValue);}
          return true;}
        return super.tryElementSetFromObject(qName, objValue);
    }
    protected boolean tryElementSetFromList(javax.xml.namespace.QName qName, java.util.List listValue) {
        return super.tryElementSetFromList(qName, listValue);
    }
    private final static javax.xml.namespace.QName QName_4_141 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "Plano");
    private final static javax.xml.namespace.QName QName_4_144 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "DiaAniversarioConta");
    private final static javax.xml.namespace.QName QName_4_142 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "SaldoBase");
    private final static javax.xml.namespace.QName QName_4_143 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "ValorSimulado");
    private final static javax.xml.namespace.QName QName_4_66 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "Id");
    private final static javax.xml.namespace.QName QName_4_145 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "PedidoEmOutrasHabilitacoes");
}
