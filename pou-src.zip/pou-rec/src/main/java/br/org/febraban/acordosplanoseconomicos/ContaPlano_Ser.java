/**
 * ContaPlano_Ser.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf031428.03 v72314182347
 */

package br.org.febraban.acordosplanoseconomicos;

public class ContaPlano_Ser extends br.org.febraban.acordosplanoseconomicos.Conta_Ser {
    /**
     * Constructor
     */
    public ContaPlano_Ser(
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType, 
           com.ibm.ws.webservices.engine.description.TypeDesc _typeDesc) {
        super(_javaType, _xmlType, _typeDesc);
    }
    public void serialize(
        javax.xml.namespace.QName name,
        org.xml.sax.Attributes attributes,
        java.lang.Object value,
        com.ibm.ws.webservices.engine.encoding.SerializationContext context)
        throws java.io.IOException
    {
        context.startElement(name, addAttributes(attributes, value, context));
        addElements(value, context);
        context.endElement();
    }
    protected org.xml.sax.Attributes addAttributes(
        org.xml.sax.Attributes attributes,
        java.lang.Object value,
        com.ibm.ws.webservices.engine.encoding.SerializationContext context)
        throws java.io.IOException
    {
        attributes = super.addAttributes(attributes, value, context);
           javax.xml.namespace.QName
           elemQName = QName_4_66;
           context.qName2String(elemQName, true);
           elemQName = QName_4_141;
           context.qName2String(elemQName, true);
           elemQName = QName_4_142;
           context.qName2String(elemQName, true);
           elemQName = QName_4_143;
           context.qName2String(elemQName, true);
           elemQName = QName_4_144;
           context.qName2String(elemQName, true);
           elemQName = QName_4_145;
           context.qName2String(elemQName, true);
        return attributes;
    }
    protected void addElements(
        java.lang.Object value,
        com.ibm.ws.webservices.engine.encoding.SerializationContext context)
        throws java.io.IOException
    {
        super.addElements(value, context);
        ContaPlano bean = (ContaPlano) value;
        java.lang.Object propValue;
        javax.xml.namespace.QName propQName;
        {
          propQName = QName_4_66;
          propValue = bean.getId();
          serializeChild(propQName, null, 
              propValue, 
              QName_1_6,
              false,null,context);
          propQName = QName_4_141;
          propValue = bean.getPlano();
          serializeChild(propQName, null, 
              propValue, 
              QName_8_146,
              false,null,context);
          propQName = QName_4_142;
          propValue = bean.getSaldoBase();
          serializeChild(propQName, null, 
              propValue, 
              QName_1_33,
              false,null,context);
          propQName = QName_4_143;
          propValue = bean.getValorSimulado();
          serializeChild(propQName, null, 
              propValue, 
              QName_1_33,
              false,null,context);
          propQName = QName_4_144;
          propValue = new java.lang.Double(bean.getDiaAniversarioConta());
          serializeChild(propQName, null, 
              propValue, 
              QName_1_33,
              true,null,context);
          propQName = QName_4_145;
          propValue = bean.getPedidoEmOutrasHabilitacoes();
          serializeChild(propQName, null, 
              propValue, 
              QName_4_147,
              false,null,context);
        }
    }
    private final static javax.xml.namespace.QName QName_1_6 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://www.w3.org/2001/XMLSchema",
                  "int");
    private final static javax.xml.namespace.QName QName_1_33 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://www.w3.org/2001/XMLSchema",
                  "double");
    private final static javax.xml.namespace.QName QName_4_145 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "PedidoEmOutrasHabilitacoes");
    private final static javax.xml.namespace.QName QName_4_66 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "Id");
    private final static javax.xml.namespace.QName QName_8_146 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/enums",
                  "PlanoEnum");
    private final static javax.xml.namespace.QName QName_4_141 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "Plano");
    private final static javax.xml.namespace.QName QName_4_142 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "SaldoBase");
    private final static javax.xml.namespace.QName QName_4_147 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "ArrayOfHabilitacao");
    private final static javax.xml.namespace.QName QName_4_144 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "DiaAniversarioConta");
    private final static javax.xml.namespace.QName QName_4_143 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "ValorSimulado");
}
