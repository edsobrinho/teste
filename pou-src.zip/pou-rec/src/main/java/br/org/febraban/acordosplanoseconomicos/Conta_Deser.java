/**
 * Conta_Deser.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf031428.03 v72314182347
 */

package br.org.febraban.acordosplanoseconomicos;

public class Conta_Deser extends com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializer {
    /**
     * Constructor
     */
    public Conta_Deser(
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType, 
           com.ibm.ws.webservices.engine.description.TypeDesc _typeDesc) {
        super(_javaType, _xmlType, _typeDesc);
    }
    /**
     * Create instance of java bean
     */
    public void createValue() {
        value = new Conta();
    }
    protected boolean tryElementSetFromString(javax.xml.namespace.QName qName, java.lang.String strValue) {
        if (qName==QName_15_129) {
          ((Conta)value).setNomeTitular(strValue);
          return true;}
        else if (qName==QName_15_130) {
          ((Conta)value).setCpfCnpj(strValue);
          return true;}
        else if (qName==QName_15_131) {
          ((Conta)value).setBanco(com.ibm.ws.webservices.engine.encoding.ser.SimpleDeserializer.parseint(strValue));
          return true;}
        else if (qName==QName_15_132) {
          ((Conta)value).setNomeBanco(strValue);
          return true;}
        else if (qName==QName_15_133) {
          ((Conta)value).setAgencia(strValue);
          return true;}
        else if (qName==QName_15_134) {
          ((Conta)value).setAgenciaDV(strValue);
          return true;}
        else if (qName==QName_15_135) {
          ((Conta)value).setNumeroConta(strValue);
          return true;}
        else if (qName==QName_15_136) {
          ((Conta)value).setNumeroContaDV(strValue);
          return true;}
        return false;
    }
    protected boolean tryAttributeSetFromString(javax.xml.namespace.QName qName, java.lang.String strValue) {
        return false;
    }
    protected boolean tryElementSetFromObject(javax.xml.namespace.QName qName, java.lang.Object objValue) {
        if (qName==QName_15_137) {
          ((Conta)value).setTipoConta((br.org.febraban.acordosplanoseconomicos.TipoContaEnum)objValue);
          return true;}
        return false;
    }
    protected boolean tryElementSetFromList(javax.xml.namespace.QName qName, java.util.List listValue) {
        return false;
    }
    private final static javax.xml.namespace.QName QName_15_132 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/tipos",
                  "NomeBanco");
    private final static javax.xml.namespace.QName QName_15_131 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/tipos",
                  "Banco");
    private final static javax.xml.namespace.QName QName_15_133 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/tipos",
                  "Agencia");
    private final static javax.xml.namespace.QName QName_15_129 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/tipos",
                  "NomeTitular");
    private final static javax.xml.namespace.QName QName_15_136 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/tipos",
                  "NumeroContaDV");
    private final static javax.xml.namespace.QName QName_15_130 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/tipos",
                  "CpfCnpj");
    private final static javax.xml.namespace.QName QName_15_137 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/tipos",
                  "TipoConta");
    private final static javax.xml.namespace.QName QName_15_134 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/tipos",
                  "AgenciaDV");
    private final static javax.xml.namespace.QName QName_15_135 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/tipos",
                  "NumeroConta");
}
