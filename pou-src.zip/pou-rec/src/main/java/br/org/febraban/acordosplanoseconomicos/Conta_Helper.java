/**
 * Conta_Helper.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf031428.03 v72314182347
 */

package br.org.febraban.acordosplanoseconomicos;

public class Conta_Helper {
    // Type metadata
    private static final com.ibm.ws.webservices.engine.description.TypeDesc typeDesc =
        new com.ibm.ws.webservices.engine.description.TypeDesc(Conta.class);

    static {
        typeDesc.setOption("buildNum","cf031428.03");
        com.ibm.ws.webservices.engine.description.FieldDesc field = new com.ibm.ws.webservices.engine.description.ElementDesc();
        field.setFieldName("nomeTitular");
        field.setXmlName(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/tipos", "NomeTitular"));
        field.setXmlType(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(field);
        field = new com.ibm.ws.webservices.engine.description.ElementDesc();
        field.setFieldName("cpfCnpj");
        field.setXmlName(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/tipos", "CpfCnpj"));
        field.setXmlType(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(field);
        field = new com.ibm.ws.webservices.engine.description.ElementDesc();
        field.setFieldName("banco");
        field.setXmlName(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/tipos", "Banco"));
        field.setXmlType(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(field);
        field = new com.ibm.ws.webservices.engine.description.ElementDesc();
        field.setFieldName("nomeBanco");
        field.setXmlName(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/tipos", "NomeBanco"));
        field.setXmlType(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(field);
        field = new com.ibm.ws.webservices.engine.description.ElementDesc();
        field.setFieldName("agencia");
        field.setXmlName(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/tipos", "Agencia"));
        field.setXmlType(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(field);
        field = new com.ibm.ws.webservices.engine.description.ElementDesc();
        field.setFieldName("agenciaDV");
        field.setXmlName(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/tipos", "AgenciaDV"));
        field.setXmlType(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.w3.org/2001/XMLSchema", "string"));
        field.setMinOccursIs0(true);
        typeDesc.addFieldDesc(field);
        field = new com.ibm.ws.webservices.engine.description.ElementDesc();
        field.setFieldName("numeroConta");
        field.setXmlName(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/tipos", "NumeroConta"));
        field.setXmlType(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(field);
        field = new com.ibm.ws.webservices.engine.description.ElementDesc();
        field.setFieldName("numeroContaDV");
        field.setXmlName(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/tipos", "NumeroContaDV"));
        field.setXmlType(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(field);
        field = new com.ibm.ws.webservices.engine.description.ElementDesc();
        field.setFieldName("tipoConta");
        field.setXmlName(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/tipos", "TipoConta"));
        field.setXmlType(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/tipos/enums", "TipoContaEnum"));
        field.setMinOccursIs0(true);
        typeDesc.addFieldDesc(field);
    };

    /**
     * Return type metadata object
     */
    public static com.ibm.ws.webservices.engine.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static com.ibm.ws.webservices.engine.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class javaType,  
           javax.xml.namespace.QName xmlType) {
        return 
          new Conta_Ser(
            javaType, xmlType, typeDesc);
    };

    /**
     * Get Custom Deserializer
     */
    public static com.ibm.ws.webservices.engine.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class javaType,  
           javax.xml.namespace.QName xmlType) {
        return 
          new Conta_Deser(
            javaType, xmlType, typeDesc);
    };

}
