/**
 * Contato.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf031428.03 v72314182347
 */

package br.org.febraban.acordosplanoseconomicos;

public class Contato  {
    private br.org.febraban.acordosplanoseconomicos.Telefone celular;
    private java.lang.String email;
    private br.org.febraban.acordosplanoseconomicos.Telefone telefoneFixo;

    public Contato() {
    }

    public br.org.febraban.acordosplanoseconomicos.Telefone getCelular() {
        return celular;
    }

    public void setCelular(br.org.febraban.acordosplanoseconomicos.Telefone celular) {
        this.celular = celular;
    }

    public java.lang.String getEmail() {
        return email;
    }

    public void setEmail(java.lang.String email) {
        this.email = email;
    }

    public br.org.febraban.acordosplanoseconomicos.Telefone getTelefoneFixo() {
        return telefoneFixo;
    }

    public void setTelefoneFixo(br.org.febraban.acordosplanoseconomicos.Telefone telefoneFixo) {
        this.telefoneFixo = telefoneFixo;
    }

}
