/**
 * Contato_Deser.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf031428.03 v72314182347
 */

package br.org.febraban.acordosplanoseconomicos;

public class Contato_Deser extends com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializer {
    /**
     * Constructor
     */
    public Contato_Deser(
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType, 
           com.ibm.ws.webservices.engine.description.TypeDesc _typeDesc) {
        super(_javaType, _xmlType, _typeDesc);
    }
    /**
     * Create instance of java bean
     */
    public void createValue() {
        value = new Contato();
    }
    protected boolean tryElementSetFromString(javax.xml.namespace.QName qName, java.lang.String strValue) {
        if (qName==QName_4_123) {
          ((Contato)value).setEmail(strValue);
          return true;}
        return false;
    }
    protected boolean tryAttributeSetFromString(javax.xml.namespace.QName qName, java.lang.String strValue) {
        return false;
    }
    protected boolean tryElementSetFromObject(javax.xml.namespace.QName qName, java.lang.Object objValue) {
        if (qName==QName_4_122) {
          ((Contato)value).setCelular((br.org.febraban.acordosplanoseconomicos.Telefone)objValue);
          return true;}
        else if (qName==QName_4_124) {
          ((Contato)value).setTelefoneFixo((br.org.febraban.acordosplanoseconomicos.Telefone)objValue);
          return true;}
        return false;
    }
    protected boolean tryElementSetFromList(javax.xml.namespace.QName qName, java.util.List listValue) {
        return false;
    }
    private final static javax.xml.namespace.QName QName_4_124 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "TelefoneFixo");
    private final static javax.xml.namespace.QName QName_4_122 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "Celular");
    private final static javax.xml.namespace.QName QName_4_123 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "Email");
}
