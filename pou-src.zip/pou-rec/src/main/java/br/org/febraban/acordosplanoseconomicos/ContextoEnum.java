/**
 * ContextoEnum.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf031428.03 v72314182347
 */

package br.org.febraban.acordosplanoseconomicos;

public class ContextoEnum  {
    private java.lang.String _value_;
    private static java.util.HashMap _table_ = new java.util.HashMap();

    // Constructor
    protected ContextoEnum(java.lang.String value) {
        _value_ = value;
        _table_.put(_value_,this);
    };

    public static final java.lang.String _POUPADOR = "POUPADOR";
    public static final java.lang.String _INVENTARIANTE = "INVENTARIANTE";
    public static final java.lang.String _ADVOGADO = "ADVOGADO";
    public static final java.lang.String _PROCESSO = "PROCESSO";
    public static final java.lang.String _CONTA_PLANO = "CONTA_PLANO";
    public static final java.lang.String _PAGAMENTO = "PAGAMENTO";
    public static final java.lang.String _RESUMO = "RESUMO";
    public static final java.lang.String _TERMO = "TERMO";
    public static final java.lang.String _ADESAO = "ADESAO";
    public static final java.lang.String _OUTROS_DOCUMENTOS = "OUTROS_DOCUMENTOS";
    public static final java.lang.String _PROPOSTA = "PROPOSTA";
    public static final java.lang.String _SUCESSOR = "SUCESSOR";
    public static final ContextoEnum POUPADOR = new ContextoEnum(_POUPADOR);
    public static final ContextoEnum INVENTARIANTE = new ContextoEnum(_INVENTARIANTE);
    public static final ContextoEnum ADVOGADO = new ContextoEnum(_ADVOGADO);
    public static final ContextoEnum PROCESSO = new ContextoEnum(_PROCESSO);
    public static final ContextoEnum CONTA_PLANO = new ContextoEnum(_CONTA_PLANO);
    public static final ContextoEnum PAGAMENTO = new ContextoEnum(_PAGAMENTO);
    public static final ContextoEnum RESUMO = new ContextoEnum(_RESUMO);
    public static final ContextoEnum TERMO = new ContextoEnum(_TERMO);
    public static final ContextoEnum ADESAO = new ContextoEnum(_ADESAO);
    public static final ContextoEnum OUTROS_DOCUMENTOS = new ContextoEnum(_OUTROS_DOCUMENTOS);
    public static final ContextoEnum PROPOSTA = new ContextoEnum(_PROPOSTA);
    public static final ContextoEnum SUCESSOR = new ContextoEnum(_SUCESSOR);
    public java.lang.String getValue() { return _value_;}
    public static ContextoEnum fromValue(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        ContextoEnum enumeration = (ContextoEnum)
            _table_.get(value);
        if (enumeration==null) throw new java.lang.IllegalArgumentException();
        return enumeration;
    }
    public static ContextoEnum fromString(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        return fromValue(value);
    }
    public boolean equals(java.lang.Object obj) {return (obj == this);}
    public int hashCode() { return toString().hashCode();}
    public java.lang.String toString() { return _value_;}

}
