/**
 * DepositoJudicial.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf031428.03 v72314182347
 */

package br.org.febraban.acordosplanoseconomicos;

public class DepositoJudicial  {
    private int banco;
    private java.lang.String nomeBanco;
    private java.lang.String identificadorDepositoJudicial;
    private java.lang.String dataValidade;

    public DepositoJudicial() {
    }

    public int getBanco() {
        return banco;
    }

    public void setBanco(int banco) {
        this.banco = banco;
    }

    public java.lang.String getNomeBanco() {
        return nomeBanco;
    }

    public void setNomeBanco(java.lang.String nomeBanco) {
        this.nomeBanco = nomeBanco;
    }

    public java.lang.String getIdentificadorDepositoJudicial() {
        return identificadorDepositoJudicial;
    }

    public void setIdentificadorDepositoJudicial(java.lang.String identificadorDepositoJudicial) {
        this.identificadorDepositoJudicial = identificadorDepositoJudicial;
    }

    public java.lang.String getDataValidade() {
        return dataValidade;
    }

    public void setDataValidade(java.lang.String dataValidade) {
        this.dataValidade = dataValidade;
    }

}
