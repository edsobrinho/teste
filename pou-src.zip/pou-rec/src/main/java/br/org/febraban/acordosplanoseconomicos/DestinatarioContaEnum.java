/**
 * DestinatarioContaEnum.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf031428.03 v72314182347
 */

package br.org.febraban.acordosplanoseconomicos;

public class DestinatarioContaEnum  {
    private java.lang.String _value_;
    private static java.util.HashMap _table_ = new java.util.HashMap();

    // Constructor
    protected DestinatarioContaEnum(java.lang.String value) {
        _value_ = value;
        _table_.put(_value_,this);
    };

    public static final java.lang.String _CONTA_POUPADOR = "CONTA_POUPADOR";
    public static final java.lang.String _CONTA_ADVOGADO = "CONTA_ADVOGADO";
    public static final java.lang.String _DEPOSITO_JUDICIAL = "DEPOSITO_JUDICIAL";
    public static final java.lang.String _BOLETO = "BOLETO";
    public static final DestinatarioContaEnum CONTA_POUPADOR = new DestinatarioContaEnum(_CONTA_POUPADOR);
    public static final DestinatarioContaEnum CONTA_ADVOGADO = new DestinatarioContaEnum(_CONTA_ADVOGADO);
    public static final DestinatarioContaEnum DEPOSITO_JUDICIAL = new DestinatarioContaEnum(_DEPOSITO_JUDICIAL);
    public static final DestinatarioContaEnum BOLETO = new DestinatarioContaEnum(_BOLETO);
    public java.lang.String getValue() { return _value_;}
    public static DestinatarioContaEnum fromValue(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        DestinatarioContaEnum enumeration = (DestinatarioContaEnum)
            _table_.get(value);
        if (enumeration==null) throw new java.lang.IllegalArgumentException();
        return enumeration;
    }
    public static DestinatarioContaEnum fromString(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        return fromValue(value);
    }
    public boolean equals(java.lang.Object obj) {return (obj == this);}
    public int hashCode() { return toString().hashCode();}
    public java.lang.String toString() { return _value_;}

}
