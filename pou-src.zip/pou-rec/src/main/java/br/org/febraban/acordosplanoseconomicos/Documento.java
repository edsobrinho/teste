/**
 * Documento.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf031428.03 v72314182347
 */

package br.org.febraban.acordosplanoseconomicos;

public class Documento  {
    private int id;
    private java.lang.String nomeDocumento;
    private br.org.febraban.acordosplanoseconomicos.TipoDocumentoEnum tipoDocumento;
    private br.org.febraban.acordosplanoseconomicos.ContextoEnum contexto;
    private java.lang.Integer idChaveContexto;

    public Documento() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public java.lang.String getNomeDocumento() {
        return nomeDocumento;
    }

    public void setNomeDocumento(java.lang.String nomeDocumento) {
        this.nomeDocumento = nomeDocumento;
    }

    public br.org.febraban.acordosplanoseconomicos.TipoDocumentoEnum getTipoDocumento() {
        return tipoDocumento;
    }

    public void setTipoDocumento(br.org.febraban.acordosplanoseconomicos.TipoDocumentoEnum tipoDocumento) {
        this.tipoDocumento = tipoDocumento;
    }

    public br.org.febraban.acordosplanoseconomicos.ContextoEnum getContexto() {
        return contexto;
    }

    public void setContexto(br.org.febraban.acordosplanoseconomicos.ContextoEnum contexto) {
        this.contexto = contexto;
    }

    public java.lang.Integer getIdChaveContexto() {
        return idChaveContexto;
    }

    public void setIdChaveContexto(java.lang.Integer idChaveContexto) {
        this.idChaveContexto = idChaveContexto;
    }

}
