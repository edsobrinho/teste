/**
 * DocumentoStub.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf031428.03 v72314182347
 */

package br.org.febraban.acordosplanoseconomicos;

public class DocumentoStub extends com.ibm.ws.webservices.engine.client.Stub implements br.org.febraban.acordosplanoseconomicos.IDocumentoService {
    public DocumentoStub(java.net.URL endpointURL, javax.xml.rpc.Service service) throws com.ibm.ws.webservices.engine.WebServicesFault {
        if (service == null) {
            super.service = new com.ibm.ws.webservices.engine.client.Service();
        }
        else {
            super.service = service;
        }
        super.engine = ((com.ibm.ws.webservices.engine.client.Service) super.service).getEngine();
        super.messageContexts = new com.ibm.ws.webservices.engine.MessageContext[3];
        java.lang.String theOption = (java.lang.String)super._getProperty("lastStubMapping");
        if (theOption == null || !theOption.equals("br.org.febraban.acordosplanoseconomicos.Documento")) {
                initTypeMapping();
                super._setProperty("lastStubMapping","br.org.febraban.acordosplanoseconomicos.Documento");
        }
        super.cachedEndpoint = endpointURL;
        super.connection = ((com.ibm.ws.webservices.engine.client.Service) super.service).getConnection(endpointURL);
    }

    private void initTypeMapping() {
        javax.xml.rpc.encoding.TypeMapping tm = super.getTypeMapping(com.ibm.ws.webservices.engine.Constants.URI_LITERAL_ENC);
        java.lang.Class javaType = null;
        javax.xml.namespace.QName xmlType = null;
        javax.xml.namespace.QName compQName = null;
        javax.xml.namespace.QName compTypeQName = null;
        com.ibm.ws.webservices.engine.encoding.SerializerFactory sf = null;
        com.ibm.ws.webservices.engine.encoding.DeserializerFactory df = null;
        javaType = br.org.febraban.acordosplanoseconomicos.RespostaOperacao.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "RespostaOperacao");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = br.org.febraban.acordosplanoseconomicos.RetornoProcessamentoEnum.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/enums", "RetornoProcessamentoEnum");
        compTypeQName = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.w3.org/2001/XMLSchema", "string");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.EnumSerializerFactory.class, javaType, xmlType, null, compTypeQName);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.EnumDeserializerFactory.class, javaType, xmlType, null, compTypeQName);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = br.org.febraban.acordosplanoseconomicos.Documento[].class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/documentos", "ArrayOfDocumento");
        compQName = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/documentos", "Documento");
        compTypeQName = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/documentos", "Documento");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.ArraySerializerFactory.class, javaType, xmlType, compQName, compTypeQName);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.ArrayDeserializerFactory.class, javaType, xmlType, compQName, compTypeQName);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = br.org.febraban.acordosplanoseconomicos.IdentificadorArquivo.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/documentos/requisicoes", "IdentificadorArquivo");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = br.org.febraban.acordosplanoseconomicos.Arquivo.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/documentos", "Arquivo");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = br.org.febraban.acordosplanoseconomicos.RequisicaoConfirmacaoRecebimentoArquivo.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/documentos/requisicoes", "RequisicaoConfirmacaoRecebimentoArquivo");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = br.org.febraban.acordosplanoseconomicos.RespostaOperacaoConfirmarRecebimentoArquivo[].class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/documentos/respostas", "ArrayOfRespostaOperacaoConfirmarRecebimentoArquivo");
        compQName = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/documentos/respostas", "RespostaOperacaoConfirmarRecebimentoArquivo");
        compTypeQName = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/documentos/respostas", "RespostaOperacaoConfirmarRecebimentoArquivo");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.ArraySerializerFactory.class, javaType, xmlType, compQName, compTypeQName);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.ArrayDeserializerFactory.class, javaType, xmlType, compQName, compTypeQName);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = br.org.febraban.acordosplanoseconomicos.ContextoEnum.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/enums", "ContextoEnum");
        compTypeQName = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.w3.org/2001/XMLSchema", "string");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.EnumSerializerFactory.class, javaType, xmlType, null, compTypeQName);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.EnumDeserializerFactory.class, javaType, xmlType, null, compTypeQName);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = br.org.febraban.acordosplanoseconomicos.TipoDocumentoEnum.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/enums", "TipoDocumentoEnum");
        compTypeQName = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.w3.org/2001/XMLSchema", "string");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.EnumSerializerFactory.class, javaType, xmlType, null, compTypeQName);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.EnumDeserializerFactory.class, javaType, xmlType, null, compTypeQName);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = br.org.febraban.acordosplanoseconomicos.Documento.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/documentos", "Documento");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = br.org.febraban.acordosplanoseconomicos.IdentificadorArquivo[].class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/documentos/requisicoes", "ArrayOfIdentificadorArquivo");
        compQName = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/documentos/requisicoes", "IdentificadorArquivo");
        compTypeQName = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/documentos/requisicoes", "IdentificadorArquivo");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.ArraySerializerFactory.class, javaType, xmlType, compQName, compTypeQName);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.ArrayDeserializerFactory.class, javaType, xmlType, compQName, compTypeQName);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = br.org.febraban.acordosplanoseconomicos.RespostaOperacaoConfirmarRecebimentoArquivo.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/documentos/respostas", "RespostaOperacaoConfirmarRecebimentoArquivo");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

    }

    private static com.ibm.ws.webservices.engine.description.OperationDesc _obterDocumentoOperation0 = null;
    private static com.ibm.ws.webservices.engine.description.OperationDesc _getobterDocumentoOperation0() {
        com.ibm.ws.webservices.engine.description.ParameterDesc[]  _params0 = new com.ibm.ws.webservices.engine.description.ParameterDesc[] {
         new com.ibm.ws.webservices.engine.description.ParameterDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "guidPedido"), com.ibm.ws.webservices.engine.description.ParameterDesc.IN, com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false, false, true, true, false), 
          };
        _params0[0].setOption("partQNameString","{http://www.w3.org/2001/XMLSchema}string");
        _params0[0].setOption("inputPosition","0");
        _params0[0].setOption("partName","string");
        com.ibm.ws.webservices.engine.description.ParameterDesc  _returnDesc0 = new com.ibm.ws.webservices.engine.description.ParameterDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "ObterDocumentoResult"), com.ibm.ws.webservices.engine.description.ParameterDesc.OUT, com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/documentos", "ArrayOfDocumento"), br.org.febraban.acordosplanoseconomicos.Documento[].class, true, false, false, true, true, false); 
        _returnDesc0.setOption("partQNameString","{http://acordosplanoseconomicos.febraban.org.br/contratos/documentos}ArrayOfDocumento");
        _returnDesc0.setOption("outputPosition","0");
        _returnDesc0.setOption("partName","ArrayOfDocumento");
        com.ibm.ws.webservices.engine.description.FaultDesc[]  _faults0 = new com.ibm.ws.webservices.engine.description.FaultDesc[] {
          };
        _obterDocumentoOperation0 = new com.ibm.ws.webservices.engine.description.OperationDesc("obterDocumento", com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "ObterDocumento"), _params0, _returnDesc0, _faults0, "http://acordosplanoseconomicos.febraban.org.br/IDocumentoService/ObterDocumento");
        _obterDocumentoOperation0.setOption("buildNum","cf031428.03");
        _obterDocumentoOperation0.setOption("ResponseNamespace","http://acordosplanoseconomicos.febraban.org.br");
        _obterDocumentoOperation0.setOption("targetNamespace","http://acordosplanoseconomicos.febraban.org.br");
        _obterDocumentoOperation0.setOption("outputMessageQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "IDocumentoService_ObterDocumento_OutputMessage"));
        _obterDocumentoOperation0.setOption("inputWSAAction","http://acordosplanoseconomicos.febraban.org.br/IDocumentoService/ObterDocumento");
        _obterDocumentoOperation0.setOption("portTypeQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "IDocumentoService"));
        _obterDocumentoOperation0.setOption("outputWSAAction","http://acordosplanoseconomicos.febraban.org.br/IDocumentoService/ObterDocumentoResponse");
        _obterDocumentoOperation0.setOption("ServiceQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "AcordoPlanoEconomicosService"));
        _obterDocumentoOperation0.setOption("ResponseLocalPart","ObterDocumentoResponse");
        _obterDocumentoOperation0.setOption("inputMessageQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "IDocumentoService_ObterDocumento_InputMessage"));
        _obterDocumentoOperation0.setUse(com.ibm.ws.webservices.engine.enumtype.Use.LITERAL);
        _obterDocumentoOperation0.setStyle(com.ibm.ws.webservices.engine.enumtype.Style.WRAPPED);
        return _obterDocumentoOperation0;

    }

    private int _obterDocumentoIndex0 = 0;
    private synchronized com.ibm.ws.webservices.engine.client.Stub.Invoke _getobterDocumentoInvoke0(Object[] parameters) throws com.ibm.ws.webservices.engine.WebServicesFault  {
        com.ibm.ws.webservices.engine.MessageContext mc = super.messageContexts[_obterDocumentoIndex0];
        if (mc == null) {
            mc = new com.ibm.ws.webservices.engine.MessageContext(super.engine);
            mc.setOperation(DocumentoStub._obterDocumentoOperation0);
            mc.setUseSOAPAction(true);
            mc.setSOAPActionURI("http://acordosplanoseconomicos.febraban.org.br/IDocumentoService/ObterDocumento");
            mc.setEncodingStyle(com.ibm.ws.webservices.engine.Constants.URI_LITERAL_ENC);
            mc.setProperty(com.ibm.wsspi.webservices.Constants.SEND_TYPE_ATTR_PROPERTY, Boolean.FALSE);
            mc.setProperty(com.ibm.wsspi.webservices.Constants.ENGINE_DO_MULTI_REFS_PROPERTY, Boolean.FALSE);
            super.primeMessageContext(mc);
            super.messageContexts[_obterDocumentoIndex0] = mc;
        }
        try {
            mc = (com.ibm.ws.webservices.engine.MessageContext) mc.clone();
        }
        catch (CloneNotSupportedException cnse) {
            throw com.ibm.ws.webservices.engine.WebServicesFault.makeFault(cnse);
        }
        return new com.ibm.ws.webservices.engine.client.Stub.Invoke(connection, mc, parameters);
    }

    public br.org.febraban.acordosplanoseconomicos.Documento[] obterDocumento(java.lang.String guidPedido) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new com.ibm.ws.webservices.engine.NoEndPointException();
        }
        java.util.Vector _resp = null;
        try {
            _resp = _getobterDocumentoInvoke0(new java.lang.Object[] {guidPedido}).invoke();

        } catch (com.ibm.ws.webservices.engine.WebServicesFault wsf) {
            Exception e = wsf.getUserException();
            throw wsf;
        } 
        try {
            return (br.org.febraban.acordosplanoseconomicos.Documento[]) ((com.ibm.ws.webservices.engine.xmlsoap.ext.ParamValue) _resp.get(0)).getValue();
        } catch (java.lang.Exception _exception) {
            return (br.org.febraban.acordosplanoseconomicos.Documento[]) super.convert(((com.ibm.ws.webservices.engine.xmlsoap.ext.ParamValue) _resp.get(0)).getValue(), br.org.febraban.acordosplanoseconomicos.Documento[].class);
        }
    }

    private static com.ibm.ws.webservices.engine.description.OperationDesc _obterArquivoOperation1 = null;
    private static com.ibm.ws.webservices.engine.description.OperationDesc _getobterArquivoOperation1() {
        com.ibm.ws.webservices.engine.description.ParameterDesc[]  _params1 = new com.ibm.ws.webservices.engine.description.ParameterDesc[] {
         new com.ibm.ws.webservices.engine.description.ParameterDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "requisicao"), com.ibm.ws.webservices.engine.description.ParameterDesc.IN, com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/documentos/requisicoes", "IdentificadorArquivo"), br.org.febraban.acordosplanoseconomicos.IdentificadorArquivo.class, false, false, false, true, true, false), 
          };
        _params1[0].setOption("partQNameString","{http://acordosplanoseconomicos.febraban.org.br/contratos/documentos/requisicoes}IdentificadorArquivo");
        _params1[0].setOption("inputPosition","0");
        _params1[0].setOption("partName","IdentificadorArquivo");
        com.ibm.ws.webservices.engine.description.ParameterDesc  _returnDesc1 = new com.ibm.ws.webservices.engine.description.ParameterDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "ObterArquivoResult"), com.ibm.ws.webservices.engine.description.ParameterDesc.OUT, com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/documentos", "Arquivo"), br.org.febraban.acordosplanoseconomicos.Arquivo.class, true, false, false, true, true, false); 
        _returnDesc1.setOption("partQNameString","{http://acordosplanoseconomicos.febraban.org.br/contratos/documentos}Arquivo");
        _returnDesc1.setOption("outputPosition","0");
        _returnDesc1.setOption("partName","Arquivo");
        com.ibm.ws.webservices.engine.description.FaultDesc[]  _faults1 = new com.ibm.ws.webservices.engine.description.FaultDesc[] {
          };
        _obterArquivoOperation1 = new com.ibm.ws.webservices.engine.description.OperationDesc("obterArquivo", com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "ObterArquivo"), _params1, _returnDesc1, _faults1, "http://acordosplanoseconomicos.febraban.org.br/IDocumentoService/ObterArquivo");
        _obterArquivoOperation1.setOption("buildNum","cf031428.03");
        _obterArquivoOperation1.setOption("ResponseNamespace","http://acordosplanoseconomicos.febraban.org.br");
        _obterArquivoOperation1.setOption("targetNamespace","http://acordosplanoseconomicos.febraban.org.br");
        _obterArquivoOperation1.setOption("outputMessageQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "IDocumentoService_ObterArquivo_OutputMessage"));
        _obterArquivoOperation1.setOption("inputWSAAction","http://acordosplanoseconomicos.febraban.org.br/IDocumentoService/ObterArquivo");
        _obterArquivoOperation1.setOption("portTypeQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "IDocumentoService"));
        _obterArquivoOperation1.setOption("outputWSAAction","http://acordosplanoseconomicos.febraban.org.br/IDocumentoService/ObterArquivoResponse");
        _obterArquivoOperation1.setOption("ServiceQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "AcordoPlanoEconomicosService"));
        _obterArquivoOperation1.setOption("ResponseLocalPart","ObterArquivoResponse");
        _obterArquivoOperation1.setOption("inputMessageQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "IDocumentoService_ObterArquivo_InputMessage"));
        _obterArquivoOperation1.setUse(com.ibm.ws.webservices.engine.enumtype.Use.LITERAL);
        _obterArquivoOperation1.setStyle(com.ibm.ws.webservices.engine.enumtype.Style.WRAPPED);
        return _obterArquivoOperation1;

    }

    private int _obterArquivoIndex1 = 1;
    private synchronized com.ibm.ws.webservices.engine.client.Stub.Invoke _getobterArquivoInvoke1(Object[] parameters) throws com.ibm.ws.webservices.engine.WebServicesFault  {
        com.ibm.ws.webservices.engine.MessageContext mc = super.messageContexts[_obterArquivoIndex1];
        if (mc == null) {
            mc = new com.ibm.ws.webservices.engine.MessageContext(super.engine);
            mc.setOperation(DocumentoStub._obterArquivoOperation1);
            mc.setUseSOAPAction(true);
            mc.setSOAPActionURI("http://acordosplanoseconomicos.febraban.org.br/IDocumentoService/ObterArquivo");
            mc.setEncodingStyle(com.ibm.ws.webservices.engine.Constants.URI_LITERAL_ENC);
            mc.setProperty(com.ibm.wsspi.webservices.Constants.SEND_TYPE_ATTR_PROPERTY, Boolean.FALSE);
            mc.setProperty(com.ibm.wsspi.webservices.Constants.ENGINE_DO_MULTI_REFS_PROPERTY, Boolean.FALSE);
            super.primeMessageContext(mc);
            super.messageContexts[_obterArquivoIndex1] = mc;
        }
        try {
            mc = (com.ibm.ws.webservices.engine.MessageContext) mc.clone();
        }
        catch (CloneNotSupportedException cnse) {
            throw com.ibm.ws.webservices.engine.WebServicesFault.makeFault(cnse);
        }
        return new com.ibm.ws.webservices.engine.client.Stub.Invoke(connection, mc, parameters);
    }

    public br.org.febraban.acordosplanoseconomicos.Arquivo obterArquivo(br.org.febraban.acordosplanoseconomicos.IdentificadorArquivo requisicao) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new com.ibm.ws.webservices.engine.NoEndPointException();
        }
        java.util.Vector _resp = null;
        try {
            _resp = _getobterArquivoInvoke1(new java.lang.Object[] {requisicao}).invoke();

        } catch (com.ibm.ws.webservices.engine.WebServicesFault wsf) {
            Exception e = wsf.getUserException();
            throw wsf;
        } 
        try {
            return (br.org.febraban.acordosplanoseconomicos.Arquivo) ((com.ibm.ws.webservices.engine.xmlsoap.ext.ParamValue) _resp.get(0)).getValue();
        } catch (java.lang.Exception _exception) {
            return (br.org.febraban.acordosplanoseconomicos.Arquivo) super.convert(((com.ibm.ws.webservices.engine.xmlsoap.ext.ParamValue) _resp.get(0)).getValue(), br.org.febraban.acordosplanoseconomicos.Arquivo.class);
        }
    }

    private static com.ibm.ws.webservices.engine.description.OperationDesc _confirmarRecebimentoArquivoOperation2 = null;
    private static com.ibm.ws.webservices.engine.description.OperationDesc _getconfirmarRecebimentoArquivoOperation2() {
        com.ibm.ws.webservices.engine.description.ParameterDesc[]  _params2 = new com.ibm.ws.webservices.engine.description.ParameterDesc[] {
         new com.ibm.ws.webservices.engine.description.ParameterDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "requisicao"), com.ibm.ws.webservices.engine.description.ParameterDesc.IN, com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/documentos/requisicoes", "RequisicaoConfirmacaoRecebimentoArquivo"), br.org.febraban.acordosplanoseconomicos.RequisicaoConfirmacaoRecebimentoArquivo.class, false, false, false, true, true, false), 
          };
        _params2[0].setOption("partQNameString","{http://acordosplanoseconomicos.febraban.org.br/contratos/documentos/requisicoes}RequisicaoConfirmacaoRecebimentoArquivo");
        _params2[0].setOption("inputPosition","0");
        _params2[0].setOption("partName","RequisicaoConfirmacaoRecebimentoArquivo");
        com.ibm.ws.webservices.engine.description.ParameterDesc  _returnDesc2 = new com.ibm.ws.webservices.engine.description.ParameterDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "ConfirmarRecebimentoArquivoResult"), com.ibm.ws.webservices.engine.description.ParameterDesc.OUT, com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/documentos/respostas", "ArrayOfRespostaOperacaoConfirmarRecebimentoArquivo"), br.org.febraban.acordosplanoseconomicos.RespostaOperacaoConfirmarRecebimentoArquivo[].class, true, false, false, true, true, false); 
        _returnDesc2.setOption("partQNameString","{http://acordosplanoseconomicos.febraban.org.br/contratos/documentos/respostas}ArrayOfRespostaOperacaoConfirmarRecebimentoArquivo");
        _returnDesc2.setOption("outputPosition","0");
        _returnDesc2.setOption("partName","ArrayOfRespostaOperacaoConfirmarRecebimentoArquivo");
        com.ibm.ws.webservices.engine.description.FaultDesc[]  _faults2 = new com.ibm.ws.webservices.engine.description.FaultDesc[] {
          };
        _confirmarRecebimentoArquivoOperation2 = new com.ibm.ws.webservices.engine.description.OperationDesc("confirmarRecebimentoArquivo", com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "ConfirmarRecebimentoArquivo"), _params2, _returnDesc2, _faults2, "http://acordosplanoseconomicos.febraban.org.br/IDocumentoService/ConfirmarRecebimentoArquivo");
        _confirmarRecebimentoArquivoOperation2.setOption("buildNum","cf031428.03");
        _confirmarRecebimentoArquivoOperation2.setOption("ResponseNamespace","http://acordosplanoseconomicos.febraban.org.br");
        _confirmarRecebimentoArquivoOperation2.setOption("targetNamespace","http://acordosplanoseconomicos.febraban.org.br");
        _confirmarRecebimentoArquivoOperation2.setOption("outputMessageQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "IDocumentoService_ConfirmarRecebimentoArquivo_OutputMessage"));
        _confirmarRecebimentoArquivoOperation2.setOption("inputWSAAction","http://acordosplanoseconomicos.febraban.org.br/IDocumentoService/ConfirmarRecebimentoArquivo");
        _confirmarRecebimentoArquivoOperation2.setOption("portTypeQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "IDocumentoService"));
        _confirmarRecebimentoArquivoOperation2.setOption("outputWSAAction","http://acordosplanoseconomicos.febraban.org.br/IDocumentoService/ConfirmarRecebimentoArquivoResponse");
        _confirmarRecebimentoArquivoOperation2.setOption("ServiceQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "AcordoPlanoEconomicosService"));
        _confirmarRecebimentoArquivoOperation2.setOption("ResponseLocalPart","ConfirmarRecebimentoArquivoResponse");
        _confirmarRecebimentoArquivoOperation2.setOption("inputMessageQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "IDocumentoService_ConfirmarRecebimentoArquivo_InputMessage"));
        _confirmarRecebimentoArquivoOperation2.setUse(com.ibm.ws.webservices.engine.enumtype.Use.LITERAL);
        _confirmarRecebimentoArquivoOperation2.setStyle(com.ibm.ws.webservices.engine.enumtype.Style.WRAPPED);
        return _confirmarRecebimentoArquivoOperation2;

    }

    private int _confirmarRecebimentoArquivoIndex2 = 2;
    private synchronized com.ibm.ws.webservices.engine.client.Stub.Invoke _getconfirmarRecebimentoArquivoInvoke2(Object[] parameters) throws com.ibm.ws.webservices.engine.WebServicesFault  {
        com.ibm.ws.webservices.engine.MessageContext mc = super.messageContexts[_confirmarRecebimentoArquivoIndex2];
        if (mc == null) {
            mc = new com.ibm.ws.webservices.engine.MessageContext(super.engine);
            mc.setOperation(DocumentoStub._confirmarRecebimentoArquivoOperation2);
            mc.setUseSOAPAction(true);
            mc.setSOAPActionURI("http://acordosplanoseconomicos.febraban.org.br/IDocumentoService/ConfirmarRecebimentoArquivo");
            mc.setEncodingStyle(com.ibm.ws.webservices.engine.Constants.URI_LITERAL_ENC);
            mc.setProperty(com.ibm.wsspi.webservices.Constants.SEND_TYPE_ATTR_PROPERTY, Boolean.FALSE);
            mc.setProperty(com.ibm.wsspi.webservices.Constants.ENGINE_DO_MULTI_REFS_PROPERTY, Boolean.FALSE);
            super.primeMessageContext(mc);
            super.messageContexts[_confirmarRecebimentoArquivoIndex2] = mc;
        }
        try {
            mc = (com.ibm.ws.webservices.engine.MessageContext) mc.clone();
        }
        catch (CloneNotSupportedException cnse) {
            throw com.ibm.ws.webservices.engine.WebServicesFault.makeFault(cnse);
        }
        return new com.ibm.ws.webservices.engine.client.Stub.Invoke(connection, mc, parameters);
    }

    public br.org.febraban.acordosplanoseconomicos.RespostaOperacaoConfirmarRecebimentoArquivo[] confirmarRecebimentoArquivo(br.org.febraban.acordosplanoseconomicos.RequisicaoConfirmacaoRecebimentoArquivo requisicao) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new com.ibm.ws.webservices.engine.NoEndPointException();
        }
        java.util.Vector _resp = null;
        try {
            _resp = _getconfirmarRecebimentoArquivoInvoke2(new java.lang.Object[] {requisicao}).invoke();

        } catch (com.ibm.ws.webservices.engine.WebServicesFault wsf) {
            Exception e = wsf.getUserException();
            throw wsf;
        } 
        try {
            return (br.org.febraban.acordosplanoseconomicos.RespostaOperacaoConfirmarRecebimentoArquivo[]) ((com.ibm.ws.webservices.engine.xmlsoap.ext.ParamValue) _resp.get(0)).getValue();
        } catch (java.lang.Exception _exception) {
            return (br.org.febraban.acordosplanoseconomicos.RespostaOperacaoConfirmarRecebimentoArquivo[]) super.convert(((com.ibm.ws.webservices.engine.xmlsoap.ext.ParamValue) _resp.get(0)).getValue(), br.org.febraban.acordosplanoseconomicos.RespostaOperacaoConfirmarRecebimentoArquivo[].class);
        }
    }

    private static void _staticInit() {
        _confirmarRecebimentoArquivoOperation2 = _getconfirmarRecebimentoArquivoOperation2();
        _obterDocumentoOperation0 = _getobterDocumentoOperation0();
        _obterArquivoOperation1 = _getobterArquivoOperation1();
    }

    static {
       _staticInit();
    }
}
