/**
 * Dominio.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf031428.03 v72314182347
 */

package br.org.febraban.acordosplanoseconomicos;

public class Dominio  {
    private int id;
    private java.lang.String nome;
    private br.org.febraban.acordosplanoseconomicos.DominioItem[] itens;

    public Dominio() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public java.lang.String getNome() {
        return nome;
    }

    public void setNome(java.lang.String nome) {
        this.nome = nome;
    }

    public br.org.febraban.acordosplanoseconomicos.DominioItem[] getItens() {
        return itens;
    }

    public void setItens(br.org.febraban.acordosplanoseconomicos.DominioItem[] itens) {
        this.itens = itens;
    }

}
