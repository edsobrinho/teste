/**
 * Endereco.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf031428.03 v72314182347
 */

package br.org.febraban.acordosplanoseconomicos;

public class Endereco  {
    private java.lang.String CEP;
    private java.lang.String UF;
    private java.lang.String cidade;
    private java.lang.String bairro;
    private java.lang.String tipoLogradouro;
    private java.lang.String logradouro;
    private java.lang.String complemento;
    private java.lang.String numero;

    public Endereco() {
    }

    public java.lang.String getCEP() {
        return CEP;
    }

    public void setCEP(java.lang.String CEP) {
        this.CEP = CEP;
    }

    public java.lang.String getUF() {
        return UF;
    }

    public void setUF(java.lang.String UF) {
        this.UF = UF;
    }

    public java.lang.String getCidade() {
        return cidade;
    }

    public void setCidade(java.lang.String cidade) {
        this.cidade = cidade;
    }

    public java.lang.String getBairro() {
        return bairro;
    }

    public void setBairro(java.lang.String bairro) {
        this.bairro = bairro;
    }

    public java.lang.String getTipoLogradouro() {
        return tipoLogradouro;
    }

    public void setTipoLogradouro(java.lang.String tipoLogradouro) {
        this.tipoLogradouro = tipoLogradouro;
    }

    public java.lang.String getLogradouro() {
        return logradouro;
    }

    public void setLogradouro(java.lang.String logradouro) {
        this.logradouro = logradouro;
    }

    public java.lang.String getComplemento() {
        return complemento;
    }

    public void setComplemento(java.lang.String complemento) {
        this.complemento = complemento;
    }

    public java.lang.String getNumero() {
        return numero;
    }

    public void setNumero(java.lang.String numero) {
        this.numero = numero;
    }

}
