/**
 * Endereco_Deser.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf031428.03 v72314182347
 */

package br.org.febraban.acordosplanoseconomicos;

public class Endereco_Deser extends com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializer {
    /**
     * Constructor
     */
    public Endereco_Deser(
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType, 
           com.ibm.ws.webservices.engine.description.TypeDesc _typeDesc) {
        super(_javaType, _xmlType, _typeDesc);
    }
    /**
     * Create instance of java bean
     */
    public void createValue() {
        value = new Endereco();
    }
    protected boolean tryElementSetFromString(javax.xml.namespace.QName qName, java.lang.String strValue) {
        if (qName==QName_15_116) {
          ((Endereco)value).setCEP(strValue);
          return true;}
        else if (qName==QName_15_97) {
          ((Endereco)value).setUF(strValue);
          return true;}
        else if (qName==QName_15_117) {
          ((Endereco)value).setCidade(strValue);
          return true;}
        else if (qName==QName_15_118) {
          ((Endereco)value).setBairro(strValue);
          return true;}
        else if (qName==QName_15_119) {
          ((Endereco)value).setTipoLogradouro(strValue);
          return true;}
        else if (qName==QName_15_120) {
          ((Endereco)value).setLogradouro(strValue);
          return true;}
        else if (qName==QName_15_121) {
          ((Endereco)value).setComplemento(strValue);
          return true;}
        else if (qName==QName_15_110) {
          ((Endereco)value).setNumero(strValue);
          return true;}
        return false;
    }
    protected boolean tryAttributeSetFromString(javax.xml.namespace.QName qName, java.lang.String strValue) {
        return false;
    }
    protected boolean tryElementSetFromObject(javax.xml.namespace.QName qName, java.lang.Object objValue) {
        return false;
    }
    protected boolean tryElementSetFromList(javax.xml.namespace.QName qName, java.util.List listValue) {
        return false;
    }
    private final static javax.xml.namespace.QName QName_15_117 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/tipos",
                  "Cidade");
    private final static javax.xml.namespace.QName QName_15_119 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/tipos",
                  "TipoLogradouro");
    private final static javax.xml.namespace.QName QName_15_110 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/tipos",
                  "Numero");
    private final static javax.xml.namespace.QName QName_15_120 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/tipos",
                  "Logradouro");
    private final static javax.xml.namespace.QName QName_15_121 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/tipos",
                  "Complemento");
    private final static javax.xml.namespace.QName QName_15_118 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/tipos",
                  "Bairro");
    private final static javax.xml.namespace.QName QName_15_116 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/tipos",
                  "CEP");
    private final static javax.xml.namespace.QName QName_15_97 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/tipos",
                  "UF");
}
