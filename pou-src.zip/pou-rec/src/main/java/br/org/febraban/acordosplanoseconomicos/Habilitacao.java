/**
 * Habilitacao.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf031428.03 v72314182347
 */

package br.org.febraban.acordosplanoseconomicos;

public class Habilitacao  {
    private java.lang.String protocolo;

    public Habilitacao() {
    }

    public java.lang.String getProtocolo() {
        return protocolo;
    }

    public void setProtocolo(java.lang.String protocolo) {
        this.protocolo = protocolo;
    }

}
