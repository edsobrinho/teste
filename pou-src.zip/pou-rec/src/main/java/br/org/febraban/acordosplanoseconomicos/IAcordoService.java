/**
 * IAcordoService.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf031428.03 v72314182347
 */

package br.org.febraban.acordosplanoseconomicos;

public interface IAcordoService extends java.rmi.Remote {
    public br.org.febraban.acordosplanoseconomicos.RespostaOperacao cadastrarResultadoAnalisePedido(br.org.febraban.acordosplanoseconomicos.ResultadoAnalisePedido resultadoAnalisePedido) throws java.rmi.RemoteException;
    public br.org.febraban.acordosplanoseconomicos.AceiteProposta[] obterRespostaProposta(br.org.febraban.acordosplanoseconomicos.RespostaPropostaFiltro filtro) throws java.rmi.RemoteException;
    public br.org.febraban.acordosplanoseconomicos.RespostaOperacao informarPagamento(br.org.febraban.acordosplanoseconomicos.PagamentoAcordo pagamento) throws java.rmi.RemoteException;
}
