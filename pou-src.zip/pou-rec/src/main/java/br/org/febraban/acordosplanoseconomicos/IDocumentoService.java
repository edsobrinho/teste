/**
 * IDocumentoService.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf031428.03 v72314182347
 */

package br.org.febraban.acordosplanoseconomicos;

public interface IDocumentoService extends java.rmi.Remote {
    public br.org.febraban.acordosplanoseconomicos.Documento[] obterDocumento(java.lang.String guidPedido) throws java.rmi.RemoteException;
    public br.org.febraban.acordosplanoseconomicos.Arquivo obterArquivo(br.org.febraban.acordosplanoseconomicos.IdentificadorArquivo requisicao) throws java.rmi.RemoteException;
    public br.org.febraban.acordosplanoseconomicos.RespostaOperacaoConfirmarRecebimentoArquivo[] confirmarRecebimentoArquivo(br.org.febraban.acordosplanoseconomicos.RequisicaoConfirmacaoRecebimentoArquivo requisicao) throws java.rmi.RemoteException;
}
