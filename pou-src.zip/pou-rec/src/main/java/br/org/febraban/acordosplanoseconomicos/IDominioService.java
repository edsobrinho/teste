/**
 * IDominioService.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf031428.03 v72314182347
 */

package br.org.febraban.acordosplanoseconomicos;

public interface IDominioService extends java.rmi.Remote {
    public br.org.febraban.acordosplanoseconomicos.Dominio[] obterDominio() throws java.rmi.RemoteException;
}
