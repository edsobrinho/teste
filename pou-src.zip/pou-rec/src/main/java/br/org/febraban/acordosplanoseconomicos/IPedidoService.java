/**
 * IPedidoService.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf031428.03 v72314182347
 */

package br.org.febraban.acordosplanoseconomicos;

public interface IPedidoService extends java.rmi.Remote {
    public br.org.febraban.acordosplanoseconomicos.RespostaObterPedido obterPedido(br.org.febraban.acordosplanoseconomicos.PedidoFiltro solicitacao) throws java.rmi.RemoteException;
    public br.org.febraban.acordosplanoseconomicos.RespostaConfirmacaoRecebimentoPedido[] confirmarRecebimentoPedido(br.org.febraban.acordosplanoseconomicos.ConfirmacaoPedidosRecebidos pedidosRecebidos) throws java.rmi.RemoteException;
}
