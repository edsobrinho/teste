/**
 * Identidade.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf031428.03 v72314182347
 */

package br.org.febraban.acordosplanoseconomicos;

public class Identidade  {
    private java.lang.String numero;
    private java.lang.String orgao;
    private java.lang.String UF;
    private br.org.febraban.acordosplanoseconomicos.TipoIdentidadeEnum tipo;
    private java.lang.String classificacao;
    private java.lang.String validade;

    public Identidade() {
    }

    public java.lang.String getNumero() {
        return numero;
    }

    public void setNumero(java.lang.String numero) {
        this.numero = numero;
    }

    public java.lang.String getOrgao() {
        return orgao;
    }

    public void setOrgao(java.lang.String orgao) {
        this.orgao = orgao;
    }

    public java.lang.String getUF() {
        return UF;
    }

    public void setUF(java.lang.String UF) {
        this.UF = UF;
    }

    public br.org.febraban.acordosplanoseconomicos.TipoIdentidadeEnum getTipo() {
        return tipo;
    }

    public void setTipo(br.org.febraban.acordosplanoseconomicos.TipoIdentidadeEnum tipo) {
        this.tipo = tipo;
    }

    public java.lang.String getClassificacao() {
        return classificacao;
    }

    public void setClassificacao(java.lang.String classificacao) {
        this.classificacao = classificacao;
    }

    public java.lang.String getValidade() {
        return validade;
    }

    public void setValidade(java.lang.String validade) {
        this.validade = validade;
    }

}
