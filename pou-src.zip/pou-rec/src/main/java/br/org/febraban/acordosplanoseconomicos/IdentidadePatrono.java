/**
 * IdentidadePatrono.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf031428.03 v72314182347
 */

package br.org.febraban.acordosplanoseconomicos;

public class IdentidadePatrono  {
    private br.org.febraban.acordosplanoseconomicos.EsferaEnum esfera;
    private java.lang.String UF;
    private java.lang.String numero;

    public IdentidadePatrono() {
    }

    public br.org.febraban.acordosplanoseconomicos.EsferaEnum getEsfera() {
        return esfera;
    }

    public void setEsfera(br.org.febraban.acordosplanoseconomicos.EsferaEnum esfera) {
        this.esfera = esfera;
    }

    public java.lang.String getUF() {
        return UF;
    }

    public void setUF(java.lang.String UF) {
        this.UF = UF;
    }

    public java.lang.String getNumero() {
        return numero;
    }

    public void setNumero(java.lang.String numero) {
        this.numero = numero;
    }

}
