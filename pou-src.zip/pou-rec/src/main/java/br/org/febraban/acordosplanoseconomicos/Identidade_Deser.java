/**
 * Identidade_Deser.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf031428.03 v72314182347
 */

package br.org.febraban.acordosplanoseconomicos;

public class Identidade_Deser extends com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializer {
    /**
     * Constructor
     */
    public Identidade_Deser(
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType, 
           com.ibm.ws.webservices.engine.description.TypeDesc _typeDesc) {
        super(_javaType, _xmlType, _typeDesc);
    }
    /**
     * Create instance of java bean
     */
    public void createValue() {
        value = new Identidade();
    }
    protected boolean tryElementSetFromString(javax.xml.namespace.QName qName, java.lang.String strValue) {
        if (qName==QName_15_110) {
          ((Identidade)value).setNumero(strValue);
          return true;}
        else if (qName==QName_15_111) {
          ((Identidade)value).setOrgao(strValue);
          return true;}
        else if (qName==QName_15_97) {
          ((Identidade)value).setUF(strValue);
          return true;}
        else if (qName==QName_15_113) {
          ((Identidade)value).setClassificacao(strValue);
          return true;}
        else if (qName==QName_15_114) {
          ((Identidade)value).setValidade(strValue);
          return true;}
        return false;
    }
    protected boolean tryAttributeSetFromString(javax.xml.namespace.QName qName, java.lang.String strValue) {
        return false;
    }
    protected boolean tryElementSetFromObject(javax.xml.namespace.QName qName, java.lang.Object objValue) {
        if (qName==QName_15_112) {
          ((Identidade)value).setTipo((br.org.febraban.acordosplanoseconomicos.TipoIdentidadeEnum)objValue);
          return true;}
        return false;
    }
    protected boolean tryElementSetFromList(javax.xml.namespace.QName qName, java.util.List listValue) {
        return false;
    }
    private final static javax.xml.namespace.QName QName_15_112 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/tipos",
                  "Tipo");
    private final static javax.xml.namespace.QName QName_15_110 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/tipos",
                  "Numero");
    private final static javax.xml.namespace.QName QName_15_113 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/tipos",
                  "Classificacao");
    private final static javax.xml.namespace.QName QName_15_111 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/tipos",
                  "Orgao");
    private final static javax.xml.namespace.QName QName_15_114 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/tipos",
                  "Validade");
    private final static javax.xml.namespace.QName QName_15_97 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/tipos",
                  "UF");
}
