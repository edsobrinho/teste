/**
 * IdentificadorArquivo.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf031428.03 v72314182347
 */

package br.org.febraban.acordosplanoseconomicos;

public class IdentificadorArquivo  {
    private java.lang.String guidPedido;
    private int identificadorDocumento;

    public IdentificadorArquivo() {
    }

    public java.lang.String getGuidPedido() {
        return guidPedido;
    }

    public void setGuidPedido(java.lang.String guidPedido) {
        this.guidPedido = guidPedido;
    }

    public int getIdentificadorDocumento() {
        return identificadorDocumento;
    }

    public void setIdentificadorDocumento(int identificadorDocumento) {
        this.identificadorDocumento = identificadorDocumento;
    }

}
