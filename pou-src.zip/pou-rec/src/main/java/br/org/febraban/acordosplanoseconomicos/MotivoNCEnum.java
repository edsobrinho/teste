/**
 * MotivoNCEnum.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf031428.03 v72314182347
 */

package br.org.febraban.acordosplanoseconomicos;

public class MotivoNCEnum  {
    private java.lang.String _value_;
    private static java.util.HashMap _table_ = new java.util.HashMap();

    // Constructor
    protected MotivoNCEnum(java.lang.String value) {
        _value_ = value;
        _table_.put(_value_,this);
    };

    public static final java.lang.String _HABILITACAO_DUPLICADA_PARA_MESMO_CPF_PROCESSO = "HABILITACAO_DUPLICADA_PARA_MESMO_CPF_PROCESSO";
    public static final java.lang.String _HABILITACAO_DUPLICADA_PEDIDO_PLEITEADO_PELO_MESMO_CPF_EM_PROCESSO_DIFERENTE = "HABILITACAO_DUPLICADA_PEDIDO_PLEITEADO_PELO_MESMO_CPF_EM_PROCESSO_DIFERENTE";
    public static final java.lang.String _HABILITACAO_DUPLICADA_PEDIDO_PLEITEADO_CPF_DISTINTO_EM_PROCESSO_DIFERENTE = "HABILITACAO_DUPLICADA_PEDIDO_PLEITEADO_CPF_DISTINTO_EM_PROCESSO_DIFERENTE";
    public static final java.lang.String _PROCESSO_NAO_LOCALIZADO_NO_JUDICIARIO = "PROCESSO_NAO_LOCALIZADO_NO_JUDICIARIO";
    public static final java.lang.String _INFORMACAO_DIVERGENTE = "INFORMACAO_DIVERGENTE";
    public static final java.lang.String _INFORMACAO_NAO_LEGIVEL = "INFORMACAO_NAO_LEGIVEL";
    public static final java.lang.String _INFORMACAO_NAO_DISPONIVEL = "INFORMACAO_NAO_DISPONIVEL";
    public static final MotivoNCEnum HABILITACAO_DUPLICADA_PARA_MESMO_CPF_PROCESSO = new MotivoNCEnum(_HABILITACAO_DUPLICADA_PARA_MESMO_CPF_PROCESSO);
    public static final MotivoNCEnum HABILITACAO_DUPLICADA_PEDIDO_PLEITEADO_PELO_MESMO_CPF_EM_PROCESSO_DIFERENTE = new MotivoNCEnum(_HABILITACAO_DUPLICADA_PEDIDO_PLEITEADO_PELO_MESMO_CPF_EM_PROCESSO_DIFERENTE);
    public static final MotivoNCEnum HABILITACAO_DUPLICADA_PEDIDO_PLEITEADO_CPF_DISTINTO_EM_PROCESSO_DIFERENTE = new MotivoNCEnum(_HABILITACAO_DUPLICADA_PEDIDO_PLEITEADO_CPF_DISTINTO_EM_PROCESSO_DIFERENTE);
    public static final MotivoNCEnum PROCESSO_NAO_LOCALIZADO_NO_JUDICIARIO = new MotivoNCEnum(_PROCESSO_NAO_LOCALIZADO_NO_JUDICIARIO);
    public static final MotivoNCEnum INFORMACAO_DIVERGENTE = new MotivoNCEnum(_INFORMACAO_DIVERGENTE);
    public static final MotivoNCEnum INFORMACAO_NAO_LEGIVEL = new MotivoNCEnum(_INFORMACAO_NAO_LEGIVEL);
    public static final MotivoNCEnum INFORMACAO_NAO_DISPONIVEL = new MotivoNCEnum(_INFORMACAO_NAO_DISPONIVEL);
    public java.lang.String getValue() { return _value_;}
    public static MotivoNCEnum fromValue(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        MotivoNCEnum enumeration = (MotivoNCEnum)
            _table_.get(value);
        if (enumeration==null) throw new java.lang.IllegalArgumentException();
        return enumeration;
    }
    public static MotivoNCEnum fromString(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        return fromValue(value);
    }
    public boolean equals(java.lang.Object obj) {return (obj == this);}
    public int hashCode() { return toString().hashCode();}
    public java.lang.String toString() { return _value_;}

}
