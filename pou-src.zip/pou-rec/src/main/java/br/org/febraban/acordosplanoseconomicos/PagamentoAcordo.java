/**
 * PagamentoAcordo.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf031428.03 v72314182347
 */

package br.org.febraban.acordosplanoseconomicos;

public class PagamentoAcordo  {
    private java.lang.String guidPedido;
    private int identificadorPropostaBanco;
    private java.lang.String dataPagamento;
    private double valorPagamento;
    private int numeroParcela;
    private br.org.febraban.acordosplanoseconomicos.Arquivo comprovante;
    private br.org.febraban.acordosplanoseconomicos.StatusPagamentoEnum statusPagamento;
    private java.lang.String observacoesPagamento;
    private br.org.febraban.acordosplanoseconomicos.ContaPagamento contaPagamentoAcordo;

    public PagamentoAcordo() {
    }

    public java.lang.String getGuidPedido() {
        return guidPedido;
    }

    public void setGuidPedido(java.lang.String guidPedido) {
        this.guidPedido = guidPedido;
    }

    public int getIdentificadorPropostaBanco() {
        return identificadorPropostaBanco;
    }

    public void setIdentificadorPropostaBanco(int identificadorPropostaBanco) {
        this.identificadorPropostaBanco = identificadorPropostaBanco;
    }

    public java.lang.String getDataPagamento() {
        return dataPagamento;
    }

    public void setDataPagamento(java.lang.String dataPagamento) {
        this.dataPagamento = dataPagamento;
    }

    public double getValorPagamento() {
        return valorPagamento;
    }

    public void setValorPagamento(double valorPagamento) {
        this.valorPagamento = valorPagamento;
    }

    public int getNumeroParcela() {
        return numeroParcela;
    }

    public void setNumeroParcela(int numeroParcela) {
        this.numeroParcela = numeroParcela;
    }

    public br.org.febraban.acordosplanoseconomicos.Arquivo getComprovante() {
        return comprovante;
    }

    public void setComprovante(br.org.febraban.acordosplanoseconomicos.Arquivo comprovante) {
        this.comprovante = comprovante;
    }

    public br.org.febraban.acordosplanoseconomicos.StatusPagamentoEnum getStatusPagamento() {
        return statusPagamento;
    }

    public void setStatusPagamento(br.org.febraban.acordosplanoseconomicos.StatusPagamentoEnum statusPagamento) {
        this.statusPagamento = statusPagamento;
    }

    public java.lang.String getObservacoesPagamento() {
        return observacoesPagamento;
    }

    public void setObservacoesPagamento(java.lang.String observacoesPagamento) {
        this.observacoesPagamento = observacoesPagamento;
    }

    public br.org.febraban.acordosplanoseconomicos.ContaPagamento getContaPagamentoAcordo() {
        return contaPagamentoAcordo;
    }

    public void setContaPagamentoAcordo(br.org.febraban.acordosplanoseconomicos.ContaPagamento contaPagamentoAcordo) {
        this.contaPagamentoAcordo = contaPagamentoAcordo;
    }

}
