/**
 * PagamentoAcordo_Deser.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf031428.03 v72314182347
 */

package br.org.febraban.acordosplanoseconomicos;

public class PagamentoAcordo_Deser extends com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializer {
    /**
     * Constructor
     */
    public PagamentoAcordo_Deser(
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType, 
           com.ibm.ws.webservices.engine.description.TypeDesc _typeDesc) {
        super(_javaType, _xmlType, _typeDesc);
    }
    /**
     * Create instance of java bean
     */
    public void createValue() {
        value = new PagamentoAcordo();
    }
    protected boolean tryElementSetFromString(javax.xml.namespace.QName qName, java.lang.String strValue) {
        if (qName==QName_9_2) {
          ((PagamentoAcordo)value).setGuidPedido(strValue);
          return true;}
        else if (qName==QName_9_25) {
          ((PagamentoAcordo)value).setIdentificadorPropostaBanco(com.ibm.ws.webservices.engine.encoding.ser.SimpleDeserializer.parseint(strValue));
          return true;}
        else if (qName==QName_9_26) {
          ((PagamentoAcordo)value).setDataPagamento(strValue);
          return true;}
        else if (qName==QName_9_27) {
          ((PagamentoAcordo)value).setValorPagamento(com.ibm.ws.webservices.engine.encoding.ser.SimpleDeserializer.parsedouble(strValue));
          return true;}
        else if (qName==QName_9_28) {
          ((PagamentoAcordo)value).setNumeroParcela(com.ibm.ws.webservices.engine.encoding.ser.SimpleDeserializer.parseint(strValue));
          return true;}
        else if (qName==QName_9_31) {
          ((PagamentoAcordo)value).setObservacoesPagamento(strValue);
          return true;}
        return false;
    }
    protected boolean tryAttributeSetFromString(javax.xml.namespace.QName qName, java.lang.String strValue) {
        return false;
    }
    protected boolean tryElementSetFromObject(javax.xml.namespace.QName qName, java.lang.Object objValue) {
        if (qName==QName_9_29) {
          ((PagamentoAcordo)value).setComprovante((br.org.febraban.acordosplanoseconomicos.Arquivo)objValue);
          return true;}
        else if (qName==QName_9_30) {
          ((PagamentoAcordo)value).setStatusPagamento((br.org.febraban.acordosplanoseconomicos.StatusPagamentoEnum)objValue);
          return true;}
        else if (qName==QName_9_32) {
          ((PagamentoAcordo)value).setContaPagamentoAcordo((br.org.febraban.acordosplanoseconomicos.ContaPagamento)objValue);
          return true;}
        return false;
    }
    protected boolean tryElementSetFromList(javax.xml.namespace.QName qName, java.util.List listValue) {
        return false;
    }
    private final static javax.xml.namespace.QName QName_9_32 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/acordos",
                  "ContaPagamentoAcordo");
    private final static javax.xml.namespace.QName QName_9_28 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/acordos",
                  "NumeroParcela");
    private final static javax.xml.namespace.QName QName_9_26 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/acordos",
                  "DataPagamento");
    private final static javax.xml.namespace.QName QName_9_27 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/acordos",
                  "ValorPagamento");
    private final static javax.xml.namespace.QName QName_9_30 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/acordos",
                  "StatusPagamento");
    private final static javax.xml.namespace.QName QName_9_25 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/acordos",
                  "IdentificadorPropostaBanco");
    private final static javax.xml.namespace.QName QName_9_31 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/acordos",
                  "ObservacoesPagamento");
    private final static javax.xml.namespace.QName QName_9_2 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/acordos",
                  "GuidPedido");
    private final static javax.xml.namespace.QName QName_9_29 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/acordos",
                  "Comprovante");
}
