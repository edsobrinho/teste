/**
 * PagamentoAcordo_Ser.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf031428.03 v72314182347
 */

package br.org.febraban.acordosplanoseconomicos;

public class PagamentoAcordo_Ser extends com.ibm.ws.webservices.engine.encoding.ser.BeanSerializer {
    /**
     * Constructor
     */
    public PagamentoAcordo_Ser(
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType, 
           com.ibm.ws.webservices.engine.description.TypeDesc _typeDesc) {
        super(_javaType, _xmlType, _typeDesc);
    }
    public void serialize(
        javax.xml.namespace.QName name,
        org.xml.sax.Attributes attributes,
        java.lang.Object value,
        com.ibm.ws.webservices.engine.encoding.SerializationContext context)
        throws java.io.IOException
    {
        context.startElement(name, addAttributes(attributes, value, context));
        addElements(value, context);
        context.endElement();
    }
    protected org.xml.sax.Attributes addAttributes(
        org.xml.sax.Attributes attributes,
        java.lang.Object value,
        com.ibm.ws.webservices.engine.encoding.SerializationContext context)
        throws java.io.IOException
    {
           javax.xml.namespace.QName
           elemQName = QName_9_2;
           context.qName2String(elemQName, true);
           elemQName = QName_9_25;
           context.qName2String(elemQName, true);
           elemQName = QName_9_26;
           context.qName2String(elemQName, true);
           elemQName = QName_9_27;
           context.qName2String(elemQName, true);
           elemQName = QName_9_28;
           context.qName2String(elemQName, true);
           elemQName = QName_9_29;
           context.qName2String(elemQName, true);
           elemQName = QName_9_30;
           context.qName2String(elemQName, true);
           elemQName = QName_9_31;
           context.qName2String(elemQName, true);
           elemQName = QName_9_32;
           context.qName2String(elemQName, true);
        return attributes;
    }
    protected void addElements(
        java.lang.Object value,
        com.ibm.ws.webservices.engine.encoding.SerializationContext context)
        throws java.io.IOException
    {
        PagamentoAcordo bean = (PagamentoAcordo) value;
        java.lang.Object propValue;
        javax.xml.namespace.QName propQName;
        {
          propQName = QName_9_2;
          propValue = bean.getGuidPedido();
          if (propValue != null && !context.shouldSendXSIType()) {
            context.simpleElement(propQName, null, propValue.toString()); 
          } else {
            serializeChild(propQName, null, 
              propValue, 
              QName_1_5,
              true,null,context);
          }
          propQName = QName_9_25;
          propValue = new java.lang.Integer(bean.getIdentificadorPropostaBanco());
          serializeChild(propQName, null, 
              propValue, 
              QName_1_6,
              true,null,context);
          propQName = QName_9_26;
          propValue = bean.getDataPagamento();
          if (propValue != null && !context.shouldSendXSIType()) {
            context.simpleElement(propQName, null, propValue.toString()); 
          } else {
            serializeChild(propQName, null, 
              propValue, 
              QName_1_5,
              true,null,context);
          }
          propQName = QName_9_27;
          propValue = new java.lang.Double(bean.getValorPagamento());
          serializeChild(propQName, null, 
              propValue, 
              QName_1_33,
              true,null,context);
          propQName = QName_9_28;
          propValue = new java.lang.Integer(bean.getNumeroParcela());
          serializeChild(propQName, null, 
              propValue, 
              QName_1_6,
              true,null,context);
          propQName = QName_9_29;
          propValue = bean.getComprovante();
          serializeChild(propQName, null, 
              propValue, 
              QName_12_34,
              true,null,context);
          propQName = QName_9_30;
          propValue = bean.getStatusPagamento();
          serializeChild(propQName, null, 
              propValue, 
              QName_10_35,
              true,null,context);
          propQName = QName_9_31;
          propValue = bean.getObservacoesPagamento();
          if (propValue != null && !context.shouldSendXSIType()) {
            context.simpleElement(propQName, null, propValue.toString()); 
          } else {
            serializeChild(propQName, null, 
              propValue, 
              QName_1_5,
              false,null,context);
          }
          propQName = QName_9_32;
          propValue = bean.getContaPagamentoAcordo();
          serializeChild(propQName, null, 
              propValue, 
              QName_4_36,
              false,null,context);
        }
    }
    private final static javax.xml.namespace.QName QName_9_32 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/acordos",
                  "ContaPagamentoAcordo");
    private final static javax.xml.namespace.QName QName_1_6 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://www.w3.org/2001/XMLSchema",
                  "int");
    private final static javax.xml.namespace.QName QName_4_36 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "ContaPagamento");
    private final static javax.xml.namespace.QName QName_9_28 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/acordos",
                  "NumeroParcela");
    private final static javax.xml.namespace.QName QName_1_33 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://www.w3.org/2001/XMLSchema",
                  "double");
    private final static javax.xml.namespace.QName QName_9_26 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/acordos",
                  "DataPagamento");
    private final static javax.xml.namespace.QName QName_9_27 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/acordos",
                  "ValorPagamento");
    private final static javax.xml.namespace.QName QName_9_30 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/acordos",
                  "StatusPagamento");
    private final static javax.xml.namespace.QName QName_12_34 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/documentos",
                  "Arquivo");
    private final static javax.xml.namespace.QName QName_1_5 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://www.w3.org/2001/XMLSchema",
                  "string");
    private final static javax.xml.namespace.QName QName_9_25 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/acordos",
                  "IdentificadorPropostaBanco");
    private final static javax.xml.namespace.QName QName_10_35 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/acordos/enums",
                  "StatusPagamentoEnum");
    private final static javax.xml.namespace.QName QName_9_31 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/acordos",
                  "ObservacoesPagamento");
    private final static javax.xml.namespace.QName QName_9_2 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/acordos",
                  "GuidPedido");
    private final static javax.xml.namespace.QName QName_9_29 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/acordos",
                  "Comprovante");
}
