/**
 * Parte.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf031428.03 v72314182347
 */

package br.org.febraban.acordosplanoseconomicos;

public class Parte  {
    private int id;
    private java.lang.String cpf;
    private java.lang.String nome;
    private br.org.febraban.acordosplanoseconomicos.Identidade identidade;
    private java.lang.String dataNascimento;
    private boolean falecido;
    private java.lang.String dataObito;
    private br.org.febraban.acordosplanoseconomicos.Endereco enderecoCorrespondencia;
    private br.org.febraban.acordosplanoseconomicos.Contato contato;
    private br.org.febraban.acordosplanoseconomicos.QualificacaoEnvolvidoEnum qualificacao;

    public Parte() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public java.lang.String getCpf() {
        return cpf;
    }

    public void setCpf(java.lang.String cpf) {
        this.cpf = cpf;
    }

    public java.lang.String getNome() {
        return nome;
    }

    public void setNome(java.lang.String nome) {
        this.nome = nome;
    }

    public br.org.febraban.acordosplanoseconomicos.Identidade getIdentidade() {
        return identidade;
    }

    public void setIdentidade(br.org.febraban.acordosplanoseconomicos.Identidade identidade) {
        this.identidade = identidade;
    }

    public java.lang.String getDataNascimento() {
        return dataNascimento;
    }

    public void setDataNascimento(java.lang.String dataNascimento) {
        this.dataNascimento = dataNascimento;
    }

    public boolean isFalecido() {
        return falecido;
    }

    public void setFalecido(boolean falecido) {
        this.falecido = falecido;
    }

    public java.lang.String getDataObito() {
        return dataObito;
    }

    public void setDataObito(java.lang.String dataObito) {
        this.dataObito = dataObito;
    }

    public br.org.febraban.acordosplanoseconomicos.Endereco getEnderecoCorrespondencia() {
        return enderecoCorrespondencia;
    }

    public void setEnderecoCorrespondencia(br.org.febraban.acordosplanoseconomicos.Endereco enderecoCorrespondencia) {
        this.enderecoCorrespondencia = enderecoCorrespondencia;
    }

    public br.org.febraban.acordosplanoseconomicos.Contato getContato() {
        return contato;
    }

    public void setContato(br.org.febraban.acordosplanoseconomicos.Contato contato) {
        this.contato = contato;
    }

    public br.org.febraban.acordosplanoseconomicos.QualificacaoEnvolvidoEnum getQualificacao() {
        return qualificacao;
    }

    public void setQualificacao(br.org.febraban.acordosplanoseconomicos.QualificacaoEnvolvidoEnum qualificacao) {
        this.qualificacao = qualificacao;
    }

}
