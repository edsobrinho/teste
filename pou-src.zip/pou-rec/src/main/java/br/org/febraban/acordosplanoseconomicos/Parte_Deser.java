/**
 * Parte_Deser.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf031428.03 v72314182347
 */

package br.org.febraban.acordosplanoseconomicos;

public class Parte_Deser extends com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializer {
    /**
     * Constructor
     */
    public Parte_Deser(
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType, 
           com.ibm.ws.webservices.engine.description.TypeDesc _typeDesc) {
        super(_javaType, _xmlType, _typeDesc);
    }
    /**
     * Create instance of java bean
     */
    public void createValue() {
        value = new Parte();
    }
    protected boolean tryElementSetFromString(javax.xml.namespace.QName qName, java.lang.String strValue) {
        if (qName==QName_4_66) {
          ((Parte)value).setId(com.ibm.ws.webservices.engine.encoding.ser.SimpleDeserializer.parseint(strValue));
          return true;}
        else if (qName==QName_4_67) {
          ((Parte)value).setCpf(strValue);
          return true;}
        else if (qName==QName_4_68) {
          ((Parte)value).setNome(strValue);
          return true;}
        else if (qName==QName_4_70) {
          ((Parte)value).setDataNascimento(strValue);
          return true;}
        else if (qName==QName_4_71) {
          ((Parte)value).setFalecido(com.ibm.ws.webservices.engine.encoding.ser.SimpleDeserializer.parseboolean(strValue));
          return true;}
        else if (qName==QName_4_72) {
          ((Parte)value).setDataObito(strValue);
          return true;}
        return false;
    }
    protected boolean tryAttributeSetFromString(javax.xml.namespace.QName qName, java.lang.String strValue) {
        return false;
    }
    protected boolean tryElementSetFromObject(javax.xml.namespace.QName qName, java.lang.Object objValue) {
        if (qName==QName_4_69) {
          ((Parte)value).setIdentidade((br.org.febraban.acordosplanoseconomicos.Identidade)objValue);
          return true;}
        else if (qName==QName_4_73) {
          ((Parte)value).setEnderecoCorrespondencia((br.org.febraban.acordosplanoseconomicos.Endereco)objValue);
          return true;}
        else if (qName==QName_4_74) {
          ((Parte)value).setContato((br.org.febraban.acordosplanoseconomicos.Contato)objValue);
          return true;}
        else if (qName==QName_4_75) {
          ((Parte)value).setQualificacao((br.org.febraban.acordosplanoseconomicos.QualificacaoEnvolvidoEnum)objValue);
          return true;}
        return false;
    }
    protected boolean tryElementSetFromList(javax.xml.namespace.QName qName, java.util.List listValue) {
        return false;
    }
    private final static javax.xml.namespace.QName QName_4_75 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "Qualificacao");
    private final static javax.xml.namespace.QName QName_4_72 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "DataObito");
    private final static javax.xml.namespace.QName QName_4_68 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "Nome");
    private final static javax.xml.namespace.QName QName_4_66 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "Id");
    private final static javax.xml.namespace.QName QName_4_73 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "EnderecoCorrespondencia");
    private final static javax.xml.namespace.QName QName_4_69 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "Identidade");
    private final static javax.xml.namespace.QName QName_4_71 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "Falecido");
    private final static javax.xml.namespace.QName QName_4_67 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "Cpf");
    private final static javax.xml.namespace.QName QName_4_74 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "Contato");
    private final static javax.xml.namespace.QName QName_4_70 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "DataNascimento");
}
