/**
 * Pedido.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf031428.03 v72314182347
 */

package br.org.febraban.acordosplanoseconomicos;

public class Pedido  {
    private java.lang.String guidPedido;
    private java.lang.String protocolo;
    private int identificadorLoteHabilitacao;
    private java.lang.String dataAbertura;
    private br.org.febraban.acordosplanoseconomicos.StatusPedidoEnum statusPedido;
    private java.lang.Double valorCustasProcessuais;
    private java.lang.String dataConfimacaoLeituraBanco;
    private double valorTotalSimulado;
    private br.org.febraban.acordosplanoseconomicos.DestinatarioContaEnum destinatarioPagamentoAcordo;
    private br.org.febraban.acordosplanoseconomicos.Parte poupador;
    private br.org.febraban.acordosplanoseconomicos.Parte[] envolvidosEspolio;
    private br.org.febraban.acordosplanoseconomicos.Advogado patrono;
    private br.org.febraban.acordosplanoseconomicos.ContaPagamento contaPagamentoAcordo;
    private br.org.febraban.acordosplanoseconomicos.ContaPagamento contaPagamentoHonorario;
    private br.org.febraban.acordosplanoseconomicos.Processo processo;
    private br.org.febraban.acordosplanoseconomicos.ContaPlano[] contasContempladas;
    private br.org.febraban.acordosplanoseconomicos.Documento[] documentos;
    private br.org.febraban.acordosplanoseconomicos.BPO resultadoBPO;

    public Pedido() {
    }

    public java.lang.String getGuidPedido() {
        return guidPedido;
    }

    public void setGuidPedido(java.lang.String guidPedido) {
        this.guidPedido = guidPedido;
    }

    public java.lang.String getProtocolo() {
        return protocolo;
    }

    public void setProtocolo(java.lang.String protocolo) {
        this.protocolo = protocolo;
    }

    public int getIdentificadorLoteHabilitacao() {
        return identificadorLoteHabilitacao;
    }

    public void setIdentificadorLoteHabilitacao(int identificadorLoteHabilitacao) {
        this.identificadorLoteHabilitacao = identificadorLoteHabilitacao;
    }

    public java.lang.String getDataAbertura() {
        return dataAbertura;
    }

    public void setDataAbertura(java.lang.String dataAbertura) {
        this.dataAbertura = dataAbertura;
    }

    public br.org.febraban.acordosplanoseconomicos.StatusPedidoEnum getStatusPedido() {
        return statusPedido;
    }

    public void setStatusPedido(br.org.febraban.acordosplanoseconomicos.StatusPedidoEnum statusPedido) {
        this.statusPedido = statusPedido;
    }

    public java.lang.Double getValorCustasProcessuais() {
        return valorCustasProcessuais;
    }

    public void setValorCustasProcessuais(java.lang.Double valorCustasProcessuais) {
        this.valorCustasProcessuais = valorCustasProcessuais;
    }

    public java.lang.String getDataConfimacaoLeituraBanco() {
        return dataConfimacaoLeituraBanco;
    }

    public void setDataConfimacaoLeituraBanco(java.lang.String dataConfimacaoLeituraBanco) {
        this.dataConfimacaoLeituraBanco = dataConfimacaoLeituraBanco;
    }

    public double getValorTotalSimulado() {
        return valorTotalSimulado;
    }

    public void setValorTotalSimulado(double valorTotalSimulado) {
        this.valorTotalSimulado = valorTotalSimulado;
    }

    public br.org.febraban.acordosplanoseconomicos.DestinatarioContaEnum getDestinatarioPagamentoAcordo() {
        return destinatarioPagamentoAcordo;
    }

    public void setDestinatarioPagamentoAcordo(br.org.febraban.acordosplanoseconomicos.DestinatarioContaEnum destinatarioPagamentoAcordo) {
        this.destinatarioPagamentoAcordo = destinatarioPagamentoAcordo;
    }

    public br.org.febraban.acordosplanoseconomicos.Parte getPoupador() {
        return poupador;
    }

    public void setPoupador(br.org.febraban.acordosplanoseconomicos.Parte poupador) {
        this.poupador = poupador;
    }

    public br.org.febraban.acordosplanoseconomicos.Parte[] getEnvolvidosEspolio() {
        return envolvidosEspolio;
    }

    public void setEnvolvidosEspolio(br.org.febraban.acordosplanoseconomicos.Parte[] envolvidosEspolio) {
        this.envolvidosEspolio = envolvidosEspolio;
    }

    public br.org.febraban.acordosplanoseconomicos.Advogado getPatrono() {
        return patrono;
    }

    public void setPatrono(br.org.febraban.acordosplanoseconomicos.Advogado patrono) {
        this.patrono = patrono;
    }

    public br.org.febraban.acordosplanoseconomicos.ContaPagamento getContaPagamentoAcordo() {
        return contaPagamentoAcordo;
    }

    public void setContaPagamentoAcordo(br.org.febraban.acordosplanoseconomicos.ContaPagamento contaPagamentoAcordo) {
        this.contaPagamentoAcordo = contaPagamentoAcordo;
    }

    public br.org.febraban.acordosplanoseconomicos.ContaPagamento getContaPagamentoHonorario() {
        return contaPagamentoHonorario;
    }

    public void setContaPagamentoHonorario(br.org.febraban.acordosplanoseconomicos.ContaPagamento contaPagamentoHonorario) {
        this.contaPagamentoHonorario = contaPagamentoHonorario;
    }

    public br.org.febraban.acordosplanoseconomicos.Processo getProcesso() {
        return processo;
    }

    public void setProcesso(br.org.febraban.acordosplanoseconomicos.Processo processo) {
        this.processo = processo;
    }

    public br.org.febraban.acordosplanoseconomicos.ContaPlano[] getContasContempladas() {
        return contasContempladas;
    }

    public void setContasContempladas(br.org.febraban.acordosplanoseconomicos.ContaPlano[] contasContempladas) {
        this.contasContempladas = contasContempladas;
    }

    public br.org.febraban.acordosplanoseconomicos.Documento[] getDocumentos() {
        return documentos;
    }

    public void setDocumentos(br.org.febraban.acordosplanoseconomicos.Documento[] documentos) {
        this.documentos = documentos;
    }

    public br.org.febraban.acordosplanoseconomicos.BPO getResultadoBPO() {
        return resultadoBPO;
    }

    public void setResultadoBPO(br.org.febraban.acordosplanoseconomicos.BPO resultadoBPO) {
        this.resultadoBPO = resultadoBPO;
    }

}
