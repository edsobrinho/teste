/**
 * PedidoFiltro.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf031428.03 v72314182347
 */

package br.org.febraban.acordosplanoseconomicos;

public class PedidoFiltro  {
    private java.lang.String dataFim;
    private java.lang.String dataInicio;
    private java.lang.String guidPedido;
    private java.lang.Integer quantidadeARetornar;
    private br.org.febraban.acordosplanoseconomicos.StatusPedidoEnum status;

    public PedidoFiltro() {
    }

    public java.lang.String getDataFim() {
        return dataFim;
    }

    public void setDataFim(java.lang.String dataFim) {
        this.dataFim = dataFim;
    }

    public java.lang.String getDataInicio() {
        return dataInicio;
    }

    public void setDataInicio(java.lang.String dataInicio) {
        this.dataInicio = dataInicio;
    }

    public java.lang.String getGuidPedido() {
        return guidPedido;
    }

    public void setGuidPedido(java.lang.String guidPedido) {
        this.guidPedido = guidPedido;
    }

    public java.lang.Integer getQuantidadeARetornar() {
        return quantidadeARetornar;
    }

    public void setQuantidadeARetornar(java.lang.Integer quantidadeARetornar) {
        this.quantidadeARetornar = quantidadeARetornar;
    }

    public br.org.febraban.acordosplanoseconomicos.StatusPedidoEnum getStatus() {
        return status;
    }

    public void setStatus(br.org.febraban.acordosplanoseconomicos.StatusPedidoEnum status) {
        this.status = status;
    }

}
