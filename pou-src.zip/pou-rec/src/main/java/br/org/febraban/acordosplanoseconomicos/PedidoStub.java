/**
 * PedidoStub.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf031428.03 v72314182347
 */

package br.org.febraban.acordosplanoseconomicos;

public class PedidoStub extends com.ibm.ws.webservices.engine.client.Stub implements br.org.febraban.acordosplanoseconomicos.IPedidoService {
    public PedidoStub(java.net.URL endpointURL, javax.xml.rpc.Service service) throws com.ibm.ws.webservices.engine.WebServicesFault {
        if (service == null) {
            super.service = new com.ibm.ws.webservices.engine.client.Service();
        }
        else {
            super.service = service;
        }
        super.engine = ((com.ibm.ws.webservices.engine.client.Service) super.service).getEngine();
        super.messageContexts = new com.ibm.ws.webservices.engine.MessageContext[2];
        java.lang.String theOption = (java.lang.String)super._getProperty("lastStubMapping");
        if (theOption == null || !theOption.equals("br.org.febraban.acordosplanoseconomicos.Pedido")) {
                initTypeMapping();
                super._setProperty("lastStubMapping","br.org.febraban.acordosplanoseconomicos.Pedido");
        }
        super.cachedEndpoint = endpointURL;
        super.connection = ((com.ibm.ws.webservices.engine.client.Service) super.service).getConnection(endpointURL);
    }

    private void initTypeMapping() {
        javax.xml.rpc.encoding.TypeMapping tm = super.getTypeMapping(com.ibm.ws.webservices.engine.Constants.URI_LITERAL_ENC);
        java.lang.Class javaType = null;
        javax.xml.namespace.QName xmlType = null;
        javax.xml.namespace.QName compQName = null;
        javax.xml.namespace.QName compTypeQName = null;
        com.ibm.ws.webservices.engine.encoding.SerializerFactory sf = null;
        com.ibm.ws.webservices.engine.encoding.DeserializerFactory df = null;
        javaType = br.org.febraban.acordosplanoseconomicos.PedidoFiltro.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/filtros", "PedidoFiltro");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = br.org.febraban.acordosplanoseconomicos.RespostaObterPedido.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/respostas", "RespostaObterPedido");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = br.org.febraban.acordosplanoseconomicos.ConfirmacaoPedidosRecebidos.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/requisicoes", "ConfirmacaoPedidosRecebidos");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = br.org.febraban.acordosplanoseconomicos.RespostaConfirmacaoRecebimentoPedido[].class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/respostas", "ArrayOfRespostaConfirmacaoRecebimentoPedido");
        compQName = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/respostas", "RespostaConfirmacaoRecebimentoPedido");
        compTypeQName = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/respostas", "RespostaConfirmacaoRecebimentoPedido");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.ArraySerializerFactory.class, javaType, xmlType, compQName, compTypeQName);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.ArrayDeserializerFactory.class, javaType, xmlType, compQName, compTypeQName);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = br.org.febraban.acordosplanoseconomicos.RespostaOperacao.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "RespostaOperacao");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = br.org.febraban.acordosplanoseconomicos.RetornoProcessamentoEnum.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/enums", "RetornoProcessamentoEnum");
        compTypeQName = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.w3.org/2001/XMLSchema", "string");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.EnumSerializerFactory.class, javaType, xmlType, null, compTypeQName);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.EnumDeserializerFactory.class, javaType, xmlType, null, compTypeQName);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = br.org.febraban.acordosplanoseconomicos.Documento[].class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/documentos", "ArrayOfDocumento");
        compQName = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/documentos", "Documento");
        compTypeQName = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/documentos", "Documento");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.ArraySerializerFactory.class, javaType, xmlType, compQName, compTypeQName);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.ArrayDeserializerFactory.class, javaType, xmlType, compQName, compTypeQName);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = java.lang.String.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://schemas.microsoft.com/2003/10/Serialization/", "guid");
        compTypeQName = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.w3.org/2001/XMLSchema", "string");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.SimpleSerializerFactory.class, javaType, xmlType, null, compTypeQName);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.SimpleDeserializerFactory.class, javaType, xmlType, null, compTypeQName);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = br.org.febraban.acordosplanoseconomicos.StatusPedidoEnum.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/enums", "StatusPedidoEnum");
        compTypeQName = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.w3.org/2001/XMLSchema", "string");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.EnumSerializerFactory.class, javaType, xmlType, null, compTypeQName);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.EnumDeserializerFactory.class, javaType, xmlType, null, compTypeQName);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = br.org.febraban.acordosplanoseconomicos.DestinatarioContaEnum.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/enums", "DestinatarioContaEnum");
        compTypeQName = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.w3.org/2001/XMLSchema", "string");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.EnumSerializerFactory.class, javaType, xmlType, null, compTypeQName);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.EnumDeserializerFactory.class, javaType, xmlType, null, compTypeQName);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = br.org.febraban.acordosplanoseconomicos.TipoIdentidadeEnum.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/enums", "TipoIdentidadeEnum");
        compTypeQName = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.w3.org/2001/XMLSchema", "string");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.EnumSerializerFactory.class, javaType, xmlType, null, compTypeQName);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.EnumDeserializerFactory.class, javaType, xmlType, null, compTypeQName);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = br.org.febraban.acordosplanoseconomicos.QualificacaoEnvolvidoEnum.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/enums", "QualificacaoEnvolvidoEnum");
        compTypeQName = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.w3.org/2001/XMLSchema", "string");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.EnumSerializerFactory.class, javaType, xmlType, null, compTypeQName);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.EnumDeserializerFactory.class, javaType, xmlType, null, compTypeQName);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = br.org.febraban.acordosplanoseconomicos.EsferaEnum.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/enums", "EsferaEnum");
        compTypeQName = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.w3.org/2001/XMLSchema", "string");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.EnumSerializerFactory.class, javaType, xmlType, null, compTypeQName);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.EnumDeserializerFactory.class, javaType, xmlType, null, compTypeQName);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = br.org.febraban.acordosplanoseconomicos.QualificacaoPatronoEnum.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/enums", "QualificacaoPatronoEnum");
        compTypeQName = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.w3.org/2001/XMLSchema", "string");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.EnumSerializerFactory.class, javaType, xmlType, null, compTypeQName);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.EnumDeserializerFactory.class, javaType, xmlType, null, compTypeQName);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = br.org.febraban.acordosplanoseconomicos.TipoProcessoEnum.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/enums", "TipoProcessoEnum");
        compTypeQName = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.w3.org/2001/XMLSchema", "string");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.EnumSerializerFactory.class, javaType, xmlType, null, compTypeQName);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.EnumDeserializerFactory.class, javaType, xmlType, null, compTypeQName);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = br.org.febraban.acordosplanoseconomicos.TipoAcaoEnum.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/enums", "TipoAcaoEnum");
        compTypeQName = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.w3.org/2001/XMLSchema", "string");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.EnumSerializerFactory.class, javaType, xmlType, null, compTypeQName);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.EnumDeserializerFactory.class, javaType, xmlType, null, compTypeQName);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = br.org.febraban.acordosplanoseconomicos.ResultadoAnaliseBPOEnum.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/enums", "ResultadoAnaliseBPOEnum");
        compTypeQName = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.w3.org/2001/XMLSchema", "string");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.EnumSerializerFactory.class, javaType, xmlType, null, compTypeQName);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.EnumDeserializerFactory.class, javaType, xmlType, null, compTypeQName);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = br.org.febraban.acordosplanoseconomicos.MotivoNCEnum[].class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/enums", "ArrayOfMotivoNCEnum");
        compQName = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/enums", "MotivoNCEnum");
        compTypeQName = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/enums", "MotivoNCEnum");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.ArraySerializerFactory.class, javaType, xmlType, compQName, compTypeQName);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.ArrayDeserializerFactory.class, javaType, xmlType, compQName, compTypeQName);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = br.org.febraban.acordosplanoseconomicos.MotivoNCEnum.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/enums", "MotivoNCEnum");
        compTypeQName = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.w3.org/2001/XMLSchema", "string");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.EnumSerializerFactory.class, javaType, xmlType, null, compTypeQName);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.EnumDeserializerFactory.class, javaType, xmlType, null, compTypeQName);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = br.org.febraban.acordosplanoseconomicos.Pedido[].class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/", "ArrayOfPedido");
        compQName = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/", "Pedido");
        compTypeQName = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/", "Pedido");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.ArraySerializerFactory.class, javaType, xmlType, compQName, compTypeQName);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.ArrayDeserializerFactory.class, javaType, xmlType, compQName, compTypeQName);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = br.org.febraban.acordosplanoseconomicos.RespostaConfirmacaoRecebimentoPedido.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/respostas", "RespostaConfirmacaoRecebimentoPedido");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = br.org.febraban.acordosplanoseconomicos.Pedido.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/", "Pedido");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = br.org.febraban.acordosplanoseconomicos.Parte.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/", "Parte");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = br.org.febraban.acordosplanoseconomicos.Parte[].class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/", "ArrayOfParte");
        compQName = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/", "Parte");
        compTypeQName = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/", "Parte");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.ArraySerializerFactory.class, javaType, xmlType, compQName, compTypeQName);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.ArrayDeserializerFactory.class, javaType, xmlType, compQName, compTypeQName);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = br.org.febraban.acordosplanoseconomicos.Advogado.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/", "Advogado");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = br.org.febraban.acordosplanoseconomicos.ContaPagamento.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/", "ContaPagamento");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = br.org.febraban.acordosplanoseconomicos.Processo.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/", "Processo");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = br.org.febraban.acordosplanoseconomicos.ContaPlano[].class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/", "ArrayOfContaPlano");
        compQName = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/", "ContaPlano");
        compTypeQName = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/", "ContaPlano");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.ArraySerializerFactory.class, javaType, xmlType, compQName, compTypeQName);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.ArrayDeserializerFactory.class, javaType, xmlType, compQName, compTypeQName);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = br.org.febraban.acordosplanoseconomicos.BPO.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/", "BPO");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = br.org.febraban.acordosplanoseconomicos.Identidade.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/tipos", "Identidade");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = br.org.febraban.acordosplanoseconomicos.Endereco.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/tipos", "Endereco");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = br.org.febraban.acordosplanoseconomicos.Contato.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/", "Contato");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = br.org.febraban.acordosplanoseconomicos.Telefone.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/tipos", "Telefone");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = br.org.febraban.acordosplanoseconomicos.IdentidadePatrono.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/tipos", "IdentidadePatrono");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = br.org.febraban.acordosplanoseconomicos.Conta.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/tipos", "Conta");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = br.org.febraban.acordosplanoseconomicos.DepositoJudicial.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/tipos", "DepositoJudicial");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = br.org.febraban.acordosplanoseconomicos.ContaPlano.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/", "ContaPlano");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = br.org.febraban.acordosplanoseconomicos.PlanoEnum.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/enums", "PlanoEnum");
        compTypeQName = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.w3.org/2001/XMLSchema", "string");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.EnumSerializerFactory.class, javaType, xmlType, null, compTypeQName);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.EnumDeserializerFactory.class, javaType, xmlType, null, compTypeQName);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = br.org.febraban.acordosplanoseconomicos.Habilitacao[].class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/", "ArrayOfHabilitacao");
        compQName = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/", "Habilitacao");
        compTypeQName = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/", "Habilitacao");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.ArraySerializerFactory.class, javaType, xmlType, compQName, compTypeQName);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.ArrayDeserializerFactory.class, javaType, xmlType, compQName, compTypeQName);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = br.org.febraban.acordosplanoseconomicos.Habilitacao.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/", "Habilitacao");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = br.org.febraban.acordosplanoseconomicos.ResultadoAnaliseBPO[].class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/", "ArrayOfResultadoAnaliseBPO");
        compQName = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/", "ResultadoAnaliseBPO");
        compTypeQName = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/", "ResultadoAnaliseBPO");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.ArraySerializerFactory.class, javaType, xmlType, compQName, compTypeQName);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.ArrayDeserializerFactory.class, javaType, xmlType, compQName, compTypeQName);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = br.org.febraban.acordosplanoseconomicos.ResultadoAnaliseBPO.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/", "ResultadoAnaliseBPO");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = br.org.febraban.acordosplanoseconomicos.ContextoEnum.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/enums", "ContextoEnum");
        compTypeQName = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.w3.org/2001/XMLSchema", "string");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.EnumSerializerFactory.class, javaType, xmlType, null, compTypeQName);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.EnumDeserializerFactory.class, javaType, xmlType, null, compTypeQName);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = br.org.febraban.acordosplanoseconomicos.TipoDocumentoEnum.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/enums", "TipoDocumentoEnum");
        compTypeQName = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.w3.org/2001/XMLSchema", "string");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.EnumSerializerFactory.class, javaType, xmlType, null, compTypeQName);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.EnumDeserializerFactory.class, javaType, xmlType, null, compTypeQName);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = br.org.febraban.acordosplanoseconomicos.TipoContaEnum.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/tipos/enums", "TipoContaEnum");
        compTypeQName = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.w3.org/2001/XMLSchema", "string");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.EnumSerializerFactory.class, javaType, xmlType, null, compTypeQName);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.EnumDeserializerFactory.class, javaType, xmlType, null, compTypeQName);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = br.org.febraban.acordosplanoseconomicos.Documento.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/documentos", "Documento");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = java.lang.String[].class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://schemas.microsoft.com/2003/10/Serialization/Arrays", "ArrayOfstring");
        compQName = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://schemas.microsoft.com/2003/10/Serialization/Arrays", "string");
        compTypeQName = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.w3.org/2001/XMLSchema", "string");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.ArraySerializerFactory.class, javaType, xmlType, compQName, compTypeQName);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.ArrayDeserializerFactory.class, javaType, xmlType, compQName, compTypeQName);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

    }

    private static com.ibm.ws.webservices.engine.description.OperationDesc _obterPedidoOperation0 = null;
    private static com.ibm.ws.webservices.engine.description.OperationDesc _getobterPedidoOperation0() {
        com.ibm.ws.webservices.engine.description.ParameterDesc[]  _params0 = new com.ibm.ws.webservices.engine.description.ParameterDesc[] {
         new com.ibm.ws.webservices.engine.description.ParameterDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "solicitacao"), com.ibm.ws.webservices.engine.description.ParameterDesc.IN, com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/filtros", "PedidoFiltro"), br.org.febraban.acordosplanoseconomicos.PedidoFiltro.class, false, false, false, true, true, false), 
          };
        _params0[0].setOption("partQNameString","{http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/filtros}PedidoFiltro");
        _params0[0].setOption("inputPosition","0");
        _params0[0].setOption("partName","PedidoFiltro");
        com.ibm.ws.webservices.engine.description.ParameterDesc  _returnDesc0 = new com.ibm.ws.webservices.engine.description.ParameterDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "ObterPedidoResult"), com.ibm.ws.webservices.engine.description.ParameterDesc.OUT, com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/respostas", "RespostaObterPedido"), br.org.febraban.acordosplanoseconomicos.RespostaObterPedido.class, true, false, false, true, true, false); 
        _returnDesc0.setOption("partQNameString","{http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/respostas}RespostaObterPedido");
        _returnDesc0.setOption("outputPosition","0");
        _returnDesc0.setOption("partName","RespostaObterPedido");
        com.ibm.ws.webservices.engine.description.FaultDesc[]  _faults0 = new com.ibm.ws.webservices.engine.description.FaultDesc[] {
          };
        _obterPedidoOperation0 = new com.ibm.ws.webservices.engine.description.OperationDesc("obterPedido", com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "ObterPedido"), _params0, _returnDesc0, _faults0, "http://acordosplanoseconomicos.febraban.org.br/IPedidoService/ObterPedido");
        _obterPedidoOperation0.setOption("buildNum","cf031428.03");
        _obterPedidoOperation0.setOption("ResponseNamespace","http://acordosplanoseconomicos.febraban.org.br");
        _obterPedidoOperation0.setOption("targetNamespace","http://acordosplanoseconomicos.febraban.org.br");
        _obterPedidoOperation0.setOption("outputMessageQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "IPedidoService_ObterPedido_OutputMessage"));
        _obterPedidoOperation0.setOption("inputWSAAction","http://acordosplanoseconomicos.febraban.org.br/IPedidoService/ObterPedido");
        _obterPedidoOperation0.setOption("portTypeQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "IPedidoService"));
        _obterPedidoOperation0.setOption("outputWSAAction","http://acordosplanoseconomicos.febraban.org.br/IPedidoService/ObterPedidoResponse");
        _obterPedidoOperation0.setOption("ServiceQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "AcordoPlanoEconomicosService"));
        _obterPedidoOperation0.setOption("ResponseLocalPart","ObterPedidoResponse");
        _obterPedidoOperation0.setOption("inputMessageQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "IPedidoService_ObterPedido_InputMessage"));
        _obterPedidoOperation0.setUse(com.ibm.ws.webservices.engine.enumtype.Use.LITERAL);
        _obterPedidoOperation0.setStyle(com.ibm.ws.webservices.engine.enumtype.Style.WRAPPED);
        return _obterPedidoOperation0;

    }

    private int _obterPedidoIndex0 = 0;
    private synchronized com.ibm.ws.webservices.engine.client.Stub.Invoke _getobterPedidoInvoke0(Object[] parameters) throws com.ibm.ws.webservices.engine.WebServicesFault  {
        com.ibm.ws.webservices.engine.MessageContext mc = super.messageContexts[_obterPedidoIndex0];
        if (mc == null) {
            mc = new com.ibm.ws.webservices.engine.MessageContext(super.engine);
            mc.setOperation(PedidoStub._obterPedidoOperation0);
            mc.setUseSOAPAction(true);
            mc.setSOAPActionURI("http://acordosplanoseconomicos.febraban.org.br/IPedidoService/ObterPedido");
            mc.setEncodingStyle(com.ibm.ws.webservices.engine.Constants.URI_LITERAL_ENC);
            mc.setProperty(com.ibm.wsspi.webservices.Constants.SEND_TYPE_ATTR_PROPERTY, Boolean.FALSE);
            mc.setProperty(com.ibm.wsspi.webservices.Constants.ENGINE_DO_MULTI_REFS_PROPERTY, Boolean.FALSE);
            super.primeMessageContext(mc);
            super.messageContexts[_obterPedidoIndex0] = mc;
        }
        try {
            mc = (com.ibm.ws.webservices.engine.MessageContext) mc.clone();
        }
        catch (CloneNotSupportedException cnse) {
            throw com.ibm.ws.webservices.engine.WebServicesFault.makeFault(cnse);
        }
        return new com.ibm.ws.webservices.engine.client.Stub.Invoke(connection, mc, parameters);
    }

    public br.org.febraban.acordosplanoseconomicos.RespostaObterPedido obterPedido(br.org.febraban.acordosplanoseconomicos.PedidoFiltro solicitacao) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new com.ibm.ws.webservices.engine.NoEndPointException();
        }
        java.util.Vector _resp = null;
        try {
            _resp = _getobterPedidoInvoke0(new java.lang.Object[] {solicitacao}).invoke();

        } catch (com.ibm.ws.webservices.engine.WebServicesFault wsf) {
            Exception e = wsf.getUserException();
            throw wsf;
        } 
        try {
            return (br.org.febraban.acordosplanoseconomicos.RespostaObterPedido) ((com.ibm.ws.webservices.engine.xmlsoap.ext.ParamValue) _resp.get(0)).getValue();
        } catch (java.lang.Exception _exception) {
            return (br.org.febraban.acordosplanoseconomicos.RespostaObterPedido) super.convert(((com.ibm.ws.webservices.engine.xmlsoap.ext.ParamValue) _resp.get(0)).getValue(), br.org.febraban.acordosplanoseconomicos.RespostaObterPedido.class);
        }
    }

    private static com.ibm.ws.webservices.engine.description.OperationDesc _confirmarRecebimentoPedidoOperation1 = null;
    private static com.ibm.ws.webservices.engine.description.OperationDesc _getconfirmarRecebimentoPedidoOperation1() {
        com.ibm.ws.webservices.engine.description.ParameterDesc[]  _params1 = new com.ibm.ws.webservices.engine.description.ParameterDesc[] {
         new com.ibm.ws.webservices.engine.description.ParameterDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "pedidosRecebidos"), com.ibm.ws.webservices.engine.description.ParameterDesc.IN, com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/requisicoes", "ConfirmacaoPedidosRecebidos"), br.org.febraban.acordosplanoseconomicos.ConfirmacaoPedidosRecebidos.class, false, false, false, true, true, false), 
          };
        _params1[0].setOption("partQNameString","{http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/requisicoes}ConfirmacaoPedidosRecebidos");
        _params1[0].setOption("inputPosition","0");
        _params1[0].setOption("partName","ConfirmacaoPedidosRecebidos");
        com.ibm.ws.webservices.engine.description.ParameterDesc  _returnDesc1 = new com.ibm.ws.webservices.engine.description.ParameterDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "ConfirmarRecebimentoPedidoResult"), com.ibm.ws.webservices.engine.description.ParameterDesc.OUT, com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/respostas", "ArrayOfRespostaConfirmacaoRecebimentoPedido"), br.org.febraban.acordosplanoseconomicos.RespostaConfirmacaoRecebimentoPedido[].class, true, false, false, true, true, false); 
        _returnDesc1.setOption("partQNameString","{http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/respostas}ArrayOfRespostaConfirmacaoRecebimentoPedido");
        _returnDesc1.setOption("outputPosition","0");
        _returnDesc1.setOption("partName","ArrayOfRespostaConfirmacaoRecebimentoPedido");
        com.ibm.ws.webservices.engine.description.FaultDesc[]  _faults1 = new com.ibm.ws.webservices.engine.description.FaultDesc[] {
          };
        _confirmarRecebimentoPedidoOperation1 = new com.ibm.ws.webservices.engine.description.OperationDesc("confirmarRecebimentoPedido", com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "ConfirmarRecebimentoPedido"), _params1, _returnDesc1, _faults1, "http://acordosplanoseconomicos.febraban.org.br/IPedidoService/ConfirmarRecebimentoPedido");
        _confirmarRecebimentoPedidoOperation1.setOption("buildNum","cf031428.03");
        _confirmarRecebimentoPedidoOperation1.setOption("ResponseNamespace","http://acordosplanoseconomicos.febraban.org.br");
        _confirmarRecebimentoPedidoOperation1.setOption("targetNamespace","http://acordosplanoseconomicos.febraban.org.br");
        _confirmarRecebimentoPedidoOperation1.setOption("outputMessageQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "IPedidoService_ConfirmarRecebimentoPedido_OutputMessage"));
        _confirmarRecebimentoPedidoOperation1.setOption("inputWSAAction","http://acordosplanoseconomicos.febraban.org.br/IPedidoService/ConfirmarRecebimentoPedido");
        _confirmarRecebimentoPedidoOperation1.setOption("portTypeQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "IPedidoService"));
        _confirmarRecebimentoPedidoOperation1.setOption("outputWSAAction","http://acordosplanoseconomicos.febraban.org.br/IPedidoService/ConfirmarRecebimentoPedidoResponse");
        _confirmarRecebimentoPedidoOperation1.setOption("ServiceQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "AcordoPlanoEconomicosService"));
        _confirmarRecebimentoPedidoOperation1.setOption("ResponseLocalPart","ConfirmarRecebimentoPedidoResponse");
        _confirmarRecebimentoPedidoOperation1.setOption("inputMessageQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br", "IPedidoService_ConfirmarRecebimentoPedido_InputMessage"));
        _confirmarRecebimentoPedidoOperation1.setUse(com.ibm.ws.webservices.engine.enumtype.Use.LITERAL);
        _confirmarRecebimentoPedidoOperation1.setStyle(com.ibm.ws.webservices.engine.enumtype.Style.WRAPPED);
        return _confirmarRecebimentoPedidoOperation1;

    }

    private int _confirmarRecebimentoPedidoIndex1 = 1;
    private synchronized com.ibm.ws.webservices.engine.client.Stub.Invoke _getconfirmarRecebimentoPedidoInvoke1(Object[] parameters) throws com.ibm.ws.webservices.engine.WebServicesFault  {
        com.ibm.ws.webservices.engine.MessageContext mc = super.messageContexts[_confirmarRecebimentoPedidoIndex1];
        if (mc == null) {
            mc = new com.ibm.ws.webservices.engine.MessageContext(super.engine);
            mc.setOperation(PedidoStub._confirmarRecebimentoPedidoOperation1);
            mc.setUseSOAPAction(true);
            mc.setSOAPActionURI("http://acordosplanoseconomicos.febraban.org.br/IPedidoService/ConfirmarRecebimentoPedido");
            mc.setEncodingStyle(com.ibm.ws.webservices.engine.Constants.URI_LITERAL_ENC);
            mc.setProperty(com.ibm.wsspi.webservices.Constants.SEND_TYPE_ATTR_PROPERTY, Boolean.FALSE);
            mc.setProperty(com.ibm.wsspi.webservices.Constants.ENGINE_DO_MULTI_REFS_PROPERTY, Boolean.FALSE);
            super.primeMessageContext(mc);
            super.messageContexts[_confirmarRecebimentoPedidoIndex1] = mc;
        }
        try {
            mc = (com.ibm.ws.webservices.engine.MessageContext) mc.clone();
        }
        catch (CloneNotSupportedException cnse) {
            throw com.ibm.ws.webservices.engine.WebServicesFault.makeFault(cnse);
        }
        return new com.ibm.ws.webservices.engine.client.Stub.Invoke(connection, mc, parameters);
    }

    public br.org.febraban.acordosplanoseconomicos.RespostaConfirmacaoRecebimentoPedido[] confirmarRecebimentoPedido(br.org.febraban.acordosplanoseconomicos.ConfirmacaoPedidosRecebidos pedidosRecebidos) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new com.ibm.ws.webservices.engine.NoEndPointException();
        }
        java.util.Vector _resp = null;
        try {
            _resp = _getconfirmarRecebimentoPedidoInvoke1(new java.lang.Object[] {pedidosRecebidos}).invoke();

        } catch (com.ibm.ws.webservices.engine.WebServicesFault wsf) {
            Exception e = wsf.getUserException();
            throw wsf;
        } 
        try {
            return (br.org.febraban.acordosplanoseconomicos.RespostaConfirmacaoRecebimentoPedido[]) ((com.ibm.ws.webservices.engine.xmlsoap.ext.ParamValue) _resp.get(0)).getValue();
        } catch (java.lang.Exception _exception) {
            return (br.org.febraban.acordosplanoseconomicos.RespostaConfirmacaoRecebimentoPedido[]) super.convert(((com.ibm.ws.webservices.engine.xmlsoap.ext.ParamValue) _resp.get(0)).getValue(), br.org.febraban.acordosplanoseconomicos.RespostaConfirmacaoRecebimentoPedido[].class);
        }
    }

    private static void _staticInit() {
        _confirmarRecebimentoPedidoOperation1 = _getconfirmarRecebimentoPedidoOperation1();
        _obterPedidoOperation0 = _getobterPedidoOperation0();
    }

    static {
       _staticInit();
    }
}
