/**
 * Pedido_Deser.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf031428.03 v72314182347
 */

package br.org.febraban.acordosplanoseconomicos;

public class Pedido_Deser extends com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializer {
    /**
     * Constructor
     */
    public Pedido_Deser(
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType, 
           com.ibm.ws.webservices.engine.description.TypeDesc _typeDesc) {
        super(_javaType, _xmlType, _typeDesc);
    }
    /**
     * Create instance of java bean
     */
    public void createValue() {
        value = new Pedido();
    }
    protected boolean tryElementSetFromString(javax.xml.namespace.QName qName, java.lang.String strValue) {
        if (qName==QName_4_2) {
          ((Pedido)value).setGuidPedido(strValue);
          return true;}
        else if (qName==QName_4_42) {
          ((Pedido)value).setProtocolo(strValue);
          return true;}
        else if (qName==QName_4_43) {
          ((Pedido)value).setIdentificadorLoteHabilitacao(com.ibm.ws.webservices.engine.encoding.ser.SimpleDeserializer.parseint(strValue));
          return true;}
        else if (qName==QName_4_44) {
          ((Pedido)value).setDataAbertura(strValue);
          return true;}
        else if (qName==QName_4_46) {
          ((Pedido)value).setValorCustasProcessuais(com.ibm.ws.webservices.engine.encoding.ser.SimpleDeserializer.parseDouble(strValue));
          return true;}
        else if (qName==QName_4_47) {
          ((Pedido)value).setDataConfimacaoLeituraBanco(strValue);
          return true;}
        else if (qName==QName_4_48) {
          ((Pedido)value).setValorTotalSimulado(com.ibm.ws.webservices.engine.encoding.ser.SimpleDeserializer.parsedouble(strValue));
          return true;}
        return false;
    }
    protected boolean tryAttributeSetFromString(javax.xml.namespace.QName qName, java.lang.String strValue) {
        return false;
    }
    protected boolean tryElementSetFromObject(javax.xml.namespace.QName qName, java.lang.Object objValue) {
        if (qName==QName_4_45) {
          ((Pedido)value).setStatusPedido((br.org.febraban.acordosplanoseconomicos.StatusPedidoEnum)objValue);
          return true;}
        else if (qName==QName_4_49) {
          ((Pedido)value).setDestinatarioPagamentoAcordo((br.org.febraban.acordosplanoseconomicos.DestinatarioContaEnum)objValue);
          return true;}
        else if (qName==QName_4_50) {
          ((Pedido)value).setPoupador((br.org.febraban.acordosplanoseconomicos.Parte)objValue);
          return true;}
        else if (qName==QName_4_51) {
          if (objValue instanceof java.util.List) {
            br.org.febraban.acordosplanoseconomicos.Parte[] array = new br.org.febraban.acordosplanoseconomicos.Parte[((java.util.List)objValue).size()];
            ((java.util.List)objValue).toArray(array);
            ((Pedido)value).setEnvolvidosEspolio(array);
          } else { 
            ((Pedido)value).setEnvolvidosEspolio((br.org.febraban.acordosplanoseconomicos.Parte[])objValue);}
          return true;}
        else if (qName==QName_4_52) {
          ((Pedido)value).setPatrono((br.org.febraban.acordosplanoseconomicos.Advogado)objValue);
          return true;}
        else if (qName==QName_4_32) {
          ((Pedido)value).setContaPagamentoAcordo((br.org.febraban.acordosplanoseconomicos.ContaPagamento)objValue);
          return true;}
        else if (qName==QName_4_53) {
          ((Pedido)value).setContaPagamentoHonorario((br.org.febraban.acordosplanoseconomicos.ContaPagamento)objValue);
          return true;}
        else if (qName==QName_4_54) {
          ((Pedido)value).setProcesso((br.org.febraban.acordosplanoseconomicos.Processo)objValue);
          return true;}
        else if (qName==QName_4_55) {
          if (objValue instanceof java.util.List) {
            br.org.febraban.acordosplanoseconomicos.ContaPlano[] array = new br.org.febraban.acordosplanoseconomicos.ContaPlano[((java.util.List)objValue).size()];
            ((java.util.List)objValue).toArray(array);
            ((Pedido)value).setContasContempladas(array);
          } else { 
            ((Pedido)value).setContasContempladas((br.org.febraban.acordosplanoseconomicos.ContaPlano[])objValue);}
          return true;}
        else if (qName==QName_4_56) {
          if (objValue instanceof java.util.List) {
            br.org.febraban.acordosplanoseconomicos.Documento[] array = new br.org.febraban.acordosplanoseconomicos.Documento[((java.util.List)objValue).size()];
            ((java.util.List)objValue).toArray(array);
            ((Pedido)value).setDocumentos(array);
          } else { 
            ((Pedido)value).setDocumentos((br.org.febraban.acordosplanoseconomicos.Documento[])objValue);}
          return true;}
        else if (qName==QName_4_57) {
          ((Pedido)value).setResultadoBPO((br.org.febraban.acordosplanoseconomicos.BPO)objValue);
          return true;}
        return false;
    }
    protected boolean tryElementSetFromList(javax.xml.namespace.QName qName, java.util.List listValue) {
        return false;
    }
    private final static javax.xml.namespace.QName QName_4_56 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "Documentos");
    private final static javax.xml.namespace.QName QName_4_50 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "Poupador");
    private final static javax.xml.namespace.QName QName_4_48 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "ValorTotalSimulado");
    private final static javax.xml.namespace.QName QName_4_44 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "DataAbertura");
    private final static javax.xml.namespace.QName QName_4_52 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "Patrono");
    private final static javax.xml.namespace.QName QName_4_47 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "DataConfimacaoLeituraBanco");
    private final static javax.xml.namespace.QName QName_4_54 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "Processo");
    private final static javax.xml.namespace.QName QName_4_32 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "ContaPagamentoAcordo");
    private final static javax.xml.namespace.QName QName_4_2 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "GuidPedido");
    private final static javax.xml.namespace.QName QName_4_53 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "ContaPagamentoHonorario");
    private final static javax.xml.namespace.QName QName_4_49 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "DestinatarioPagamentoAcordo");
    private final static javax.xml.namespace.QName QName_4_43 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "identificadorLoteHabilitacao");
    private final static javax.xml.namespace.QName QName_4_51 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "EnvolvidosEspolio");
    private final static javax.xml.namespace.QName QName_4_45 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "StatusPedido");
    private final static javax.xml.namespace.QName QName_4_57 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "ResultadoBPO");
    private final static javax.xml.namespace.QName QName_4_46 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "ValorCustasProcessuais");
    private final static javax.xml.namespace.QName QName_4_42 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "Protocolo");
    private final static javax.xml.namespace.QName QName_4_55 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "ContasContempladas");
}
