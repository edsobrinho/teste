/**
 * Pedido_Ser.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf031428.03 v72314182347
 */

package br.org.febraban.acordosplanoseconomicos;

public class Pedido_Ser extends com.ibm.ws.webservices.engine.encoding.ser.BeanSerializer {
    /**
     * Constructor
     */
    public Pedido_Ser(
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType, 
           com.ibm.ws.webservices.engine.description.TypeDesc _typeDesc) {
        super(_javaType, _xmlType, _typeDesc);
    }
    public void serialize(
        javax.xml.namespace.QName name,
        org.xml.sax.Attributes attributes,
        java.lang.Object value,
        com.ibm.ws.webservices.engine.encoding.SerializationContext context)
        throws java.io.IOException
    {
        context.startElement(name, addAttributes(attributes, value, context));
        addElements(value, context);
        context.endElement();
    }
    protected org.xml.sax.Attributes addAttributes(
        org.xml.sax.Attributes attributes,
        java.lang.Object value,
        com.ibm.ws.webservices.engine.encoding.SerializationContext context)
        throws java.io.IOException
    {
           javax.xml.namespace.QName
           elemQName = QName_4_2;
           context.qName2String(elemQName, true);
           elemQName = QName_4_42;
           context.qName2String(elemQName, true);
           elemQName = QName_4_43;
           context.qName2String(elemQName, true);
           elemQName = QName_4_44;
           context.qName2String(elemQName, true);
           elemQName = QName_4_45;
           context.qName2String(elemQName, true);
           elemQName = QName_4_46;
           context.qName2String(elemQName, true);
           elemQName = QName_4_47;
           context.qName2String(elemQName, true);
           elemQName = QName_4_48;
           context.qName2String(elemQName, true);
           elemQName = QName_4_49;
           context.qName2String(elemQName, true);
           elemQName = QName_4_50;
           context.qName2String(elemQName, true);
           elemQName = QName_4_51;
           context.qName2String(elemQName, true);
           elemQName = QName_4_52;
           context.qName2String(elemQName, true);
           elemQName = QName_4_32;
           context.qName2String(elemQName, true);
           elemQName = QName_4_53;
           context.qName2String(elemQName, true);
           elemQName = QName_4_54;
           context.qName2String(elemQName, true);
           elemQName = QName_4_55;
           context.qName2String(elemQName, true);
           elemQName = QName_4_56;
           context.qName2String(elemQName, true);
           elemQName = QName_4_57;
           context.qName2String(elemQName, true);
        return attributes;
    }
    protected void addElements(
        java.lang.Object value,
        com.ibm.ws.webservices.engine.encoding.SerializationContext context)
        throws java.io.IOException
    {
        Pedido bean = (Pedido) value;
        java.lang.Object propValue;
        javax.xml.namespace.QName propQName;
        {
          propQName = QName_4_2;
          propValue = bean.getGuidPedido();
          if (propValue != null && !context.shouldSendXSIType()) {
            context.simpleElement(propQName, null, propValue.toString()); 
          } else {
            serializeChild(propQName, null, 
              propValue, 
              QName_14_58,
              true,null,context);
          }
          propQName = QName_4_42;
          propValue = bean.getProtocolo();
          if (propValue != null && !context.shouldSendXSIType()) {
            context.simpleElement(propQName, null, propValue.toString()); 
          } else {
            serializeChild(propQName, null, 
              propValue, 
              QName_1_5,
              true,null,context);
          }
          propQName = QName_4_43;
          propValue = new java.lang.Integer(bean.getIdentificadorLoteHabilitacao());
          serializeChild(propQName, null, 
              propValue, 
              QName_1_6,
              true,null,context);
          propQName = QName_4_44;
          propValue = bean.getDataAbertura();
          if (propValue != null && !context.shouldSendXSIType()) {
            context.simpleElement(propQName, null, propValue.toString()); 
          } else {
            serializeChild(propQName, null, 
              propValue, 
              QName_1_5,
              true,null,context);
          }
          propQName = QName_4_45;
          propValue = bean.getStatusPedido();
          serializeChild(propQName, null, 
              propValue, 
              QName_2_7,
              true,null,context);
          propQName = QName_4_46;
          propValue = bean.getValorCustasProcessuais();
          serializeChild(propQName, null, 
              propValue, 
              QName_1_33,
              false,null,context);
          propQName = QName_4_47;
          propValue = bean.getDataConfimacaoLeituraBanco();
          if (propValue != null && !context.shouldSendXSIType()) {
            context.simpleElement(propQName, null, propValue.toString()); 
          } else {
            serializeChild(propQName, null, 
              propValue, 
              QName_1_5,
              false,null,context);
          }
          propQName = QName_4_48;
          propValue = new java.lang.Double(bean.getValorTotalSimulado());
          serializeChild(propQName, null, 
              propValue, 
              QName_1_33,
              true,null,context);
          propQName = QName_4_49;
          propValue = bean.getDestinatarioPagamentoAcordo();
          serializeChild(propQName, null, 
              propValue, 
              QName_2_59,
              true,null,context);
          propQName = QName_4_50;
          propValue = bean.getPoupador();
          serializeChild(propQName, null, 
              propValue, 
              QName_4_60,
              true,null,context);
          propQName = QName_4_51;
          propValue = bean.getEnvolvidosEspolio();
          serializeChild(propQName, null, 
              propValue, 
              QName_4_61,
              false,null,context);
          propQName = QName_4_52;
          propValue = bean.getPatrono();
          serializeChild(propQName, null, 
              propValue, 
              QName_4_62,
              false,null,context);
          propQName = QName_4_32;
          propValue = bean.getContaPagamentoAcordo();
          serializeChild(propQName, null, 
              propValue, 
              QName_4_36,
              false,null,context);
          propQName = QName_4_53;
          propValue = bean.getContaPagamentoHonorario();
          serializeChild(propQName, null, 
              propValue, 
              QName_4_36,
              false,null,context);
          propQName = QName_4_54;
          propValue = bean.getProcesso();
          serializeChild(propQName, null, 
              propValue, 
              QName_4_54,
              false,null,context);
          propQName = QName_4_55;
          propValue = bean.getContasContempladas();
          serializeChild(propQName, null, 
              propValue, 
              QName_4_63,
              true,null,context);
          propQName = QName_4_56;
          propValue = bean.getDocumentos();
          serializeChild(propQName, null, 
              propValue, 
              QName_12_64,
              true,null,context);
          propQName = QName_4_57;
          propValue = bean.getResultadoBPO();
          serializeChild(propQName, null, 
              propValue, 
              QName_4_65,
              false,null,context);
        }
    }
    private final static javax.xml.namespace.QName QName_4_60 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "Parte");
    private final static javax.xml.namespace.QName QName_4_56 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "Documentos");
    private final static javax.xml.namespace.QName QName_4_63 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "ArrayOfContaPlano");
    private final static javax.xml.namespace.QName QName_4_50 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "Poupador");
    private final static javax.xml.namespace.QName QName_4_48 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "ValorTotalSimulado");
    private final static javax.xml.namespace.QName QName_4_36 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "ContaPagamento");
    private final static javax.xml.namespace.QName QName_4_44 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "DataAbertura");
    private final static javax.xml.namespace.QName QName_4_52 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "Patrono");
    private final static javax.xml.namespace.QName QName_1_5 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://www.w3.org/2001/XMLSchema",
                  "string");
    private final static javax.xml.namespace.QName QName_4_47 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "DataConfimacaoLeituraBanco");
    private final static javax.xml.namespace.QName QName_4_62 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "Advogado");
    private final static javax.xml.namespace.QName QName_1_6 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://www.w3.org/2001/XMLSchema",
                  "int");
    private final static javax.xml.namespace.QName QName_4_54 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "Processo");
    private final static javax.xml.namespace.QName QName_4_32 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "ContaPagamentoAcordo");
    private final static javax.xml.namespace.QName QName_4_2 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "GuidPedido");
    private final static javax.xml.namespace.QName QName_4_53 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "ContaPagamentoHonorario");
    private final static javax.xml.namespace.QName QName_4_65 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "BPO");
    private final static javax.xml.namespace.QName QName_2_59 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/enums",
                  "DestinatarioContaEnum");
    private final static javax.xml.namespace.QName QName_14_58 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://schemas.microsoft.com/2003/10/Serialization/",
                  "guid");
    private final static javax.xml.namespace.QName QName_4_49 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "DestinatarioPagamentoAcordo");
    private final static javax.xml.namespace.QName QName_2_7 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/enums",
                  "StatusPedidoEnum");
    private final static javax.xml.namespace.QName QName_4_43 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "identificadorLoteHabilitacao");
    private final static javax.xml.namespace.QName QName_4_51 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "EnvolvidosEspolio");
    private final static javax.xml.namespace.QName QName_4_45 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "StatusPedido");
    private final static javax.xml.namespace.QName QName_4_61 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "ArrayOfParte");
    private final static javax.xml.namespace.QName QName_4_57 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "ResultadoBPO");
    private final static javax.xml.namespace.QName QName_1_33 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://www.w3.org/2001/XMLSchema",
                  "double");
    private final static javax.xml.namespace.QName QName_4_46 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "ValorCustasProcessuais");
    private final static javax.xml.namespace.QName QName_12_64 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/documentos",
                  "ArrayOfDocumento");
    private final static javax.xml.namespace.QName QName_4_42 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "Protocolo");
    private final static javax.xml.namespace.QName QName_4_55 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "ContasContempladas");
}
