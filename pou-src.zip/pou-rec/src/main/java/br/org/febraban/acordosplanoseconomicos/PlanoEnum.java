/**
 * PlanoEnum.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf031428.03 v72314182347
 */

package br.org.febraban.acordosplanoseconomicos;

public class PlanoEnum  {
    private java.lang.String _value_;
    private static java.util.HashMap _table_ = new java.util.HashMap();

    // Constructor
    protected PlanoEnum(java.lang.String value) {
        _value_ = value;
        _table_.put(_value_,this);
    };

    public static final java.lang.String _BRESSER = "BRESSER";
    public static final java.lang.String _COLLOR_I = "COLLOR_I";
    public static final java.lang.String _COLLOR_II = "COLLOR_II";
    public static final java.lang.String _VERAO = "VERAO";
    public static final PlanoEnum BRESSER = new PlanoEnum(_BRESSER);
    public static final PlanoEnum COLLOR_I = new PlanoEnum(_COLLOR_I);
    public static final PlanoEnum COLLOR_II = new PlanoEnum(_COLLOR_II);
    public static final PlanoEnum VERAO = new PlanoEnum(_VERAO);
    public java.lang.String getValue() { return _value_;}
    public static PlanoEnum fromValue(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        PlanoEnum enumeration = (PlanoEnum)
            _table_.get(value);
        if (enumeration==null) throw new java.lang.IllegalArgumentException();
        return enumeration;
    }
    public static PlanoEnum fromString(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        return fromValue(value);
    }
    public boolean equals(java.lang.Object obj) {return (obj == this);}
    public int hashCode() { return toString().hashCode();}
    public java.lang.String toString() { return _value_;}

}
