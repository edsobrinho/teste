/**
 * Processo.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf031428.03 v72314182347
 */

package br.org.febraban.acordosplanoseconomicos;

public class Processo  {
    private int id;
    private java.lang.String numeroProcessoCNJ;
    private java.lang.String numeroProcessoAntigo;
    private java.lang.String identificadorProcessoSistemaLegado;
    private br.org.febraban.acordosplanoseconomicos.TipoProcessoEnum orgaoLegal;
    private br.org.febraban.acordosplanoseconomicos.TipoAcaoEnum tipoAcao;
    private java.lang.String varaDeOrigem;
    private java.lang.String comarcaDeOrigem;
    private java.lang.String UF;
    private java.lang.String ajuizadoEm;
    private java.lang.String dataProcuracao;
    private java.lang.String instituicaoNome;

    public Processo() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public java.lang.String getNumeroProcessoCNJ() {
        return numeroProcessoCNJ;
    }

    public void setNumeroProcessoCNJ(java.lang.String numeroProcessoCNJ) {
        this.numeroProcessoCNJ = numeroProcessoCNJ;
    }

    public java.lang.String getNumeroProcessoAntigo() {
        return numeroProcessoAntigo;
    }

    public void setNumeroProcessoAntigo(java.lang.String numeroProcessoAntigo) {
        this.numeroProcessoAntigo = numeroProcessoAntigo;
    }

    public java.lang.String getIdentificadorProcessoSistemaLegado() {
        return identificadorProcessoSistemaLegado;
    }

    public void setIdentificadorProcessoSistemaLegado(java.lang.String identificadorProcessoSistemaLegado) {
        this.identificadorProcessoSistemaLegado = identificadorProcessoSistemaLegado;
    }

    public br.org.febraban.acordosplanoseconomicos.TipoProcessoEnum getOrgaoLegal() {
        return orgaoLegal;
    }

    public void setOrgaoLegal(br.org.febraban.acordosplanoseconomicos.TipoProcessoEnum orgaoLegal) {
        this.orgaoLegal = orgaoLegal;
    }

    public br.org.febraban.acordosplanoseconomicos.TipoAcaoEnum getTipoAcao() {
        return tipoAcao;
    }

    public void setTipoAcao(br.org.febraban.acordosplanoseconomicos.TipoAcaoEnum tipoAcao) {
        this.tipoAcao = tipoAcao;
    }

    public java.lang.String getVaraDeOrigem() {
        return varaDeOrigem;
    }

    public void setVaraDeOrigem(java.lang.String varaDeOrigem) {
        this.varaDeOrigem = varaDeOrigem;
    }

    public java.lang.String getComarcaDeOrigem() {
        return comarcaDeOrigem;
    }

    public void setComarcaDeOrigem(java.lang.String comarcaDeOrigem) {
        this.comarcaDeOrigem = comarcaDeOrigem;
    }

    public java.lang.String getUF() {
        return UF;
    }

    public void setUF(java.lang.String UF) {
        this.UF = UF;
    }

    public java.lang.String getAjuizadoEm() {
        return ajuizadoEm;
    }

    public void setAjuizadoEm(java.lang.String ajuizadoEm) {
        this.ajuizadoEm = ajuizadoEm;
    }

    public java.lang.String getDataProcuracao() {
        return dataProcuracao;
    }

    public void setDataProcuracao(java.lang.String dataProcuracao) {
        this.dataProcuracao = dataProcuracao;
    }

    public java.lang.String getInstituicaoNome() {
        return instituicaoNome;
    }

    public void setInstituicaoNome(java.lang.String instituicaoNome) {
        this.instituicaoNome = instituicaoNome;
    }

}
