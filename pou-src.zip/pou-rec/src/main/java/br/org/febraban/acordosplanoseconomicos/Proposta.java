/**
 * Proposta.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf031428.03 v72314182347
 */

package br.org.febraban.acordosplanoseconomicos;

public class Proposta  {
    private java.lang.String identificadorPropostaBanco;
    private double valorTotalAcordo;
    private double valorPoupador;
    private double valorHonorariosAdvogado;
    private double valorHonorariosFebrapo;
    private double valorReembolsoCustas;
    private int quantidadeParcelas;
    private double valorParcela;
    private java.lang.String dataPrimeiraParcela;
    private java.lang.String observacoes;
    private br.org.febraban.acordosplanoseconomicos.Arquivo demonstrativoCalculo;

    public Proposta() {
    }

    public java.lang.String getIdentificadorPropostaBanco() {
        return identificadorPropostaBanco;
    }

    public void setIdentificadorPropostaBanco(java.lang.String identificadorPropostaBanco) {
        this.identificadorPropostaBanco = identificadorPropostaBanco;
    }

    public double getValorTotalAcordo() {
        return valorTotalAcordo;
    }

    public void setValorTotalAcordo(double valorTotalAcordo) {
        this.valorTotalAcordo = valorTotalAcordo;
    }

    public double getValorPoupador() {
        return valorPoupador;
    }

    public void setValorPoupador(double valorPoupador) {
        this.valorPoupador = valorPoupador;
    }

    public double getValorHonorariosAdvogado() {
        return valorHonorariosAdvogado;
    }

    public void setValorHonorariosAdvogado(double valorHonorariosAdvogado) {
        this.valorHonorariosAdvogado = valorHonorariosAdvogado;
    }

    public double getValorHonorariosFebrapo() {
        return valorHonorariosFebrapo;
    }

    public void setValorHonorariosFebrapo(double valorHonorariosFebrapo) {
        this.valorHonorariosFebrapo = valorHonorariosFebrapo;
    }

    public double getValorReembolsoCustas() {
        return valorReembolsoCustas;
    }

    public void setValorReembolsoCustas(double valorReembolsoCustas) {
        this.valorReembolsoCustas = valorReembolsoCustas;
    }

    public int getQuantidadeParcelas() {
        return quantidadeParcelas;
    }

    public void setQuantidadeParcelas(int quantidadeParcelas) {
        this.quantidadeParcelas = quantidadeParcelas;
    }

    public double getValorParcela() {
        return valorParcela;
    }

    public void setValorParcela(double valorParcela) {
        this.valorParcela = valorParcela;
    }

    public java.lang.String getDataPrimeiraParcela() {
        return dataPrimeiraParcela;
    }

    public void setDataPrimeiraParcela(java.lang.String dataPrimeiraParcela) {
        this.dataPrimeiraParcela = dataPrimeiraParcela;
    }

    public java.lang.String getObservacoes() {
        return observacoes;
    }

    public void setObservacoes(java.lang.String observacoes) {
        this.observacoes = observacoes;
    }

    public br.org.febraban.acordosplanoseconomicos.Arquivo getDemonstrativoCalculo() {
        return demonstrativoCalculo;
    }

    public void setDemonstrativoCalculo(br.org.febraban.acordosplanoseconomicos.Arquivo demonstrativoCalculo) {
        this.demonstrativoCalculo = demonstrativoCalculo;
    }

}
