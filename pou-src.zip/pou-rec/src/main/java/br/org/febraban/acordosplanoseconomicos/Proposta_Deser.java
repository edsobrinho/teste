/**
 * Proposta_Deser.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf031428.03 v72314182347
 */

package br.org.febraban.acordosplanoseconomicos;

public class Proposta_Deser extends com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializer {
    /**
     * Constructor
     */
    public Proposta_Deser(
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType, 
           com.ibm.ws.webservices.engine.description.TypeDesc _typeDesc) {
        super(_javaType, _xmlType, _typeDesc);
    }
    /**
     * Create instance of java bean
     */
    public void createValue() {
        value = new Proposta();
    }
    protected boolean tryElementSetFromString(javax.xml.namespace.QName qName, java.lang.String strValue) {
        if (qName==QName_9_159) {
          ((Proposta)value).setIdentificadorPropostaBanco(strValue);
          return true;}
        else if (qName==QName_9_160) {
          ((Proposta)value).setValorTotalAcordo(com.ibm.ws.webservices.engine.encoding.ser.SimpleDeserializer.parsedouble(strValue));
          return true;}
        else if (qName==QName_9_161) {
          ((Proposta)value).setValorPoupador(com.ibm.ws.webservices.engine.encoding.ser.SimpleDeserializer.parsedouble(strValue));
          return true;}
        else if (qName==QName_9_162) {
          ((Proposta)value).setValorHonorariosAdvogado(com.ibm.ws.webservices.engine.encoding.ser.SimpleDeserializer.parsedouble(strValue));
          return true;}
        else if (qName==QName_9_163) {
          ((Proposta)value).setValorHonorariosFebrapo(com.ibm.ws.webservices.engine.encoding.ser.SimpleDeserializer.parsedouble(strValue));
          return true;}
        else if (qName==QName_9_164) {
          ((Proposta)value).setValorReembolsoCustas(com.ibm.ws.webservices.engine.encoding.ser.SimpleDeserializer.parsedouble(strValue));
          return true;}
        else if (qName==QName_9_165) {
          ((Proposta)value).setQuantidadeParcelas(com.ibm.ws.webservices.engine.encoding.ser.SimpleDeserializer.parseint(strValue));
          return true;}
        else if (qName==QName_9_166) {
          ((Proposta)value).setValorParcela(com.ibm.ws.webservices.engine.encoding.ser.SimpleDeserializer.parsedouble(strValue));
          return true;}
        else if (qName==QName_9_167) {
          ((Proposta)value).setDataPrimeiraParcela(strValue);
          return true;}
        else if (qName==QName_9_168) {
          ((Proposta)value).setObservacoes(strValue);
          return true;}
        return false;
    }
    protected boolean tryAttributeSetFromString(javax.xml.namespace.QName qName, java.lang.String strValue) {
        return false;
    }
    protected boolean tryElementSetFromObject(javax.xml.namespace.QName qName, java.lang.Object objValue) {
        if (qName==QName_9_169) {
          ((Proposta)value).setDemonstrativoCalculo((br.org.febraban.acordosplanoseconomicos.Arquivo)objValue);
          return true;}
        return false;
    }
    protected boolean tryElementSetFromList(javax.xml.namespace.QName qName, java.util.List listValue) {
        return false;
    }
    private final static javax.xml.namespace.QName QName_9_165 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/acordos",
                  "quantidadeParcelas");
    private final static javax.xml.namespace.QName QName_9_163 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/acordos",
                  "valorHonorariosFebrapo");
    private final static javax.xml.namespace.QName QName_9_161 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/acordos",
                  "valorPoupador");
    private final static javax.xml.namespace.QName QName_9_168 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/acordos",
                  "observacoes");
    private final static javax.xml.namespace.QName QName_9_164 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/acordos",
                  "valorReembolsoCustas");
    private final static javax.xml.namespace.QName QName_9_169 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/acordos",
                  "demonstrativoCalculo");
    private final static javax.xml.namespace.QName QName_9_159 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/acordos",
                  "identificadorPropostaBanco");
    private final static javax.xml.namespace.QName QName_9_166 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/acordos",
                  "valorParcela");
    private final static javax.xml.namespace.QName QName_9_167 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/acordos",
                  "dataPrimeiraParcela");
    private final static javax.xml.namespace.QName QName_9_162 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/acordos",
                  "valorHonorariosAdvogado");
    private final static javax.xml.namespace.QName QName_9_160 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/acordos",
                  "valorTotalAcordo");
}
