/**
 * Proposta_Helper.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf031428.03 v72314182347
 */

package br.org.febraban.acordosplanoseconomicos;

public class Proposta_Helper {
    // Type metadata
    private static final com.ibm.ws.webservices.engine.description.TypeDesc typeDesc =
        new com.ibm.ws.webservices.engine.description.TypeDesc(Proposta.class);

    static {
        typeDesc.setOption("buildNum","cf031428.03");
        com.ibm.ws.webservices.engine.description.FieldDesc field = new com.ibm.ws.webservices.engine.description.ElementDesc();
        field.setFieldName("identificadorPropostaBanco");
        field.setXmlName(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/acordos", "identificadorPropostaBanco"));
        field.setXmlType(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(field);
        field = new com.ibm.ws.webservices.engine.description.ElementDesc();
        field.setFieldName("valorTotalAcordo");
        field.setXmlName(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/acordos", "valorTotalAcordo"));
        field.setXmlType(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.w3.org/2001/XMLSchema", "double"));
        typeDesc.addFieldDesc(field);
        field = new com.ibm.ws.webservices.engine.description.ElementDesc();
        field.setFieldName("valorPoupador");
        field.setXmlName(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/acordos", "valorPoupador"));
        field.setXmlType(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.w3.org/2001/XMLSchema", "double"));
        typeDesc.addFieldDesc(field);
        field = new com.ibm.ws.webservices.engine.description.ElementDesc();
        field.setFieldName("valorHonorariosAdvogado");
        field.setXmlName(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/acordos", "valorHonorariosAdvogado"));
        field.setXmlType(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.w3.org/2001/XMLSchema", "double"));
        typeDesc.addFieldDesc(field);
        field = new com.ibm.ws.webservices.engine.description.ElementDesc();
        field.setFieldName("valorHonorariosFebrapo");
        field.setXmlName(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/acordos", "valorHonorariosFebrapo"));
        field.setXmlType(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.w3.org/2001/XMLSchema", "double"));
        typeDesc.addFieldDesc(field);
        field = new com.ibm.ws.webservices.engine.description.ElementDesc();
        field.setFieldName("valorReembolsoCustas");
        field.setXmlName(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/acordos", "valorReembolsoCustas"));
        field.setXmlType(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.w3.org/2001/XMLSchema", "double"));
        typeDesc.addFieldDesc(field);
        field = new com.ibm.ws.webservices.engine.description.ElementDesc();
        field.setFieldName("quantidadeParcelas");
        field.setXmlName(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/acordos", "quantidadeParcelas"));
        field.setXmlType(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(field);
        field = new com.ibm.ws.webservices.engine.description.ElementDesc();
        field.setFieldName("valorParcela");
        field.setXmlName(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/acordos", "valorParcela"));
        field.setXmlType(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.w3.org/2001/XMLSchema", "double"));
        typeDesc.addFieldDesc(field);
        field = new com.ibm.ws.webservices.engine.description.ElementDesc();
        field.setFieldName("dataPrimeiraParcela");
        field.setXmlName(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/acordos", "dataPrimeiraParcela"));
        field.setXmlType(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.w3.org/2001/XMLSchema", "string"));
        field.setMinOccursIs0(true);
        typeDesc.addFieldDesc(field);
        field = new com.ibm.ws.webservices.engine.description.ElementDesc();
        field.setFieldName("observacoes");
        field.setXmlName(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/acordos", "observacoes"));
        field.setXmlType(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.w3.org/2001/XMLSchema", "string"));
        field.setMinOccursIs0(true);
        typeDesc.addFieldDesc(field);
        field = new com.ibm.ws.webservices.engine.description.ElementDesc();
        field.setFieldName("demonstrativoCalculo");
        field.setXmlName(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/acordos", "demonstrativoCalculo"));
        field.setXmlType(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://acordosplanoseconomicos.febraban.org.br/contratos/documentos", "Arquivo"));
        field.setMinOccursIs0(true);
        typeDesc.addFieldDesc(field);
    };

    /**
     * Return type metadata object
     */
    public static com.ibm.ws.webservices.engine.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static com.ibm.ws.webservices.engine.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class javaType,  
           javax.xml.namespace.QName xmlType) {
        return 
          new Proposta_Ser(
            javaType, xmlType, typeDesc);
    };

    /**
     * Get Custom Deserializer
     */
    public static com.ibm.ws.webservices.engine.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class javaType,  
           javax.xml.namespace.QName xmlType) {
        return 
          new Proposta_Deser(
            javaType, xmlType, typeDesc);
    };

}
