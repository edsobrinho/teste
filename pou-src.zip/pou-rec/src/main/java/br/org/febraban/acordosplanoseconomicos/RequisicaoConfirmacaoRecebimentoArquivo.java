/**
 * RequisicaoConfirmacaoRecebimentoArquivo.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf031428.03 v72314182347
 */

package br.org.febraban.acordosplanoseconomicos;

public class RequisicaoConfirmacaoRecebimentoArquivo  {
    private br.org.febraban.acordosplanoseconomicos.IdentificadorArquivo[] listaIdentificadorArquivos;

    public RequisicaoConfirmacaoRecebimentoArquivo() {
    }

    public br.org.febraban.acordosplanoseconomicos.IdentificadorArquivo[] getListaIdentificadorArquivos() {
        return listaIdentificadorArquivos;
    }

    public void setListaIdentificadorArquivos(br.org.febraban.acordosplanoseconomicos.IdentificadorArquivo[] listaIdentificadorArquivos) {
        this.listaIdentificadorArquivos = listaIdentificadorArquivos;
    }

}
