/**
 * RespostaObterPedido.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf031428.03 v72314182347
 */

package br.org.febraban.acordosplanoseconomicos;

public class RespostaObterPedido  {
    private br.org.febraban.acordosplanoseconomicos.Pedido[] pedidos;
    private java.lang.Integer quantidadeTotalPedidos;

    public RespostaObterPedido() {
    }

    public br.org.febraban.acordosplanoseconomicos.Pedido[] getPedidos() {
        return pedidos;
    }

    public void setPedidos(br.org.febraban.acordosplanoseconomicos.Pedido[] pedidos) {
        this.pedidos = pedidos;
    }

    public java.lang.Integer getQuantidadeTotalPedidos() {
        return quantidadeTotalPedidos;
    }

    public void setQuantidadeTotalPedidos(java.lang.Integer quantidadeTotalPedidos) {
        this.quantidadeTotalPedidos = quantidadeTotalPedidos;
    }

}
