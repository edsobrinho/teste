/**
 * RespostaOperacao.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf031428.03 v72314182347
 */

package br.org.febraban.acordosplanoseconomicos;

public class RespostaOperacao  {
    private java.lang.String codigoRetorno;
    private br.org.febraban.acordosplanoseconomicos.RetornoProcessamentoEnum retorno;
    private java.lang.String descricaoRetorno;

    public RespostaOperacao() {
    }

    public java.lang.String getCodigoRetorno() {
        return codigoRetorno;
    }

    public void setCodigoRetorno(java.lang.String codigoRetorno) {
        this.codigoRetorno = codigoRetorno;
    }

    public br.org.febraban.acordosplanoseconomicos.RetornoProcessamentoEnum getRetorno() {
        return retorno;
    }

    public void setRetorno(br.org.febraban.acordosplanoseconomicos.RetornoProcessamentoEnum retorno) {
        this.retorno = retorno;
    }

    public java.lang.String getDescricaoRetorno() {
        return descricaoRetorno;
    }

    public void setDescricaoRetorno(java.lang.String descricaoRetorno) {
        this.descricaoRetorno = descricaoRetorno;
    }

}
