/**
 * ResultadoAnaliseBPO.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf031428.03 v72314182347
 */

package br.org.febraban.acordosplanoseconomicos;

public class ResultadoAnaliseBPO  {
    private int identificadorItem;
    private java.lang.String descricaoItem;
    private br.org.febraban.acordosplanoseconomicos.ContextoEnum contexto;
    private int idChaveContexto;
    private br.org.febraban.acordosplanoseconomicos.ResultadoAnaliseBPOEnum resultado;
    private br.org.febraban.acordosplanoseconomicos.TipoDocumentoEnum tipoDocumento;
    private br.org.febraban.acordosplanoseconomicos.MotivoNCEnum[] motivoNC;

    public ResultadoAnaliseBPO() {
    }

    public int getIdentificadorItem() {
        return identificadorItem;
    }

    public void setIdentificadorItem(int identificadorItem) {
        this.identificadorItem = identificadorItem;
    }

    public java.lang.String getDescricaoItem() {
        return descricaoItem;
    }

    public void setDescricaoItem(java.lang.String descricaoItem) {
        this.descricaoItem = descricaoItem;
    }

    public br.org.febraban.acordosplanoseconomicos.ContextoEnum getContexto() {
        return contexto;
    }

    public void setContexto(br.org.febraban.acordosplanoseconomicos.ContextoEnum contexto) {
        this.contexto = contexto;
    }

    public int getIdChaveContexto() {
        return idChaveContexto;
    }

    public void setIdChaveContexto(int idChaveContexto) {
        this.idChaveContexto = idChaveContexto;
    }

    public br.org.febraban.acordosplanoseconomicos.ResultadoAnaliseBPOEnum getResultado() {
        return resultado;
    }

    public void setResultado(br.org.febraban.acordosplanoseconomicos.ResultadoAnaliseBPOEnum resultado) {
        this.resultado = resultado;
    }

    public br.org.febraban.acordosplanoseconomicos.TipoDocumentoEnum getTipoDocumento() {
        return tipoDocumento;
    }

    public void setTipoDocumento(br.org.febraban.acordosplanoseconomicos.TipoDocumentoEnum tipoDocumento) {
        this.tipoDocumento = tipoDocumento;
    }

    public br.org.febraban.acordosplanoseconomicos.MotivoNCEnum[] getMotivoNC() {
        return motivoNC;
    }

    public void setMotivoNC(br.org.febraban.acordosplanoseconomicos.MotivoNCEnum[] motivoNC) {
        this.motivoNC = motivoNC;
    }

}
