/**
 * ResultadoAnaliseBPO_Deser.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf031428.03 v72314182347
 */

package br.org.febraban.acordosplanoseconomicos;

public class ResultadoAnaliseBPO_Deser extends com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializer {
    /**
     * Constructor
     */
    public ResultadoAnaliseBPO_Deser(
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType, 
           com.ibm.ws.webservices.engine.description.TypeDesc _typeDesc) {
        super(_javaType, _xmlType, _typeDesc);
    }
    /**
     * Create instance of java bean
     */
    public void createValue() {
        value = new ResultadoAnaliseBPO();
    }
    protected boolean tryElementSetFromString(javax.xml.namespace.QName qName, java.lang.String strValue) {
        if (qName==QName_4_148) {
          ((ResultadoAnaliseBPO)value).setIdentificadorItem(com.ibm.ws.webservices.engine.encoding.ser.SimpleDeserializer.parseint(strValue));
          return true;}
        else if (qName==QName_4_149) {
          ((ResultadoAnaliseBPO)value).setDescricaoItem(strValue);
          return true;}
        else if (qName==QName_4_151) {
          ((ResultadoAnaliseBPO)value).setIdChaveContexto(com.ibm.ws.webservices.engine.encoding.ser.SimpleDeserializer.parseint(strValue));
          return true;}
        return false;
    }
    protected boolean tryAttributeSetFromString(javax.xml.namespace.QName qName, java.lang.String strValue) {
        return false;
    }
    protected boolean tryElementSetFromObject(javax.xml.namespace.QName qName, java.lang.Object objValue) {
        if (qName==QName_4_150) {
          ((ResultadoAnaliseBPO)value).setContexto((br.org.febraban.acordosplanoseconomicos.ContextoEnum)objValue);
          return true;}
        else if (qName==QName_4_17) {
          ((ResultadoAnaliseBPO)value).setResultado((br.org.febraban.acordosplanoseconomicos.ResultadoAnaliseBPOEnum)objValue);
          return true;}
        else if (qName==QName_4_152) {
          ((ResultadoAnaliseBPO)value).setTipoDocumento((br.org.febraban.acordosplanoseconomicos.TipoDocumentoEnum)objValue);
          return true;}
        else if (qName==QName_4_153) {
          if (objValue instanceof java.util.List) {
            br.org.febraban.acordosplanoseconomicos.MotivoNCEnum[] array = new br.org.febraban.acordosplanoseconomicos.MotivoNCEnum[((java.util.List)objValue).size()];
            ((java.util.List)objValue).toArray(array);
            ((ResultadoAnaliseBPO)value).setMotivoNC(array);
          } else { 
            ((ResultadoAnaliseBPO)value).setMotivoNC((br.org.febraban.acordosplanoseconomicos.MotivoNCEnum[])objValue);}
          return true;}
        return false;
    }
    protected boolean tryElementSetFromList(javax.xml.namespace.QName qName, java.util.List listValue) {
        return false;
    }
    private final static javax.xml.namespace.QName QName_4_150 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "Contexto");
    private final static javax.xml.namespace.QName QName_4_153 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "MotivoNC");
    private final static javax.xml.namespace.QName QName_4_149 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "DescricaoItem");
    private final static javax.xml.namespace.QName QName_4_148 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "IdentificadorItem");
    private final static javax.xml.namespace.QName QName_4_151 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "IdChaveContexto");
    private final static javax.xml.namespace.QName QName_4_152 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "TipoDocumento");
    private final static javax.xml.namespace.QName QName_4_17 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "Resultado");
}
