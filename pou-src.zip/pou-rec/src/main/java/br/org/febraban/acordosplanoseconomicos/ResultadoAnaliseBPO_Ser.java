/**
 * ResultadoAnaliseBPO_Ser.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf031428.03 v72314182347
 */

package br.org.febraban.acordosplanoseconomicos;

public class ResultadoAnaliseBPO_Ser extends com.ibm.ws.webservices.engine.encoding.ser.BeanSerializer {
    /**
     * Constructor
     */
    public ResultadoAnaliseBPO_Ser(
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType, 
           com.ibm.ws.webservices.engine.description.TypeDesc _typeDesc) {
        super(_javaType, _xmlType, _typeDesc);
    }
    public void serialize(
        javax.xml.namespace.QName name,
        org.xml.sax.Attributes attributes,
        java.lang.Object value,
        com.ibm.ws.webservices.engine.encoding.SerializationContext context)
        throws java.io.IOException
    {
        context.startElement(name, addAttributes(attributes, value, context));
        addElements(value, context);
        context.endElement();
    }
    protected org.xml.sax.Attributes addAttributes(
        org.xml.sax.Attributes attributes,
        java.lang.Object value,
        com.ibm.ws.webservices.engine.encoding.SerializationContext context)
        throws java.io.IOException
    {
           javax.xml.namespace.QName
           elemQName = QName_4_148;
           context.qName2String(elemQName, true);
           elemQName = QName_4_149;
           context.qName2String(elemQName, true);
           elemQName = QName_4_150;
           context.qName2String(elemQName, true);
           elemQName = QName_4_151;
           context.qName2String(elemQName, true);
           elemQName = QName_4_17;
           context.qName2String(elemQName, true);
           elemQName = QName_4_152;
           context.qName2String(elemQName, true);
           elemQName = QName_4_153;
           context.qName2String(elemQName, true);
        return attributes;
    }
    protected void addElements(
        java.lang.Object value,
        com.ibm.ws.webservices.engine.encoding.SerializationContext context)
        throws java.io.IOException
    {
        ResultadoAnaliseBPO bean = (ResultadoAnaliseBPO) value;
        java.lang.Object propValue;
        javax.xml.namespace.QName propQName;
        {
          propQName = QName_4_148;
          propValue = new java.lang.Integer(bean.getIdentificadorItem());
          serializeChild(propQName, null, 
              propValue, 
              QName_1_6,
              true,null,context);
          propQName = QName_4_149;
          propValue = bean.getDescricaoItem();
          if (propValue != null && !context.shouldSendXSIType()) {
            context.simpleElement(propQName, null, propValue.toString()); 
          } else {
            serializeChild(propQName, null, 
              propValue, 
              QName_1_5,
              true,null,context);
          }
          propQName = QName_4_150;
          propValue = bean.getContexto();
          serializeChild(propQName, null, 
              propValue, 
              QName_8_154,
              true,null,context);
          propQName = QName_4_151;
          propValue = new java.lang.Integer(bean.getIdChaveContexto());
          serializeChild(propQName, null, 
              propValue, 
              QName_1_6,
              true,null,context);
          propQName = QName_4_17;
          propValue = bean.getResultado();
          serializeChild(propQName, null, 
              propValue, 
              QName_2_155,
              true,null,context);
          propQName = QName_4_152;
          propValue = bean.getTipoDocumento();
          serializeChild(propQName, null, 
              propValue, 
              QName_8_156,
              false,null,context);
          propQName = QName_4_153;
          propValue = bean.getMotivoNC();
          serializeChild(propQName, null, 
              propValue, 
              QName_2_157,
              true,null,context);
        }
    }
    private final static javax.xml.namespace.QName QName_2_157 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/enums",
                  "ArrayOfMotivoNCEnum");
    private final static javax.xml.namespace.QName QName_1_6 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://www.w3.org/2001/XMLSchema",
                  "int");
    private final static javax.xml.namespace.QName QName_4_17 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "Resultado");
    private final static javax.xml.namespace.QName QName_4_149 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "DescricaoItem");
    private final static javax.xml.namespace.QName QName_4_151 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "IdChaveContexto");
    private final static javax.xml.namespace.QName QName_4_150 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "Contexto");
    private final static javax.xml.namespace.QName QName_8_154 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/enums",
                  "ContextoEnum");
    private final static javax.xml.namespace.QName QName_4_148 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "IdentificadorItem");
    private final static javax.xml.namespace.QName QName_4_153 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "MotivoNC");
    private final static javax.xml.namespace.QName QName_1_5 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://www.w3.org/2001/XMLSchema",
                  "string");
    private final static javax.xml.namespace.QName QName_4_152 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/",
                  "TipoDocumento");
    private final static javax.xml.namespace.QName QName_8_156 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/enums",
                  "TipoDocumentoEnum");
    private final static javax.xml.namespace.QName QName_2_155 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/enums",
                  "ResultadoAnaliseBPOEnum");
}
