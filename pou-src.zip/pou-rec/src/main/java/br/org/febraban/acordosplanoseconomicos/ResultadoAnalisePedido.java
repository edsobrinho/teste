/**
 * ResultadoAnalisePedido.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf031428.03 v72314182347
 */

package br.org.febraban.acordosplanoseconomicos;

public class ResultadoAnalisePedido  {
    private java.lang.String guidPedido;
    private br.org.febraban.acordosplanoseconomicos.TipoResultadoAnaliseHabilitacaoEnum resultado;
    private br.org.febraban.acordosplanoseconomicos.MotivoRecusaPedidoEnum motivoRecusaPedido;
    private java.lang.String subMotivoRecusa;
    private br.org.febraban.acordosplanoseconomicos.Proposta proposta;
    private java.lang.String dataAnalise;

    public ResultadoAnalisePedido() {
    }

    public java.lang.String getGuidPedido() {
        return guidPedido;
    }

    public void setGuidPedido(java.lang.String guidPedido) {
        this.guidPedido = guidPedido;
    }

    public br.org.febraban.acordosplanoseconomicos.TipoResultadoAnaliseHabilitacaoEnum getResultado() {
        return resultado;
    }

    public void setResultado(br.org.febraban.acordosplanoseconomicos.TipoResultadoAnaliseHabilitacaoEnum resultado) {
        this.resultado = resultado;
    }

    public br.org.febraban.acordosplanoseconomicos.MotivoRecusaPedidoEnum getMotivoRecusaPedido() {
        return motivoRecusaPedido;
    }

    public void setMotivoRecusaPedido(br.org.febraban.acordosplanoseconomicos.MotivoRecusaPedidoEnum motivoRecusaPedido) {
        this.motivoRecusaPedido = motivoRecusaPedido;
    }

    public java.lang.String getSubMotivoRecusa() {
        return subMotivoRecusa;
    }

    public void setSubMotivoRecusa(java.lang.String subMotivoRecusa) {
        this.subMotivoRecusa = subMotivoRecusa;
    }

    public br.org.febraban.acordosplanoseconomicos.Proposta getProposta() {
        return proposta;
    }

    public void setProposta(br.org.febraban.acordosplanoseconomicos.Proposta proposta) {
        this.proposta = proposta;
    }

    public java.lang.String getDataAnalise() {
        return dataAnalise;
    }

    public void setDataAnalise(java.lang.String dataAnalise) {
        this.dataAnalise = dataAnalise;
    }

}
