/**
 * ResultadoAnalisePedido_Deser.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf031428.03 v72314182347
 */

package br.org.febraban.acordosplanoseconomicos;

public class ResultadoAnalisePedido_Deser extends com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializer {
    /**
     * Constructor
     */
    public ResultadoAnalisePedido_Deser(
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType, 
           com.ibm.ws.webservices.engine.description.TypeDesc _typeDesc) {
        super(_javaType, _xmlType, _typeDesc);
    }
    /**
     * Create instance of java bean
     */
    public void createValue() {
        value = new ResultadoAnalisePedido();
    }
    protected boolean tryElementSetFromString(javax.xml.namespace.QName qName, java.lang.String strValue) {
        if (qName==QName_9_2) {
          ((ResultadoAnalisePedido)value).setGuidPedido(strValue);
          return true;}
        else if (qName==QName_9_19) {
          ((ResultadoAnalisePedido)value).setSubMotivoRecusa(strValue);
          return true;}
        else if (qName==QName_9_21) {
          ((ResultadoAnalisePedido)value).setDataAnalise(strValue);
          return true;}
        return false;
    }
    protected boolean tryAttributeSetFromString(javax.xml.namespace.QName qName, java.lang.String strValue) {
        return false;
    }
    protected boolean tryElementSetFromObject(javax.xml.namespace.QName qName, java.lang.Object objValue) {
        if (qName==QName_9_17) {
          ((ResultadoAnalisePedido)value).setResultado((br.org.febraban.acordosplanoseconomicos.TipoResultadoAnaliseHabilitacaoEnum)objValue);
          return true;}
        else if (qName==QName_9_18) {
          ((ResultadoAnalisePedido)value).setMotivoRecusaPedido((br.org.febraban.acordosplanoseconomicos.MotivoRecusaPedidoEnum)objValue);
          return true;}
        else if (qName==QName_9_20) {
          ((ResultadoAnalisePedido)value).setProposta((br.org.febraban.acordosplanoseconomicos.Proposta)objValue);
          return true;}
        return false;
    }
    protected boolean tryElementSetFromList(javax.xml.namespace.QName qName, java.util.List listValue) {
        return false;
    }
    private final static javax.xml.namespace.QName QName_9_2 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/acordos",
                  "GuidPedido");
    private final static javax.xml.namespace.QName QName_9_17 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/acordos",
                  "Resultado");
    private final static javax.xml.namespace.QName QName_9_21 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/acordos",
                  "DataAnalise");
    private final static javax.xml.namespace.QName QName_9_20 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/acordos",
                  "Proposta");
    private final static javax.xml.namespace.QName QName_9_19 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/acordos",
                  "SubMotivoRecusa");
    private final static javax.xml.namespace.QName QName_9_18 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/acordos",
                  "MotivoRecusaPedido");
}
