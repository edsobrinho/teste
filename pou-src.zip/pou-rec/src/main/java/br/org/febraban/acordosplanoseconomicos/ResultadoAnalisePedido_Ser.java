/**
 * ResultadoAnalisePedido_Ser.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf031428.03 v72314182347
 */

package br.org.febraban.acordosplanoseconomicos;

public class ResultadoAnalisePedido_Ser extends com.ibm.ws.webservices.engine.encoding.ser.BeanSerializer {
    /**
     * Constructor
     */
    public ResultadoAnalisePedido_Ser(
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType, 
           com.ibm.ws.webservices.engine.description.TypeDesc _typeDesc) {
        super(_javaType, _xmlType, _typeDesc);
    }
    public void serialize(
        javax.xml.namespace.QName name,
        org.xml.sax.Attributes attributes,
        java.lang.Object value,
        com.ibm.ws.webservices.engine.encoding.SerializationContext context)
        throws java.io.IOException
    {
        context.startElement(name, addAttributes(attributes, value, context));
        addElements(value, context);
        context.endElement();
    }
    protected org.xml.sax.Attributes addAttributes(
        org.xml.sax.Attributes attributes,
        java.lang.Object value,
        com.ibm.ws.webservices.engine.encoding.SerializationContext context)
        throws java.io.IOException
    {
           javax.xml.namespace.QName
           elemQName = QName_9_2;
           context.qName2String(elemQName, true);
           elemQName = QName_9_17;
           context.qName2String(elemQName, true);
           elemQName = QName_9_18;
           context.qName2String(elemQName, true);
           elemQName = QName_9_19;
           context.qName2String(elemQName, true);
           elemQName = QName_9_20;
           context.qName2String(elemQName, true);
           elemQName = QName_9_21;
           context.qName2String(elemQName, true);
        return attributes;
    }
    protected void addElements(
        java.lang.Object value,
        com.ibm.ws.webservices.engine.encoding.SerializationContext context)
        throws java.io.IOException
    {
        ResultadoAnalisePedido bean = (ResultadoAnalisePedido) value;
        java.lang.Object propValue;
        javax.xml.namespace.QName propQName;
        {
          propQName = QName_9_2;
          propValue = bean.getGuidPedido();
          if (propValue != null && !context.shouldSendXSIType()) {
            context.simpleElement(propQName, null, propValue.toString()); 
          } else {
            serializeChild(propQName, null, 
              propValue, 
              QName_1_5,
              true,null,context);
          }
          propQName = QName_9_17;
          propValue = bean.getResultado();
          serializeChild(propQName, null, 
              propValue, 
              QName_10_22,
              true,null,context);
          propQName = QName_9_18;
          propValue = bean.getMotivoRecusaPedido();
          serializeChild(propQName, null, 
              propValue, 
              QName_2_23,
              false,null,context);
          propQName = QName_9_19;
          propValue = bean.getSubMotivoRecusa();
          if (propValue != null && !context.shouldSendXSIType()) {
            context.simpleElement(propQName, null, propValue.toString()); 
          } else {
            serializeChild(propQName, null, 
              propValue, 
              QName_1_5,
              false,null,context);
          }
          propQName = QName_9_20;
          propValue = bean.getProposta();
          serializeChild(propQName, null, 
              propValue, 
              QName_9_20,
              false,null,context);
          propQName = QName_9_21;
          propValue = bean.getDataAnalise();
          if (propValue != null && !context.shouldSendXSIType()) {
            context.simpleElement(propQName, null, propValue.toString()); 
          } else {
            serializeChild(propQName, null, 
              propValue, 
              QName_1_5,
              true,null,context);
          }
        }
    }
    private final static javax.xml.namespace.QName QName_9_20 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/acordos",
                  "Proposta");
    private final static javax.xml.namespace.QName QName_9_17 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/acordos",
                  "Resultado");
    private final static javax.xml.namespace.QName QName_2_23 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/pedidos/enums",
                  "MotivoRecusaPedidoEnum");
    private final static javax.xml.namespace.QName QName_9_21 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/acordos",
                  "DataAnalise");
    private final static javax.xml.namespace.QName QName_1_5 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://www.w3.org/2001/XMLSchema",
                  "string");
    private final static javax.xml.namespace.QName QName_9_19 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/acordos",
                  "SubMotivoRecusa");
    private final static javax.xml.namespace.QName QName_10_22 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/acordos/enums",
                  "TipoResultadoAnaliseHabilitacaoEnum");
    private final static javax.xml.namespace.QName QName_9_2 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/acordos",
                  "GuidPedido");
    private final static javax.xml.namespace.QName QName_9_18 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://acordosplanoseconomicos.febraban.org.br/contratos/acordos",
                  "MotivoRecusaPedido");
}
