/**
 * StatusPagamentoEnum.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf031428.03 v72314182347
 */

package br.org.febraban.acordosplanoseconomicos;

public class StatusPagamentoEnum  {
    private java.lang.String _value_;
    private static java.util.HashMap _table_ = new java.util.HashMap();

    // Constructor
    protected StatusPagamentoEnum(java.lang.String value) {
        _value_ = value;
        _table_.put(_value_,this);
    };

    public static final java.lang.String _REALIZADO = "REALIZADO";
    public static final java.lang.String _NAO_REALIZADO = "NAO_REALIZADO";
    public static final StatusPagamentoEnum REALIZADO = new StatusPagamentoEnum(_REALIZADO);
    public static final StatusPagamentoEnum NAO_REALIZADO = new StatusPagamentoEnum(_NAO_REALIZADO);
    public java.lang.String getValue() { return _value_;}
    public static StatusPagamentoEnum fromValue(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        StatusPagamentoEnum enumeration = (StatusPagamentoEnum)
            _table_.get(value);
        if (enumeration==null) throw new java.lang.IllegalArgumentException();
        return enumeration;
    }
    public static StatusPagamentoEnum fromString(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        return fromValue(value);
    }
    public boolean equals(java.lang.Object obj) {return (obj == this);}
    public int hashCode() { return toString().hashCode();}
    public java.lang.String toString() { return _value_;}

}
