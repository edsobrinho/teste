/**
 * StatusPedidoEnum.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf031428.03 v72314182347
 */

package br.org.febraban.acordosplanoseconomicos;

public class StatusPedidoEnum  {
    private java.lang.String _value_;
    private static java.util.HashMap _table_ = new java.util.HashMap();

    // Constructor
    protected StatusPedidoEnum(java.lang.String value) {
        _value_ = value;
        _table_.put(_value_,this);
    };

    public static final java.lang.String _EM_PREENCHIMENTO = "EM_PREENCHIMENTO";
    public static final java.lang.String _ANALISE_DA_INSTITUICAO = "ANALISE_DA_INSTITUICAO";
    public static final java.lang.String _PENDENCIA_DE_DOCUMENTOS = "PENDENCIA_DE_DOCUMENTOS";
    public static final java.lang.String _HABILITACAO_NEGADA = "HABILITACAO_NEGADA";
    public static final java.lang.String _AGUARDANDO_ACEITE = "AGUARDANDO_ACEITE";
    public static final java.lang.String _ACORDO_NAO_ACEITO = "ACORDO_NAO_ACEITO";
    public static final java.lang.String _PAGAMENTOS_AGENDADOS = "PAGAMENTOS_AGENDADOS";
    public static final java.lang.String _PAGAMENTOS_CONCLUIDOS = "PAGAMENTOS_CONCLUIDOS";
    public static final StatusPedidoEnum EM_PREENCHIMENTO = new StatusPedidoEnum(_EM_PREENCHIMENTO);
    public static final StatusPedidoEnum ANALISE_DA_INSTITUICAO = new StatusPedidoEnum(_ANALISE_DA_INSTITUICAO);
    public static final StatusPedidoEnum PENDENCIA_DE_DOCUMENTOS = new StatusPedidoEnum(_PENDENCIA_DE_DOCUMENTOS);
    public static final StatusPedidoEnum HABILITACAO_NEGADA = new StatusPedidoEnum(_HABILITACAO_NEGADA);
    public static final StatusPedidoEnum AGUARDANDO_ACEITE = new StatusPedidoEnum(_AGUARDANDO_ACEITE);
    public static final StatusPedidoEnum ACORDO_NAO_ACEITO = new StatusPedidoEnum(_ACORDO_NAO_ACEITO);
    public static final StatusPedidoEnum PAGAMENTOS_AGENDADOS = new StatusPedidoEnum(_PAGAMENTOS_AGENDADOS);
    public static final StatusPedidoEnum PAGAMENTOS_CONCLUIDOS = new StatusPedidoEnum(_PAGAMENTOS_CONCLUIDOS);
    public java.lang.String getValue() { return _value_;}
    public static StatusPedidoEnum fromValue(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        StatusPedidoEnum enumeration = (StatusPedidoEnum)
            _table_.get(value);
        if (enumeration==null) throw new java.lang.IllegalArgumentException();
        return enumeration;
    }
    public static StatusPedidoEnum fromString(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        return fromValue(value);
    }
    public boolean equals(java.lang.Object obj) {return (obj == this);}
    public int hashCode() { return toString().hashCode();}
    public java.lang.String toString() { return _value_;}

}
