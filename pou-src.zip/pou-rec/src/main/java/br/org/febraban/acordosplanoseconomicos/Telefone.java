/**
 * Telefone.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf031428.03 v72314182347
 */

package br.org.febraban.acordosplanoseconomicos;

public class Telefone  {
    private java.lang.String DDD;
    private java.lang.String numero;

    public Telefone() {
    }

    public java.lang.String getDDD() {
        return DDD;
    }

    public void setDDD(java.lang.String DDD) {
        this.DDD = DDD;
    }

    public java.lang.String getNumero() {
        return numero;
    }

    public void setNumero(java.lang.String numero) {
        this.numero = numero;
    }

}
