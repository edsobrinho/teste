/**
 * TipoAcaoEnum.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf031428.03 v72314182347
 */

package br.org.febraban.acordosplanoseconomicos;

public class TipoAcaoEnum  {
    private java.lang.String _value_;
    private static java.util.HashMap _table_ = new java.util.HashMap();

    // Constructor
    protected TipoAcaoEnum(java.lang.String value) {
        _value_ = value;
        _table_.put(_value_,this);
    };

    public static final java.lang.String _ORDINARIA = "ORDINARIA";
    public static final java.lang.String _CUMPRIMENTO_SENTENCA_ORIGINARIO_ACAO_CIVIL_PUBLICA = "CUMPRIMENTO_SENTENCA_ORIGINARIO_ACAO_CIVIL_PUBLICA";
    public static final java.lang.String _EXIBICAO_DOCUMENTOS = "EXIBICAO_DOCUMENTOS";
    public static final TipoAcaoEnum ORDINARIA = new TipoAcaoEnum(_ORDINARIA);
    public static final TipoAcaoEnum CUMPRIMENTO_SENTENCA_ORIGINARIO_ACAO_CIVIL_PUBLICA = new TipoAcaoEnum(_CUMPRIMENTO_SENTENCA_ORIGINARIO_ACAO_CIVIL_PUBLICA);
    public static final TipoAcaoEnum EXIBICAO_DOCUMENTOS = new TipoAcaoEnum(_EXIBICAO_DOCUMENTOS);
    public java.lang.String getValue() { return _value_;}
    public static TipoAcaoEnum fromValue(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        TipoAcaoEnum enumeration = (TipoAcaoEnum)
            _table_.get(value);
        if (enumeration==null) throw new java.lang.IllegalArgumentException();
        return enumeration;
    }
    public static TipoAcaoEnum fromString(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        return fromValue(value);
    }
    public boolean equals(java.lang.Object obj) {return (obj == this);}
    public int hashCode() { return toString().hashCode();}
    public java.lang.String toString() { return _value_;}

}
