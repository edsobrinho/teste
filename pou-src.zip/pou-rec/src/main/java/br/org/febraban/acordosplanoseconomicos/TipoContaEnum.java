/**
 * TipoContaEnum.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf031428.03 v72314182347
 */

package br.org.febraban.acordosplanoseconomicos;

public class TipoContaEnum  {
    private java.lang.String _value_;
    private static java.util.HashMap _table_ = new java.util.HashMap();

    // Constructor
    protected TipoContaEnum(java.lang.String value) {
        _value_ = value;
        _table_.put(_value_,this);
    };

    public static final java.lang.String _CONTA_CORRENTE = "CONTA_CORRENTE";
    public static final java.lang.String _POUPANCA = "POUPANCA";
    public static final TipoContaEnum CONTA_CORRENTE = new TipoContaEnum(_CONTA_CORRENTE);
    public static final TipoContaEnum POUPANCA = new TipoContaEnum(_POUPANCA);
    public java.lang.String getValue() { return _value_;}
    public static TipoContaEnum fromValue(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        TipoContaEnum enumeration = (TipoContaEnum)
            _table_.get(value);
        if (enumeration==null) throw new java.lang.IllegalArgumentException();
        return enumeration;
    }
    public static TipoContaEnum fromString(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        return fromValue(value);
    }
    public boolean equals(java.lang.Object obj) {return (obj == this);}
    public int hashCode() { return toString().hashCode();}
    public java.lang.String toString() { return _value_;}

}
