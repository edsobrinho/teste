/**
 * TipoDocumentoEnum.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf031428.03 v72314182347
 */

package br.org.febraban.acordosplanoseconomicos;

public class TipoDocumentoEnum  {
    private java.lang.String _value_;
    private static java.util.HashMap _table_ = new java.util.HashMap();

    // Constructor
    protected TipoDocumentoEnum(java.lang.String value) {
        _value_ = value;
        _table_.put(_value_,this);
    };

    public static final java.lang.String _RG = "RG";
    public static final java.lang.String _RNE = "RNE";
    public static final java.lang.String _CPF = "CPF";
    public static final java.lang.String _OAB = "OAB";
    public static final java.lang.String _OAB_SUPLEMENTAR = "OAB_SUPLEMENTAR";
    public static final java.lang.String _TERMO_INVENTARIANTE = "TERMO_INVENTARIANTE";
    public static final java.lang.String _COPIA_INVENTARIO = "COPIA_INVENTARIO";
    public static final java.lang.String _CERTIDAO_OBITO = "CERTIDAO_OBITO";
    public static final java.lang.String _PROCURACAO = "PROCURACAO";
    public static final java.lang.String _INICIAL = "INICIAL";
    public static final java.lang.String _COPIA_AUTOS = "COPIA_AUTOS";
    public static final java.lang.String _TERMO_QUITACAO_PLANOS_ECONOMICOS = "TERMO_QUITACAO_PLANOS_ECONOMICOS";
    public static final java.lang.String _PETICAO_REGULARIZACAO_POLO_ATIVO = "PETICAO_REGULARIZACAO_POLO_ATIVO";
    public static final java.lang.String _CERTIDAO_CUSTAS = "CERTIDAO_CUSTAS";
    public static final java.lang.String _DECLARACAO_VALORES_ACORDOS_PLANOS_ECONOMICOS = "DECLARACAO_VALORES_ACORDOS_PLANOS_ECONOMICOS";
    public static final java.lang.String _DIRPF = "DIRPF";
    public static final java.lang.String _EXTRATO = "EXTRATO";
    public static final java.lang.String _TERMO_ADESAO = "TERMO_ADESAO";
    public static final java.lang.String _COMPROVANTE_PAGAMENTO = "COMPROVANTE_PAGAMENTO";
    public static final java.lang.String _RACIONAL_CALCULO = "RACIONAL_CALCULO";
    public static final TipoDocumentoEnum RG = new TipoDocumentoEnum(_RG);
    public static final TipoDocumentoEnum RNE = new TipoDocumentoEnum(_RNE);
    public static final TipoDocumentoEnum CPF = new TipoDocumentoEnum(_CPF);
    public static final TipoDocumentoEnum OAB = new TipoDocumentoEnum(_OAB);
    public static final TipoDocumentoEnum OAB_SUPLEMENTAR = new TipoDocumentoEnum(_OAB_SUPLEMENTAR);
    public static final TipoDocumentoEnum TERMO_INVENTARIANTE = new TipoDocumentoEnum(_TERMO_INVENTARIANTE);
    public static final TipoDocumentoEnum COPIA_INVENTARIO = new TipoDocumentoEnum(_COPIA_INVENTARIO);
    public static final TipoDocumentoEnum CERTIDAO_OBITO = new TipoDocumentoEnum(_CERTIDAO_OBITO);
    public static final TipoDocumentoEnum PROCURACAO = new TipoDocumentoEnum(_PROCURACAO);
    public static final TipoDocumentoEnum INICIAL = new TipoDocumentoEnum(_INICIAL);
    public static final TipoDocumentoEnum COPIA_AUTOS = new TipoDocumentoEnum(_COPIA_AUTOS);
    public static final TipoDocumentoEnum TERMO_QUITACAO_PLANOS_ECONOMICOS = new TipoDocumentoEnum(_TERMO_QUITACAO_PLANOS_ECONOMICOS);
    public static final TipoDocumentoEnum PETICAO_REGULARIZACAO_POLO_ATIVO = new TipoDocumentoEnum(_PETICAO_REGULARIZACAO_POLO_ATIVO);
    public static final TipoDocumentoEnum CERTIDAO_CUSTAS = new TipoDocumentoEnum(_CERTIDAO_CUSTAS);
    public static final TipoDocumentoEnum DECLARACAO_VALORES_ACORDOS_PLANOS_ECONOMICOS = new TipoDocumentoEnum(_DECLARACAO_VALORES_ACORDOS_PLANOS_ECONOMICOS);
    public static final TipoDocumentoEnum DIRPF = new TipoDocumentoEnum(_DIRPF);
    public static final TipoDocumentoEnum EXTRATO = new TipoDocumentoEnum(_EXTRATO);
    public static final TipoDocumentoEnum TERMO_ADESAO = new TipoDocumentoEnum(_TERMO_ADESAO);
    public static final TipoDocumentoEnum COMPROVANTE_PAGAMENTO = new TipoDocumentoEnum(_COMPROVANTE_PAGAMENTO);
    public static final TipoDocumentoEnum RACIONAL_CALCULO = new TipoDocumentoEnum(_RACIONAL_CALCULO);
    public java.lang.String getValue() { return _value_;}
    public static TipoDocumentoEnum fromValue(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        TipoDocumentoEnum enumeration = (TipoDocumentoEnum)
            _table_.get(value);
        if (enumeration==null) throw new java.lang.IllegalArgumentException();
        return enumeration;
    }
    public static TipoDocumentoEnum fromString(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        return fromValue(value);
    }
    public boolean equals(java.lang.Object obj) {return (obj == this);}
    public int hashCode() { return toString().hashCode();}
    public java.lang.String toString() { return _value_;}

}
