/**
 * TipoIdentidadeEnum.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf031428.03 v72314182347
 */

package br.org.febraban.acordosplanoseconomicos;

public class TipoIdentidadeEnum  {
    private java.lang.String _value_;
    private static java.util.HashMap _table_ = new java.util.HashMap();

    // Constructor
    protected TipoIdentidadeEnum(java.lang.String value) {
        _value_ = value;
        _table_.put(_value_,this);
    };

    public static final java.lang.String _IDENTIDADE = "IDENTIDADE";
    public static final java.lang.String _RNE = "RNE";
    public static final TipoIdentidadeEnum IDENTIDADE = new TipoIdentidadeEnum(_IDENTIDADE);
    public static final TipoIdentidadeEnum RNE = new TipoIdentidadeEnum(_RNE);
    public java.lang.String getValue() { return _value_;}
    public static TipoIdentidadeEnum fromValue(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        TipoIdentidadeEnum enumeration = (TipoIdentidadeEnum)
            _table_.get(value);
        if (enumeration==null) throw new java.lang.IllegalArgumentException();
        return enumeration;
    }
    public static TipoIdentidadeEnum fromString(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        return fromValue(value);
    }
    public boolean equals(java.lang.Object obj) {return (obj == this);}
    public int hashCode() { return toString().hashCode();}
    public java.lang.String toString() { return _value_;}

}
