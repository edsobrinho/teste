/**
 * TipoProcessoEnum.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf031428.03 v72314182347
 */

package br.org.febraban.acordosplanoseconomicos;

public class TipoProcessoEnum  {
    private java.lang.String _value_;
    private static java.util.HashMap _table_ = new java.util.HashMap();

    // Constructor
    protected TipoProcessoEnum(java.lang.String value) {
        _value_ = value;
        _table_.put(_value_,this);
    };

    public static final java.lang.String _VARA_CIVEL = "VARA_CIVEL";
    public static final java.lang.String _VARA_FEDERAL = "VARA_FEDERAL";
    public static final java.lang.String _JEF_SEM_ADVOGADO = "JEF_SEM_ADVOGADO";
    public static final java.lang.String _JEF_COM_ADVOGADO = "JEF_COM_ADVOGADO";
    public static final java.lang.String _JEC_SEM_ADVOGADO = "JEC_SEM_ADVOGADO";
    public static final java.lang.String _JEC_COM_ADVOGADO = "JEC_COM_ADVOGADO";
    public static final TipoProcessoEnum VARA_CIVEL = new TipoProcessoEnum(_VARA_CIVEL);
    public static final TipoProcessoEnum VARA_FEDERAL = new TipoProcessoEnum(_VARA_FEDERAL);
    public static final TipoProcessoEnum JEF_SEM_ADVOGADO = new TipoProcessoEnum(_JEF_SEM_ADVOGADO);
    public static final TipoProcessoEnum JEF_COM_ADVOGADO = new TipoProcessoEnum(_JEF_COM_ADVOGADO);
    public static final TipoProcessoEnum JEC_SEM_ADVOGADO = new TipoProcessoEnum(_JEC_SEM_ADVOGADO);
    public static final TipoProcessoEnum JEC_COM_ADVOGADO = new TipoProcessoEnum(_JEC_COM_ADVOGADO);
    public java.lang.String getValue() { return _value_;}
    public static TipoProcessoEnum fromValue(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        TipoProcessoEnum enumeration = (TipoProcessoEnum)
            _table_.get(value);
        if (enumeration==null) throw new java.lang.IllegalArgumentException();
        return enumeration;
    }
    public static TipoProcessoEnum fromString(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        return fromValue(value);
    }
    public boolean equals(java.lang.Object obj) {return (obj == this);}
    public int hashCode() { return toString().hashCode();}
    public java.lang.String toString() { return _value_;}

}
