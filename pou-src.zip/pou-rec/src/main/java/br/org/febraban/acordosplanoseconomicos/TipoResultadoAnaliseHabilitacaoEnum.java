/**
 * TipoResultadoAnaliseHabilitacaoEnum.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf031428.03 v72314182347
 */

package br.org.febraban.acordosplanoseconomicos;

public class TipoResultadoAnaliseHabilitacaoEnum  {
    private java.lang.String _value_;
    private static java.util.HashMap _table_ = new java.util.HashMap();

    // Constructor
    protected TipoResultadoAnaliseHabilitacaoEnum(java.lang.String value) {
        _value_ = value;
        _table_.put(_value_,this);
    };

    public static final java.lang.String _HABILITACAO_NEGADA = "HABILITACAO_NEGADA";
    public static final java.lang.String _PROPOSTA_DE_ACORDO = "PROPOSTA_DE_ACORDO";
    public static final java.lang.String _PROPOSTA_DE_ACORDO_COM_VALOR_DIVERGENTE_SIMULADO = "PROPOSTA_DE_ACORDO_COM_VALOR_DIVERGENTE_SIMULADO";
    public static final TipoResultadoAnaliseHabilitacaoEnum HABILITACAO_NEGADA = new TipoResultadoAnaliseHabilitacaoEnum(_HABILITACAO_NEGADA);
    public static final TipoResultadoAnaliseHabilitacaoEnum PROPOSTA_DE_ACORDO = new TipoResultadoAnaliseHabilitacaoEnum(_PROPOSTA_DE_ACORDO);
    public static final TipoResultadoAnaliseHabilitacaoEnum PROPOSTA_DE_ACORDO_COM_VALOR_DIVERGENTE_SIMULADO = new TipoResultadoAnaliseHabilitacaoEnum(_PROPOSTA_DE_ACORDO_COM_VALOR_DIVERGENTE_SIMULADO);
    public java.lang.String getValue() { return _value_;}
    public static TipoResultadoAnaliseHabilitacaoEnum fromValue(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        TipoResultadoAnaliseHabilitacaoEnum enumeration = (TipoResultadoAnaliseHabilitacaoEnum)
            _table_.get(value);
        if (enumeration==null) throw new java.lang.IllegalArgumentException();
        return enumeration;
    }
    public static TipoResultadoAnaliseHabilitacaoEnum fromString(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        return fromValue(value);
    }
    public boolean equals(java.lang.Object obj) {return (obj == this);}
    public int hashCode() { return toString().hashCode();}
    public java.lang.String toString() { return _value_;}

}
