package com.ccb.br.pou.planos.client;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import com.ccb.br.pou.planos.conversor.PedidoConversor;
import com.ccb.br.pou.planos.to.PedidoTO;
import com.google.gson.Gson;
import com.google.gson.JsonIOException;
import com.google.gson.JsonSyntaxException;

import br.com.bicbanco.bicbase.exceptions.ServiceException;
import br.org.febraban.acordosplanoseconomicos.AcordoPlanoEconomicosServiceLocator;
import br.org.febraban.acordosplanoseconomicos.IPedidoService;
import br.org.febraban.acordosplanoseconomicos.Pedido;
import br.org.febraban.acordosplanoseconomicos.PedidoFiltro;
import br.org.febraban.acordosplanoseconomicos.RespostaObterPedido;

public class PedidoClient {
	private static final String URL_WEBSERVICE_LOCAL = "http://B017045:8088/AcordoPlanosEconomicos.Integracao.Service.Ws.AcordoPlanoEconomicosService.svc/pedido";
	private static final Logger log = Logger.getLogger(PedidoClient.class);
	private static final String PATH_FILE_JSON = "C:\\ccbjava\\_development\\files\\pou\\";
	private static final String EXT_JSON = ".json";

	public PedidoClient() {
	}

	public static void main(String[] args) {
		RespostaObterPedido pedidos = null;
		PedidoClient client = new PedidoClient();
		try {
			PedidoFiltro solicitacao = makeSolicitacao();
			pedidos = client.getPedidoServices().obterPedido(solicitacao);

			client.printJson(pedidos);
			client.saveFileJson(pedidos);
			client.getJson(pedidos);
			client.convertRemoteToLocal(pedidos);
		} catch (RemoteException e) {
			log.error(">> PedidoClient - Erro ao recuperar a URL do endpoint do RemoteException", e);
			e.printStackTrace();
		}
	}

	private PedidoTO convertRemoteToLocal(RespostaObterPedido pedidos) {
		PedidoTO local = null;
		List<PedidoTO> pedidosLocal = new ArrayList();
		PedidoConversor conversor = new PedidoConversor();

		for (Pedido remoto : pedidos.getPedidos()) {
			local = conversor.converteDoRemoto(remoto);
			pedidosLocal.add(local);
		}

		return local;
	}

	public PedidoTO obterPedido() {
		RespostaObterPedido pedidos = null;
		PedidoTO pedido = null;
		try {
			PedidoFiltro solicitacao = makeSolicitacao();

			pedidos = getPedidoServices().obterPedido(solicitacao);

			pedido = convertRemoteToLocal(pedidos);
		} catch (RemoteException e) {
//			log.error(">> PedidoClient - Erro ao recuperar a URL do endpoint do RemoteException", e);
			e.printStackTrace();
		}

		return pedido;
	}

	public void saveFileJson(RespostaObterPedido pedidos) {
		Gson gson = null;
		Pedido[] arrayOfPedido = pedidos.getPedidos();
		int i = arrayOfPedido.length;
		for (int j = 0; j < i;) {
			Pedido pedido = arrayOfPedido[j];
			gson = new Gson();

			FileWriter writer = null;
			try {
				writer = new FileWriter("C:\\ccbjava\\_development\\files\\pou\\" + pedido.getGuidPedido() + ".json");
				gson.toJson(pedido, writer);

				try {
					writer.flush();
					writer.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
				j++;

			} catch (JsonIOException e) {

				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			} finally {
				try {
					writer.flush();
					writer.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}

	public void printJson(RespostaObterPedido pedidos) {
		Gson gson = null;
		for (Pedido pedido : pedidos.getPedidos()) {
			gson = new Gson();
			String pedidoJson = gson.toJson(pedido);

			System.out.println("key: " + pedido.getGuidPedido());
			System.out.println("value: " + pedidoJson);
		}
		System.out.println(pedidos.getQuantidadeTotalPedidos());
	}

	public List<Pedido> getJson(RespostaObterPedido respostaPedidos) {
		Gson gson = null;
		Pedido dto = null;
		List<Pedido> pedidos = new ArrayList<Pedido>();

		for (Pedido pedido : respostaPedidos.getPedidos()) {
			gson = new Gson();
			try {
				String path = "C:\\ccbjava\\_development\\files\\pou\\" + pedido.getGuidPedido() + ".json";
				FileReader reader = new FileReader(path);
				System.out.println(path);
				dto = (Pedido) gson.fromJson(reader, Pedido.class);
				System.out.println(dto.toString());
				pedidos.add(dto);
			} catch (JsonSyntaxException e) {
				e.printStackTrace();
			} catch (JsonIOException e) {
				e.printStackTrace();
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
		}

		return pedidos;
	}

	public static PedidoFiltro makeSolicitacao() {
		PedidoFiltro solicitacao = new PedidoFiltro();

		return solicitacao;
	}

	private IPedidoService getPedidoServices() {
		IPedidoService dominioService = null;
		AcordoPlanoEconomicosServiceLocator serviceLocator = new AcordoPlanoEconomicosServiceLocator();
		try {
			dominioService = serviceLocator.getPedido(new URL(
					"http://B017045:8088/AcordoPlanosEconomicos.Integracao.Service.Ws.AcordoPlanoEconomicosService.svc/pedido"));
		} catch (MalformedURLException e) {
			log.error(">> DominioClient - Erro ao recuperar a URL do endpoint do getDominio", e);
		} catch (ServiceException e) {
			log.error(">> DominioClient - Erro no processamento ao tentar recuperar os domínios", e);
		} catch (Exception e) {
			log.error(">> DominioClient - Erro no processamento ao tentar recuperar os domínios", e);
			e.printStackTrace();
		}

		return dominioService;
	}
}
