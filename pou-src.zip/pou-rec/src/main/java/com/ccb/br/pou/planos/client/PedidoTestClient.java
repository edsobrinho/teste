package com.ccb.br.pou.planos.client;

import java.net.URL;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.namespace.QName;
import javax.xml.ws.BindingProvider;

import com.google.gson.Gson;

import br.org.febraban.acordosplanoseconomicos.AcordoPlanoEconomicosServiceLocator;
import br.org.febraban.acordosplanoseconomicos.IPedidoService;
import br.org.febraban.acordosplanoseconomicos.Pedido;
import br.org.febraban.acordosplanoseconomicos.PedidoFiltro;
import br.org.febraban.acordosplanoseconomicos.RespostaObterPedido;



public class PedidoTestClient{
  private static final String WS_URL = "https://ws320.pagamentodapoupanca.com.br/AcordoPlanosEconomicos.Integracao.Service.Ws.AcordoPlanoEconomicosService.svc/pedido";
  
  public PedidoTestClient() {}
  
  public static void main(String[] args)
    throws Exception
  {
    URL url = new URL("https://ws320.pagamentodapoupanca.com.br/AcordoPlanosEconomicos.Integracao.Service.Ws.AcordoPlanoEconomicosService.svc/pedido");
    QName qname = new QName("http://acordosplanoseconomicos.febraban.org.br", "AcordoPlanoEconomicosService");
    

    AcordoPlanoEconomicosServiceLocator serviceLocatorPlanos = new AcordoPlanoEconomicosServiceLocator();
    
    IPedidoService dominioService = serviceLocatorPlanos.getPedido(url);
    




    BindingProvider provider = (BindingProvider)serviceLocatorPlanos;
    Map<String, Object> req_ctx = provider.getRequestContext();
    req_ctx.put("javax.xml.ws.service.endpoint.address", "https://ws320.pagamentodapoupanca.com.br/AcordoPlanosEconomicos.Integracao.Service.Ws.AcordoPlanoEconomicosService.svc/pedido");
    
    Map<String, List<String>> headers = new HashMap();
    headers.put("Username", Collections.singletonList("EXY_FBB_320_WS"));
    headers.put("Password", Collections.singletonList("Fich31lcesWe=oy4"));
    req_ctx.put("javax.xml.ws.http.request.headers", headers);
    
    dominioService = serviceLocatorPlanos.getPedido(new URL("https://ws320.pagamentodapoupanca.com.br/AcordoPlanosEconomicos.Integracao.Service.Ws.AcordoPlanoEconomicosService.svc/pedido"));
    
    PedidoFiltro solicitacao = new PedidoFiltro();
    dominioService.obterPedido(solicitacao);
    

    RespostaObterPedido pedidos = null;
    pedidos = dominioService.obterPedido(solicitacao);
    
    Gson gson = null;
    for (Pedido pedido : pedidos.getPedidos()) {
      gson = new Gson();
      String pedidoJson = gson.toJson(pedido);
      System.out.println("key: " + pedido.getGuidPedido());
      System.out.println("value: " + pedidoJson);
    }
    System.out.println(pedidos.getQuantidadeTotalPedidos());
  }
}