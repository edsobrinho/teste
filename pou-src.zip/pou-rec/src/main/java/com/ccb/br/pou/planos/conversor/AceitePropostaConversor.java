/**
 * @author opah
 *
 */
package com.ccb.br.pou.planos.conversor;

import com.ccb.br.pou.planos.to.AceitePropostaTO;
import com.ccb.br.pou.planos.util.Util;

import br.org.febraban.acordosplanoseconomicos.AceiteProposta;

public class AceitePropostaConversor implements IConversor<AceitePropostaTO, AceiteProposta> {
	
	public AceitePropostaConversor() {
	}

	public AceitePropostaTO converteDoRemoto(AceiteProposta remoto) {
		AceitePropostaTO local = null;

		if (remoto != null) {
			local = new AceitePropostaTO();
			local.setGuidPedido(remoto.getGuidPedido());
			local.setIdProposta(remoto.getIdentificadorProposta());
			local.setIdPropostaBanco(remoto.getIdentificadorPropostaBanco());
			local.setData(Util.formatStringToDate(remoto.getData(), "yyyyy-mm-dd hh:mm:ss"));
			local.setAceite(com.ccb.br.pou.planos.enums.AceitePropostaEnum.getInstance(remoto.getAceite().getValue()));
			if ((remoto.getMotivoRecusa() != null) && (!remoto.getMotivoRecusa().equals(""))) {
				local.setMotivoRecusa(remoto.getMotivoRecusa());
			}
		}

		return local;
	}

	public AceiteProposta converteParaRemoto(AceitePropostaTO local) {
		throw new UnsupportedOperationException();
	}
}
