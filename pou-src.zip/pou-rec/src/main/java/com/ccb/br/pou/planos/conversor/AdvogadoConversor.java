/**
 * 
 */
package com.ccb.br.pou.planos.conversor;

import com.ccb.br.pou.planos.to.AdvogadoTO;

import br.org.febraban.acordosplanoseconomicos.Advogado;

public class AdvogadoConversor implements IConversor<AdvogadoTO, Advogado> {
	public AdvogadoConversor() {
	}

	public AdvogadoTO converteDoRemoto(Advogado remoto) {
		AdvogadoTO local = null;

		if (remoto != null) {
			local = new AdvogadoTO();
			local.setId(Integer.valueOf(remoto.getId()));
			local.setCpf(remoto.getCPF());
			local.setNome(remoto.getNome());
			if (remoto.getOAB() != null) {
				local.setOab(new IdentidadePatronoConversor().converteDoRemoto(remoto.getOAB()));
			}
			if (remoto.getOABSuplementar() != null) {
				local.setOabSuplementar(new IdentidadePatronoConversor().converteDoRemoto(remoto.getOABSuplementar()));
			}
			if (remoto.getMatriculaDefensor() != null) {
				local.setMatriculaDefensor(
						new IdentidadePatronoConversor().converteDoRemoto(remoto.getMatriculaDefensor()));
			}
			if (remoto.getContato() != null) {
				local.setContato(new ContatoConversor().converteDoRemoto(remoto.getContato()));
			}
			if (remoto.getQualificacaoPatrono() != null) {
				local.setQualificacaoPatrono(com.ccb.br.pou.planos.enums.QualificacaoPatronoEnum
						.getInstance(remoto.getQualificacaoPatrono().getValue()));
			}
		}
		return local;
	}

	public Advogado converteParaRemoto(AdvogadoTO local) {
		throw new UnsupportedOperationException();
	}
}