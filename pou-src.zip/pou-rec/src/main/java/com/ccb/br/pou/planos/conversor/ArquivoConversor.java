/**
 * 
 */
package com.ccb.br.pou.planos.conversor;

import com.ccb.br.pou.planos.to.ArquivoTO;

import br.org.febraban.acordosplanoseconomicos.Arquivo;

/**
 * @author opah
 *
 */
public class ArquivoConversor implements IConversor<ArquivoTO, Arquivo> {
	public ArquivoConversor() {
	}

	public ArquivoTO converteDoRemoto(Arquivo remoto) {
		ArquivoTO local = null;

		if (remoto != null) {
			local = new ArquivoTO();
			local.setId(Integer.valueOf(remoto.getIdentificadorDocumento()));
			local.setGuidPedido(remoto.getGuidPedido());
			local.setNomeArquivo(remoto.getNomeArquivo());
			local.setConteudo(remoto.getConteudo());
		}
		return local;
	}

	public Arquivo converteParaRemoto(ArquivoTO local) {
		throw new UnsupportedOperationException();
	}
}
