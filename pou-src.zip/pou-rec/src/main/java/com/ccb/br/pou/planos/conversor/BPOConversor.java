/**
 * 
 */
package com.ccb.br.pou.planos.conversor;

import com.ccb.br.pou.planos.to.BPOTO;
import com.ccb.br.pou.planos.util.Util;

import br.org.febraban.acordosplanoseconomicos.BPO;

/**
 * @author opah
 *
 */
public class BPOConversor implements IConversor<BPOTO, BPO> {
	public BPOConversor() {
	}

	public BPOTO converteDoRemoto(BPO remoto) {
		BPOTO local = null;

		if (remoto != null) {
			local = new BPOTO();
			local.setSequencial(Integer.valueOf(remoto.getSequencialAnaliseBPO()));
			local.setIdAnaliseBPO(Integer.valueOf(remoto.getIdentificadorAnaliseBPO()));
			local.setGuidPedido(remoto.getGUIDPedido());
			if (remoto.getDataSubmissaoBPO() != null) {
				local.setDataSubmissaoBPO(Util.formatStringToDate(remoto.getDataSubmissaoBPO(), "yyyyy-mm-dd hh:mm:ss"));
			}
			if (remoto.getDataLiberacaoBPO() != null) {
				local.setDataLiberacaoBPO(Util.formatStringToDate(remoto.getDataLiberacaoBPO(), "yyyyy-mm-dd hh:mm:ss"));
			}
		}

		return local;
	}

	public BPO converteParaRemoto(BPOTO local) {
		throw new UnsupportedOperationException();
	}
}
