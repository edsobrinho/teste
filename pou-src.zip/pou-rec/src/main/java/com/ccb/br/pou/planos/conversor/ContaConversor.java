/**
 * 
 */
package com.ccb.br.pou.planos.conversor;

import com.ccb.br.pou.planos.to.ContaTO;

import br.org.febraban.acordosplanoseconomicos.Conta;

public class ContaConversor implements IConversor<ContaTO, Conta> {
	public ContaConversor() {
	}

	public ContaTO converteDoRemoto(Conta remoto) {
		ContaTO local = null;

		if (remoto != null) {
			local = new ContaTO();

			local.setNomeTitular(remoto.getNomeTitular());
			local.setCpfCnpj(remoto.getCpfCnpj());
			local.setBanco(Integer.valueOf(remoto.getBanco()));
			local.setNomeBanco(remoto.getNomeBanco());
			local.setAgencia(remoto.getAgencia());
			local.setAgenciaDV(remoto.getAgenciaDV());
			local.setNumeroConta(remoto.getNumeroConta());
			local.setNumeroContaDV(remoto.getNumeroContaDV());
			local.setTipoConta(com.ccb.br.pou.planos.enums.TipoContaEnum.getInstance(remoto.getTipoConta().getValue()));
		}

		return local;
	}

	public Conta converteParaRemoto(ContaTO local) {
		throw new UnsupportedOperationException();
	}
}
