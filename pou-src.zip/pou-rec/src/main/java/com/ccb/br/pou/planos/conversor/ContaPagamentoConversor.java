/**
 * 
 */
package com.ccb.br.pou.planos.conversor;

import com.ccb.br.pou.planos.to.ContaPagamentoTO;

import br.org.febraban.acordosplanoseconomicos.ContaPagamento;

/**
 * @author opah
 *
 */
public class ContaPagamentoConversor implements IConversor<ContaPagamentoTO, ContaPagamento> {
	
	public ContaPagamentoConversor() {
	}

	public ContaPagamentoTO converteDoRemoto(ContaPagamento remoto) {
		ContaPagamentoTO local = null;

		if (remoto != null) {
			local = new ContaPagamentoTO();
			if (remoto.getContaBancaria() != null) {
				local.setContaBancaria(new ContaConversor().converteDoRemoto(remoto.getContaBancaria()));
			}
			if (remoto.getContaJudicial() != null) {
				local.setContaJudicial(new DepositoJudicialConversor().converteDoRemoto(remoto.getContaJudicial()));
			}
		}

		return local;
	}

	public ContaPagamento converteParaRemoto(ContaPagamentoTO local) {
		throw new UnsupportedOperationException();
	}
}
