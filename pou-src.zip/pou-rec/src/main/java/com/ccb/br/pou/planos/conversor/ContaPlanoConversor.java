/**
 * 
 */
package com.ccb.br.pou.planos.conversor;


import com.ccb.br.pou.planos.to.ContaPlanoTO;

import br.com.bicbanco.bicbase.types.Money;
import br.org.febraban.acordosplanoseconomicos.ContaPlano;
import br.org.febraban.acordosplanoseconomicos.Habilitacao;


/**
 * @author opah
 *
 */
public class ContaPlanoConversor implements IConversor<ContaPlanoTO, ContaPlano> {
	public ContaPlanoConversor() {
	}

	public ContaPlanoTO converteDoRemoto(ContaPlano remoto) {
		ContaPlanoTO local = null;

		if (remoto != null) {
			local = new ContaPlanoTO();
			local.setId(remoto.getId());
			local.setPlano(com.ccb.br.pou.planos.enums.PlanoEnum.getInstance(remoto.getPlano().getValue()));
			local.setSaldoBase(new Money(remoto.getSaldoBase().doubleValue()));
			local.setValorSimulado(new Money(remoto.getValorSimulado().doubleValue()));
			local.setDiaAniversarioConta(Integer.valueOf(new Double(remoto.getDiaAniversarioConta()).intValue()));
			if ((remoto.getPedidoEmOutrasHabilitacoes() != null)
					&& (remoto.getPedidoEmOutrasHabilitacoes().length > 0)) {
				for (Habilitacao habilitacao : remoto.getPedidoEmOutrasHabilitacoes()) {
					local.getPedidoEmOutrasHabilitacoes().add(new HabilitacaoConversor().converteDoRemoto(habilitacao));
				}
			}
		}

		return local;
	}

	public ContaPlano converteParaRemoto(ContaPlanoTO local) {
		throw new UnsupportedOperationException();
	}
}
