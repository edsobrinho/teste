package com.ccb.br.pou.planos.conversor;

import com.ccb.br.pou.planos.to.ContatoTO;

import br.org.febraban.acordosplanoseconomicos.Contato;

public class ContatoConversor implements IConversor<ContatoTO, Contato> {
	public ContatoConversor() {
	}

	public ContatoTO converteDoRemoto(Contato remoto) {
		ContatoTO local = null;

		if (remoto != null) {
			local = new ContatoTO();

			local.setEmail(remoto.getEmail());
			local.setCelular(new TelefoneConversor().converteDoRemoto(remoto.getCelular()));
			local.setTelefoneFixo(new TelefoneConversor().converteDoRemoto(remoto.getTelefoneFixo()));
		}

		return local;
	}

	public Contato converteParaRemoto(ContatoTO local) {
		throw new UnsupportedOperationException();
	}
}