package com.ccb.br.pou.planos.conversor;

import com.ccb.br.pou.planos.to.DepositoJudicialTO;
import com.ccb.br.pou.planos.util.Util;

import br.org.febraban.acordosplanoseconomicos.DepositoJudicial;

public class DepositoJudicialConversor implements IConversor<DepositoJudicialTO, DepositoJudicial> {
	public DepositoJudicialConversor() {
	}

	public DepositoJudicialTO converteDoRemoto(DepositoJudicial remoto) {
		DepositoJudicialTO local = null;

		if (remoto != null) {
			local = new DepositoJudicialTO();
			local.setBanco(local.getBanco());
			local.setNomeBanco(local.getNomeBanco());
			local.setIdDepositoJudicial(remoto.getIdentificadorDepositoJudicial());
			if (remoto.getDataValidade() != null) {
				local.setDataValidade(Util.formatStringToDate(remoto.getDataValidade(), "yyyyy-mm-dd hh:mm:ss"));
			}
		}

		return local;
	}

	public DepositoJudicial converteParaRemoto(DepositoJudicialTO local) {
		throw new UnsupportedOperationException();
	}
}