package com.ccb.br.pou.planos.conversor;

import com.ccb.br.pou.planos.to.DocumentoTO;

import br.org.febraban.acordosplanoseconomicos.Documento;

public class DocumentoConversor implements IConversor<DocumentoTO, Documento> {
	public DocumentoConversor() {
	}

	public DocumentoTO converteDoRemoto(Documento remoto) {
		DocumentoTO local = null;

		if (remoto != null) {
			local = new DocumentoTO();
			local.setNomeDocumento(remoto.getNomeDocumento());
			local.setTipoDocumento(com.ccb.br.pou.planos.enums.TipoDocumentoEnum.getInstance(remoto.getTipoDocumento().getValue()));
			local.setContexto(com.ccb.br.pou.planos.enums.ContextoEnum.getInstance(remoto.getContexto().getValue()));
		}

		return local;
	}

	public Documento converteParaRemoto(DocumentoTO local) {
		throw new UnsupportedOperationException();
	}
}