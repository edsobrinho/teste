package com.ccb.br.pou.planos.conversor;

import com.ccb.br.pou.planos.to.DominioTO;

import br.org.febraban.acordosplanoseconomicos.Dominio;
import br.org.febraban.acordosplanoseconomicos.DominioItem;

public class DominioConversor implements IConversor<DominioTO, Dominio> {
	public DominioConversor() {
	}

	public DominioTO converteDoRemoto(Dominio remoto) {
		DominioTO local = null;

		if (remoto != null) {
			local = new DominioTO();
			local.setId(Integer.valueOf(remoto.getId()));
			local.setNome(remoto.getNome());
			if ((remoto.getItens() != null) && (remoto.getItens().length > 0)) {
				for (DominioItem dominioItem : remoto.getItens()) {
					local.getItens().add(new DominioItemConversor().converteDoRemoto(dominioItem));
				}
			}
		}

		return local;
	}

	public Dominio converteParaRemoto(DominioTO local) {
		throw new UnsupportedOperationException();
	}
}