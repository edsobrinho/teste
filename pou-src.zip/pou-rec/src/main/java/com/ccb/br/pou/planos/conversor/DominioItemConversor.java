package com.ccb.br.pou.planos.conversor;

import com.ccb.br.pou.planos.to.DominioItemTO;

import br.org.febraban.acordosplanoseconomicos.DominioItem;

public class DominioItemConversor implements IConversor<DominioItemTO, DominioItem> {
	public DominioItemConversor() {
	}

	public DominioItemTO converteDoRemoto(DominioItem remoto) {
		DominioItemTO local = null;

		if (remoto != null) {
			local = new DominioItemTO();
			local.setId(Integer.valueOf(remoto.getId()));
			local.setDescricao(remoto.getDescricao());
			local.setAtivo(Boolean.valueOf(remoto.isAtivo()));
		}

		return local;
	}

	public DominioItem converteParaRemoto(DominioItemTO local) {
		throw new UnsupportedOperationException();
	}
}