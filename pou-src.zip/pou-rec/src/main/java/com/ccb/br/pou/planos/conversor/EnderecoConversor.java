package com.ccb.br.pou.planos.conversor;

import com.ccb.br.pou.planos.to.EnderecoTO;

import br.org.febraban.acordosplanoseconomicos.Endereco;

public class EnderecoConversor implements IConversor<EnderecoTO, Endereco> {
	public EnderecoConversor() {
	}

	public EnderecoTO converteDoRemoto(Endereco remoto) {
		EnderecoTO local = null;

		if (remoto != null) {
			local = new EnderecoTO();
			local.setCEP(remoto.getCEP());
			local.setUF(remoto.getUF());
			local.setCidade(remoto.getCidade());
			local.setBairro(remoto.getBairro());
			local.setTipoLogradouro(remoto.getTipoLogradouro());
			local.setLogradouro(remoto.getLogradouro());
			local.setComplemento(remoto.getComplemento());
			local.setNumero(remoto.getNumero());
		}

		return local;
	}

	public Endereco converteParaRemoto(EnderecoTO local) {
		throw new UnsupportedOperationException();
	}
}