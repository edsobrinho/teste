package com.ccb.br.pou.planos.conversor;

import com.ccb.br.pou.planos.to.HabilitacaoTO;

import br.org.febraban.acordosplanoseconomicos.Habilitacao;

public class HabilitacaoConversor implements IConversor<HabilitacaoTO, Habilitacao> {
	public HabilitacaoConversor() {
	}

	public HabilitacaoTO converteDoRemoto(Habilitacao remoto) {
		HabilitacaoTO local = null;

		if (remoto != null) {
			local = new HabilitacaoTO();
			local.setProtocolo(remoto.getProtocolo());
		}

		return local;
	}

	public Habilitacao converteParaRemoto(HabilitacaoTO local) {
		throw new UnsupportedOperationException();
	}
}
