/**
 * 
 */
package com.ccb.br.pou.planos.conversor;

/**
 * @author opah
 *
 */
public interface IConversor<LOCAL, REMOTO> {
	LOCAL converteDoRemoto(REMOTO remoto);
	REMOTO converteParaRemoto(LOCAL local);
}
