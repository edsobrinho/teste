package com.ccb.br.pou.planos.conversor;

import com.ccb.br.pou.planos.to.IdentidadeTO;
import com.ccb.br.pou.planos.util.Util;

import br.org.febraban.acordosplanoseconomicos.Identidade;

public class IdentidadeConversor implements IConversor<IdentidadeTO, Identidade> {
	public IdentidadeConversor() {
	}

	public IdentidadeTO converteDoRemoto(Identidade remoto) {
		IdentidadeTO local = null;

		if (remoto != null) {
			local = new IdentidadeTO();
			local.setNumero(remoto.getNumero());
			local.setOrgao(remoto.getOrgao());
			local.setUF(remoto.getUF());
			local.setTipo(com.ccb.br.pou.planos.enums.TipoIdentidadeEnum.getInstance(remoto.getTipo().getValue()));
			if (remoto.getClassificacao() != null) {
				local.setClassificacao(remoto.getClassificacao());
			}
			if ((remoto.getValidade() != null) && (!remoto.getValidade().equals(""))) {
				local.setValidade(Util.formatStringToDate(remoto.getValidade(), "yyyyy-mm-dd hh:mm:ss"));
			}
		}

		return local;
	}

	public Identidade converteParaRemoto(IdentidadeTO local) {
		throw new UnsupportedOperationException();
	}
}