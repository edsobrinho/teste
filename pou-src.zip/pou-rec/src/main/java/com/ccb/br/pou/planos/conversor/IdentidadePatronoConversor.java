package com.ccb.br.pou.planos.conversor;

import com.ccb.br.pou.planos.to.IdentidadePatronoTO;

import br.org.febraban.acordosplanoseconomicos.IdentidadePatrono;

public class IdentidadePatronoConversor implements IConversor<IdentidadePatronoTO, IdentidadePatrono> {
	public IdentidadePatronoConversor() {
	}

	public IdentidadePatronoTO converteDoRemoto(IdentidadePatrono remoto) {
		IdentidadePatronoTO local = null;

		if (remoto != null) {
			local = new IdentidadePatronoTO();

			local.setNumero(remoto.getNumero());
			local.setUF(remoto.getUF());
			local.setEsfera(com.ccb.br.pou.planos.enums.EsferaEnum.getInstance(remoto.getEsfera().getValue()));
		}
		return local;
	}

	public IdentidadePatrono converteParaRemoto(IdentidadePatronoTO local) {
		throw new UnsupportedOperationException();
	}
}