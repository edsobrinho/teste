package com.ccb.br.pou.planos.conversor;

import com.ccb.br.pou.planos.to.PagamentoAcordoTO;
import com.ccb.br.pou.planos.util.Util;

import br.com.bicbanco.bicbase.types.Money;
import br.org.febraban.acordosplanoseconomicos.PagamentoAcordo;

public class PagamentoAcordoConversor implements IConversor<PagamentoAcordoTO, PagamentoAcordo> {
	public PagamentoAcordoConversor() {
	}

	public PagamentoAcordoTO converteDoRemoto(PagamentoAcordo remoto) {
		PagamentoAcordoTO local = null;

		if (remoto != null) {
			local = new PagamentoAcordoTO();
			local.setGuidPedido(remoto.getGuidPedido());
			local.setIdPropostaBanco(Integer.valueOf(remoto.getIdentificadorPropostaBanco()));
			local.setDataPagamento(Util.formatStringToDate(remoto.getDataPagamento(), "yyyyy-mm-dd hh:mm:ss"));
			local.setValorPagamento(new Money(remoto.getValorPagamento()));
			if (remoto.getComprovante() != null) {
				local.setComprovante(new ArquivoConversor().converteDoRemoto(remoto.getComprovante()));
			}
			local.setStatusPagamento(com.ccb.br.pou.planos.enums.StatusPagamentoEnum
					.getInstance(remoto.getStatusPagamento().getValue()));
			local.setObservacoesPagamento(remoto.getObservacoesPagamento());

			if (remoto.getContaPagamentoAcordo() != null) {
				local.setContaPagamentoAcordo(
						new ContaPagamentoConversor().converteDoRemoto(remoto.getContaPagamentoAcordo()));
			}
		}

		return local;
	}

	public PagamentoAcordo converteParaRemoto(PagamentoAcordoTO local) {
		throw new UnsupportedOperationException();
	}
}