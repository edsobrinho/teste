package com.ccb.br.pou.planos.conversor;

import com.ccb.br.pou.planos.to.ParteTO;
import com.ccb.br.pou.planos.util.Util;

import br.org.febraban.acordosplanoseconomicos.Parte;

public class ParteConversor implements IConversor<ParteTO, Parte> {
	public ParteConversor() {
	}

	public ParteTO converteDoRemoto(Parte remoto) {
		ParteTO local = null;

		if (remoto != null) {
			local = new ParteTO();
			local.setId(Integer.valueOf(remoto.getId()));
			local.setCpf(remoto.getCpf());
			local.setNome(remoto.getNome());

			if (remoto.getIdentidade() != null) {
				local.setIdentidade(new IdentidadeConversor().converteDoRemoto(remoto.getIdentidade()));
			}
			local.setDataNascimento(Util.formatStringToDate(remoto.getDataNascimento(), "yyyyy-mm-dd hh:mm:ss"));
			local.setFalecido(Boolean.valueOf(remoto.isFalecido()));
			if ((remoto.getDataObito() != null) && (!remoto.getDataObito().equals(""))) {
				local.setDataObito(Util.formatStringToDate(remoto.getDataObito(), "yyyyy-mm-dd hh:mm:ss"));
			}
			if (remoto.getEnderecoCorrespondencia() != null) {
				local.setEnderecoCorrespondencia(
						new EnderecoConversor().converteDoRemoto(remoto.getEnderecoCorrespondencia()));
			}
			if (remoto.getContato() != null) {
				local.setContato(new ContatoConversor().converteDoRemoto(remoto.getContato()));
			}

			local.setQualificacao(com.ccb.br.pou.planos.enums.QualificacaoEnvolvidoEnum
					.getInstance(remoto.getQualificacao().getValue()));
		}

		return local;
	}

	public Parte converteParaRemoto(ParteTO local) {
		throw new UnsupportedOperationException();
	}
}