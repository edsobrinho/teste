package com.ccb.br.pou.planos.conversor;

import com.ccb.br.pou.planos.to.PedidoTO;
import com.ccb.br.pou.planos.util.Util;

import br.com.bicbanco.bicbase.types.Money;
import br.org.febraban.acordosplanoseconomicos.ContaPlano;
import br.org.febraban.acordosplanoseconomicos.Documento;
import br.org.febraban.acordosplanoseconomicos.Parte;
import br.org.febraban.acordosplanoseconomicos.Pedido;

public class PedidoConversor implements IConversor<PedidoTO, Pedido> {
	public PedidoConversor() {
	}

	public PedidoTO converteDoRemoto(Pedido remoto) {
		PedidoTO local = null;

		if (remoto != null) {
			local = new PedidoTO();
			local.setGuidPedido(remoto.getGuidPedido());
			local.setProtocolo(remoto.getProtocolo());
			local.setIdLoteHabilitacao(Integer.valueOf(remoto.getIdentificadorLoteHabilitacao()));
			if (remoto.getDataAbertura() != null) {
				local.setDataAbertura(Util.formatStringToDate(remoto.getDataAbertura(), "yyyyy-mm-dd hh:mm:ss"));
			}
			local.setStatusPedido(
					com.ccb.br.pou.planos.enums.StatusPedidoEnum.getInstance(remoto.getStatusPedido().getValue()));
			local.setValorCustasProcessuais(new Money(remoto.getValorCustasProcessuais().doubleValue()));
			if (remoto.getDataConfimacaoLeituraBanco() != null) {
				local.setDataConfimacaoLeituraBanco(
						Util.formatStringToDate(remoto.getDataConfimacaoLeituraBanco(), "yyyyy-mm-dd hh:mm:ss"));
			}
			local.setValorTotalSimulado(new Money(remoto.getValorTotalSimulado()));
			local.setDestinatarioPagamentoAcordo(com.ccb.br.pou.planos.enums.DestinatarioContaEnum
					.getInstance(remoto.getDestinatarioPagamentoAcordo().getValue()));
			if (remoto.getPoupador() != null) {
				local.setPoupador(new ParteConversor().converteDoRemoto(remoto.getPoupador()));
			}
			if ((remoto.getEnvolvidosEspolio() != null) && (remoto.getEnvolvidosEspolio().length > 0)) {
				for (Parte parte : remoto.getEnvolvidosEspolio()) {
					local.getEnvolvidosEspolio().add(new ParteConversor().converteDoRemoto(parte));
				}
			}
			if (remoto.getPatrono() != null) {
				local.setPatrono(new AdvogadoConversor().converteDoRemoto(remoto.getPatrono()));
			}
			if (remoto.getContaPagamentoAcordo() != null) {
				local.setContaPagamentoAcordo(
						new ContaPagamentoConversor().converteDoRemoto(remoto.getContaPagamentoAcordo()));
			}
			if (remoto.getContaPagamentoHonorario() != null) {
				local.setContaPagamentoHonorario(
						new ContaPagamentoConversor().converteDoRemoto(remoto.getContaPagamentoHonorario()));
			}
			if (remoto.getProcesso() != null) {
				local.setProcesso(new ProcessoConversor().converteDoRemoto(remoto.getProcesso()));
			}
			if ((remoto.getContasContempladas() != null) && (remoto.getContasContempladas().length > 0)) {
				for (ContaPlano contaPlano : remoto.getContasContempladas()) {
					local.getContasContempladas().add(new ContaPlanoConversor().converteDoRemoto(contaPlano));
				}
			}
			if ((remoto.getDocumentos() != null) && (remoto.getDocumentos().length > 0)) {
				for (Documento documento : remoto.getDocumentos()) {
					local.getDocumentos().add(new DocumentoConversor().converteDoRemoto(documento));
				}
			}
			if (remoto.getResultadoBPO() != null) {
				local.setResultadoBPO(new BPOConversor().converteDoRemoto(remoto.getResultadoBPO()));
			}
		}

		return local;
	}

	public Pedido converteParaRemoto(PedidoTO local) {
		throw new UnsupportedOperationException();
	}
}