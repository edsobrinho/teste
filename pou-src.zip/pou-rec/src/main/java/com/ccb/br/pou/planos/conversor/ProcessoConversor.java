package com.ccb.br.pou.planos.conversor;

import com.ccb.br.pou.planos.to.ProcessoTO;
import com.ccb.br.pou.planos.util.Util;

import br.org.febraban.acordosplanoseconomicos.Processo;

public class ProcessoConversor implements IConversor<ProcessoTO, Processo> {
	public ProcessoConversor() {
	}

	public ProcessoTO converteDoRemoto(Processo remoto) {
		ProcessoTO local = null;

		if (remoto != null) {
			local = new ProcessoTO();
			local.setId(Integer.valueOf(remoto.getId()));
			local.setNumeroProcessoCNJ(remoto.getNumeroProcessoCNJ());

			if (remoto.getNumeroProcessoAntigo() != null) {
				local.setNumeroProcessoAntigo(remoto.getNumeroProcessoAntigo());
			}
			if (remoto.getIdentificadorProcessoSistemaLegado() != null) {
				local.setIdentificadorProcessoSistemaLegado(remoto.getIdentificadorProcessoSistemaLegado());
			}
			local.setOrgaoLegal(com.ccb.br.pou.planos.enums.TipoProcessoEnum.getInstance(remoto.getOrgaoLegal().getValue()));
			local.setTipoAcao(com.ccb.br.pou.planos.enums.TipoAcaoEnum.getInstance(remoto.getTipoAcao().getValue()));
			local.setVaraDeOrigem(remoto.getVaraDeOrigem());
			local.setComarcaDeOrigem(remoto.getComarcaDeOrigem());
			local.setUF(remoto.getUF());

			if (remoto.getAjuizadoEm() != null) {
				local.setAjuizadoEm(Util.formatStringToDate(remoto.getAjuizadoEm(), "yyyyy-mm-dd hh:mm:ss"));
			}
			if (remoto.getDataProcuracao() != null) {
				local.setDataProcuracao(Util.formatStringToDate(remoto.getDataProcuracao(), "yyyyy-mm-dd hh:mm:ss"));
			}
			local.setInstituicaoNome(remoto.getInstituicaoNome());
		}

		return local;
	}

	public Processo converteParaRemoto(ProcessoTO local) {
		throw new UnsupportedOperationException();
	}
}