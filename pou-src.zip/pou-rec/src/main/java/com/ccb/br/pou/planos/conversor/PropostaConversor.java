package com.ccb.br.pou.planos.conversor;

import com.ccb.br.pou.planos.to.PropostaTO;

import br.com.bicbanco.bicbase.types.Money;
import br.org.febraban.acordosplanoseconomicos.Proposta;

public class PropostaConversor implements IConversor<PropostaTO, Proposta> {
	public PropostaConversor() {
	}

	public PropostaTO converteDoRemoto(Proposta remoto) {
		PropostaTO local = null;

		if (remoto != null) {
			local = new PropostaTO();

			local.setIdPropostaBanco(remoto.getIdentificadorPropostaBanco());
			local.setValorTotalAcordo(new Money(remoto.getValorTotalAcordo()));
			local.setValorPoupador(new Money(remoto.getValorPoupador()));
			local.setValorHonorariosAdvogado(new Money(remoto.getValorPoupador()));
			local.setValorHonorariosFebrapo(new Money(remoto.getValorHonorariosFebrapo()));
			local.setValorReembolsoCustas(new Money(remoto.getValorReembolsoCustas()));
			local.setQuantidadeParcelas(Integer.valueOf(remoto.getQuantidadeParcelas()));
			local.setValorParcela(new Money(remoto.getValorParcela()));
			local.setObservacoes(remoto.getObservacoes());
			if (remoto.getDemonstrativoCalculo() != null) {
				local.setDemonstrativoCalculo(new ArquivoConversor().converteDoRemoto(remoto.getDemonstrativoCalculo()));
			}
		}

		return local;
	}

	public Proposta converteParaRemoto(PropostaTO local) {
		throw new UnsupportedOperationException();
	}
}