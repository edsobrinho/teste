package com.ccb.br.pou.planos.conversor;

import com.ccb.br.pou.planos.enums.MotivoNcEnum;
import com.ccb.br.pou.planos.to.ResultadoAnaliseBPOTO;

import br.org.febraban.acordosplanoseconomicos.MotivoNCEnum;
import br.org.febraban.acordosplanoseconomicos.ResultadoAnaliseBPO;

public class ResultadoAnaliseBPOConversor implements IConversor<ResultadoAnaliseBPOTO, ResultadoAnaliseBPO> {
	public ResultadoAnaliseBPOConversor() {
	}

	public ResultadoAnaliseBPOTO converteDoRemoto(ResultadoAnaliseBPO remoto) {
		ResultadoAnaliseBPOTO local = null;

		if (remoto != null) {
			local = new ResultadoAnaliseBPOTO();
			local.setIdItem(Integer.valueOf(remoto.getIdentificadorItem()));
			local.setDescricaoItem(remoto.getDescricaoItem());
			local.setContexto(com.ccb.br.pou.planos.enums.ContextoEnum.getInstance(remoto.getContexto().getValue()));
			local.setIdChaveContexto(Integer.valueOf(remoto.getIdChaveContexto()));
			local.setResultado(com.ccb.br.pou.planos.enums.ResultadoAnaliseBPOEnum.getInstance(remoto.getResultado().getValue()));
			if (remoto.getTipoDocumento() != null) {
				local.setTipoDocumento(com.ccb.br.pou.planos.enums.TipoDocumentoEnum.getInstance(remoto.getTipoDocumento().getValue()));
			}
			if (remoto.getMotivoNC() != null) {
				for (MotivoNCEnum motivoNC : remoto.getMotivoNC()) {
					local.getMotivosNC().add(MotivoNcEnum.getInstance(motivoNC.getValue()));
				}
			}
		}

		return local;
	}

	public ResultadoAnaliseBPO converteParaRemoto(ResultadoAnaliseBPOTO local) {
		throw new UnsupportedOperationException();
	}
}