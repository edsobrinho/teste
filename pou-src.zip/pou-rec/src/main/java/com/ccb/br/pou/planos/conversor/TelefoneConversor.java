package com.ccb.br.pou.planos.conversor;

import com.ccb.br.pou.planos.to.TelefoneTO;

import br.org.febraban.acordosplanoseconomicos.Telefone;

public class TelefoneConversor implements IConversor<TelefoneTO, Telefone> {
	public TelefoneConversor() {
	}

	public TelefoneTO converteDoRemoto(Telefone remoto) {
		TelefoneTO local = null;
		if (remoto != null) {
			local = new TelefoneTO();
			local.setDDD(remoto.getDDD());
			local.setNumero(remoto.getNumero());
		}

		return local;
	}

	public Telefone converteParaRemoto(TelefoneTO local) {
		throw new UnsupportedOperationException();
	}
}