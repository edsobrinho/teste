package com.ccb.br.pou.planos.enums;

public enum AceitePropostaEnum {
	
	ACEITO(Integer.valueOf(1), "ACEITO"), 
	RECUSADO(Integer.valueOf(2), "RECUSADO");

	private Integer codigo;
	private String descricao;

	private AceitePropostaEnum(Integer codigo, String descricao) {
		this.codigo = codigo;
		this.descricao = descricao;
	}

	public static AceitePropostaEnum getInstance(Integer codigo) {
		if (codigo == null) {
			return null;
		}

		for (AceitePropostaEnum aceiteProposta : values()) {
			if (aceiteProposta.getCodigo().equals(codigo)) {
				return aceiteProposta;
			}
		}

		return null;
	}

	public static AceitePropostaEnum getInstance(String descricao) {
		if (descricao == null) {
			return null;
		}

		for (AceitePropostaEnum aceiteProposta : values()) {
			if (aceiteProposta.getDescricao().equals(descricao)) {
				return aceiteProposta;
			}
		}

		return null;
	}

	public Integer getCodigo() {
		return codigo;
	}

	public void setCodigo(Integer codigo) {
		this.codigo = codigo;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
}