package com.ccb.br.pou.planos.enums;

public enum ContextoEnum {
	
	POUPADOR(Integer.valueOf(1), "POUPADOR"), 
	INVENTARIANTE(Integer.valueOf(2), "INVENTARIANTE"), 
	ADVOGADO(Integer.valueOf(3), "ADVOGADO"), 
	PROCESSO(Integer.valueOf(4), "PROCESSO"), 
	CONTA_PLANO(Integer.valueOf(5),"CONTA_PLANO"), 
	PAGAMENTO(Integer.valueOf(6), "PAGAMENTO"), 
	RESUMO(Integer.valueOf(7),"RESUMO"), 
	TERMO(Integer.valueOf(8), "TERMO"), 
	ADESAO(Integer.valueOf(9),"ADESAO"), 
	OUTROS_DOCUMENTOS(Integer.valueOf(10), "OUTROS_DOCUMENTOS"), 
	PROPOSTA(Integer.valueOf(11), "PROPOSTA"), 
	SUCESSOR(Integer.valueOf(12), "SUCESSOR");

	private Integer codigo;
	private String descricao;

	private ContextoEnum(Integer codigo, String descricao) {
		this.codigo = codigo;
		this.descricao = descricao;
	}

	public static ContextoEnum getInstance(Integer codigo) {
		if (codigo == null) {
			return null;
		}

		for (ContextoEnum contexto : values()) {
			if (contexto.getCodigo().equals(codigo)) {
				return contexto;
			}
		}

		return null;
	}

	public static ContextoEnum getInstance(String descricao) {
		if (descricao == null) {
			return null;
		}

		for (ContextoEnum contexto : values()) {
			if (contexto.getDescricao().equals(descricao)) {
				return contexto;
			}
		}

		return null;
	}

	public Integer getCodigo() {
		return codigo;
	}

	public void setCodigo(Integer codigo) {
		this.codigo = codigo;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
}