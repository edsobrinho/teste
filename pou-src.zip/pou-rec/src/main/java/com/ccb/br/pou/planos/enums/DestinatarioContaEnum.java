package com.ccb.br.pou.planos.enums;

public enum DestinatarioContaEnum {
	
	CONTA_POUPADOR(Integer.valueOf(1), "CONTA_POUPADOR"), 
	CONTA_ADVOGADO(Integer.valueOf(2),"CONTA_ADVOGADO"), 
	DEPOSITO_JUDICIAL(Integer.valueOf(3),"DEPOSITO_JUDICIAL"), 
	BOLETO(Integer.valueOf(4), "BOLETO");

	private Integer codigo;
	private String descricao;

	private DestinatarioContaEnum(Integer codigo, String descricao) {
		this.codigo = codigo;
		this.descricao = descricao;
	}

	public static DestinatarioContaEnum getInstance(Integer codigo) {
		if (codigo == null) {
			return null;
		}

		for (DestinatarioContaEnum destinatarioConta : values()) {
			if (destinatarioConta.getCodigo().equals(codigo)) {
				return destinatarioConta;
			}
		}
		return null;
	}

	public static DestinatarioContaEnum getInstance(String descricao) {
		if (descricao == null) {
			return null;
		}

		for (DestinatarioContaEnum destinatarioConta : values()) {
			if (destinatarioConta.getDescricao().equals(descricao)) {
				return destinatarioConta;
			}
		}
		return null;
	}

	public Integer getCodigo() {
		return codigo;
	}

	public void setCodigo(Integer codigo) {
		this.codigo = codigo;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
}