package com.ccb.br.pou.planos.enums;

public enum EsferaEnum {
	
	ESTADUAL(Integer.valueOf(1), "ESTADUAL"), 
	FEDERAL(Integer.valueOf(2), "FEDERAL");

	private Integer codigo;
	private String descricao;

	private EsferaEnum(Integer codigo, String descricao) {
		this.codigo = codigo;
		this.descricao = descricao;
	}

	public static EsferaEnum getInstance(Integer codigo) {
		if (codigo == null) {
			return null;
		}

		for (EsferaEnum esfera : values()) {
			if (esfera.getCodigo().equals(codigo)) {
				return esfera;
			}
		}

		return null;
	}

	public static EsferaEnum getInstance(String descricao) {
		if (descricao == null) {
			return null;
		}

		for (EsferaEnum esfera : values()) {
			if (esfera.getDescricao().equals(descricao)) {
				return esfera;
			}
		}

		return null;
	}

	public Integer getCodigo() {
		return codigo;
	}

	public void setCodigo(Integer codigo) {
		this.codigo = codigo;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
}