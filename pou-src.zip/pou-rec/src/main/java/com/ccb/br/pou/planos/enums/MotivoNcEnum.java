package com.ccb.br.pou.planos.enums;

public enum MotivoNcEnum {
	
	HABILITACAO_DUPLICADA_PARA_MESMO_CPF_PROCESSO(Integer.valueOf(1), "HABILITACAO_DUPLICADA_PARA_MESMO_CPF_PROCESSO"), 
	HABILITACAO_DUPLICADA_PEDIDO_PLEITEADO_PELO_MESMO_CPF_EM_PROCESSO_DIFERENTE(Integer.valueOf(2), "HABILITACAO_DUPLICADA_PEDIDO_PLEITEADO_PELO_MESMO_CPF_EM_PROCESSO_DIFERENTE"), 
	HABILITACAO_DUPLICADA_PEDIDO_PLEITEADO_CPF_DISTINTO_EM_PROCESSO_DIFERENTE(Integer.valueOf(3), "HABILITACAO_DUPLICADA_PEDIDO_PLEITEADO_CPF_DISTINTO_EM_PROCESSO_DIFERENTE"), 
	PROCESSO_NAO_LOCALIZADO_NO_JUDICIARIO(Integer.valueOf(4), "PROCESSO_NAO_LOCALIZADO_NO_JUDICIARIO"), 
	INFORMACAO_DIVERGENTE(Integer.valueOf(5), "INFORMACAO_DIVERGENTE"), 
	INFORMACAO_NAO_LEGIVEL(Integer.valueOf(6), "INFORMACAO_NAO_LEGIVEL"), 
	INFORMACAO_NAO_DISPONIVEL(Integer.valueOf(7), "INFORMACAO_NAO_DISPONIVEL");
  
	private Integer codigo;
	private String descricao;
  
	private MotivoNcEnum(Integer codigo, String descricao) {
		this.codigo = codigo;
		this.descricao = descricao;
	}

	public static MotivoNcEnum getInstance(Integer codigo) {
		if (codigo == null) {
			return null;
		}

		for (MotivoNcEnum tipoDocumento : values()) {
			if (tipoDocumento.getCodigo().equals(codigo)) {
				return tipoDocumento;
			}
		}

		return null;
	}

	public static MotivoNcEnum getInstance(String descricao) {
		if (descricao == null) {
			return null;
		}

		for (MotivoNcEnum tipoDocumento : values()) {
			if (tipoDocumento.getDescricao().equals(descricao)) {
				return tipoDocumento;
			}
		}

		return null;
	}

	public Integer getCodigo() {
		return codigo;
	}

	public void setCodigo(Integer codigo) {
		this.codigo = codigo;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
}