package com.ccb.br.pou.planos.enums;

public enum MotivoRecusaPedidoEnum {
	
	PROCESSO_NAO_ELEGIVEL(Integer.valueOf(1), "PROCESSO_NAO_ELEGIVEL"), 
	CONTA_NAO_ELEGIVEL(Integer.valueOf(2), "CONTA_NAO_ELEGIVEL"), 
	BANCO_NAO_ELEGIVEL(Integer.valueOf(3), "BANCO_NAO_ELEGIVEL"), 
	AUSENCIA_DOCUMENTO_OBRIGATORIO(Integer.valueOf(4), "AUSENCIA_DOCUMENTO_OBRIGATORIO");
  
	private Integer codigo;
	private String descricao;

	private MotivoRecusaPedidoEnum(Integer codigo, String descricao) {
		this.codigo = codigo;
		this.descricao = descricao;
	}

	public static MotivoRecusaPedidoEnum getInstance(Integer codigo) {
		if (codigo == null) {
			return null;
		}

		for (MotivoRecusaPedidoEnum tipoIdentidade : values()) {
			if (tipoIdentidade.getCodigo().equals(codigo)) {
				return tipoIdentidade;
			}
		}
		return null;
	}

	public static MotivoRecusaPedidoEnum getInstance(String descricao) {
		if (descricao == null) {
			return null;
		}

		for (MotivoRecusaPedidoEnum tipoIdentidade : values()) {
			if (tipoIdentidade.getDescricao().equals(descricao)) {
				return tipoIdentidade;
			}
		}
		return null;
	}

	public Integer getCodigo() {
		return codigo;
	}

	public void setCodigo(Integer codigo) {
		this.codigo = codigo;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
}