package com.ccb.br.pou.planos.enums;

public enum PlanoEnum {
	
	BRESSER(Integer.valueOf(1), "BRESSER"), 
	COLLOR_I(Integer.valueOf(2), "COLLOR_I"), 
	COLLOR_II(Integer.valueOf(3), "COLLOR_II"), 
	VERAO(Integer.valueOf(4), "VERAO");
  
	private Integer codigo;
	private String descricao;

	private PlanoEnum(Integer codigo, String descricao) {
		this.codigo = codigo;
		this.descricao = descricao;
	}

	public static PlanoEnum getInstance(Integer codigo) {
		if (codigo == null) {
			return null;
		}

		for (PlanoEnum plano : values()) {
			if (plano.getCodigo().equals(codigo)) {
				return plano;
			}
		}

		return null;
	}

	public static PlanoEnum getInstance(String descricao) {
		if (descricao == null) {
			return null;
		}

		for (PlanoEnum plano : values()) {
			if (plano.getDescricao().equals(descricao)) {
				return plano;
			}
		}

		return null;
	}

	public Integer getCodigo() {
		return codigo;
	}

	public void setCodigo(Integer codigo) {
		this.codigo = codigo;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
}