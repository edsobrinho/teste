package com.ccb.br.pou.planos.enums;

public enum QualificacaoEnvolvidoEnum {
	
	POUPADOR(Integer.valueOf(1), "POUPADOR"), 
	INVENTARIANTE(Integer.valueOf(2), "INVENTARIANTE"), 
	SUCESSOR_PRINCIPAL(Integer.valueOf(3), "SUCESSOR_PRINCIPAL"), 
	SUCESSOR(Integer.valueOf(4), "SUCESSOR");

	private Integer codigo;
	private String descricao;

	private QualificacaoEnvolvidoEnum(Integer codigo, String descricao) {
		this.codigo = codigo;
		this.descricao = descricao;
	}

	public static QualificacaoEnvolvidoEnum getInstance(Integer codigo) {
		if (codigo == null) {
			return null;
		}

		for (QualificacaoEnvolvidoEnum tipoIdentidade : values()) {
			if (tipoIdentidade.getCodigo().equals(codigo)) {
				return tipoIdentidade;
			}
		}
		return null;
	}

	public static QualificacaoEnvolvidoEnum getInstance(String descricao) {
		if (descricao == null) {
			return null;
		}

		for (QualificacaoEnvolvidoEnum tipoIdentidade : values()) {
			if (tipoIdentidade.getDescricao().equals(descricao)) {
				return tipoIdentidade;
			}
		}
		return null;
	}

	public Integer getCodigo() {
		return codigo;
	}

	public void setCodigo(Integer codigo) {
		this.codigo = codigo;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
}