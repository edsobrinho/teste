package com.ccb.br.pou.planos.enums;

public enum QualificacaoPatronoEnum {
	
   ADVOGADO(Integer.valueOf(1), "ADVOGADO"), 
   DEFENSOR(Integer.valueOf(2), "DEFENSOR");
  
	private Integer codigo;
	private String descricao;

	private QualificacaoPatronoEnum(Integer codigo, String descricao) {
		this.codigo = codigo;
		this.descricao = descricao;
	}

	public static QualificacaoPatronoEnum getInstance(Integer codigo) {
		if (codigo == null) {
			return null;
		}

		for (QualificacaoPatronoEnum qualificacaoPatrono : values()) {
			if (qualificacaoPatrono.getCodigo().equals(codigo)) {
				return qualificacaoPatrono;
			}
		}

		return null;
	}

	public static QualificacaoPatronoEnum getInstance(String descricao) {
		if (descricao == null) {
			return null;
		}

		for (QualificacaoPatronoEnum qualificacaoPatrono : values()) {
			if (qualificacaoPatrono.getDescricao().equals(descricao)) {
				return qualificacaoPatrono;
			}
		}

		return null;
	}

	public Integer getCodigo() {
		return codigo;
	}

	public void setCodigo(Integer codigo) {
		this.codigo = codigo;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
}