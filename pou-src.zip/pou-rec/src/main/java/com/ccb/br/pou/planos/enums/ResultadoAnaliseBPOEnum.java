package com.ccb.br.pou.planos.enums;

public enum ResultadoAnaliseBPOEnum {
  
	 CONFORME(Integer.valueOf(1), "CONFORME"), 
     NAO_CONFORME(Integer.valueOf(2), "NAO_CONFORME");
  
	private Integer codigo;
	private String descricao;

	private ResultadoAnaliseBPOEnum(Integer codigo, String descricao) {
		this.codigo = codigo;
		this.descricao = descricao;
	}

	public static ResultadoAnaliseBPOEnum getInstance(Integer codigo) {
		if (codigo == null) {
			return null;
		}

		for (ResultadoAnaliseBPOEnum resultAnaliseBPO : values()) {
			if (resultAnaliseBPO.getCodigo().equals(codigo)) {
				return resultAnaliseBPO;
			}
		}

		return null;
	}

	public static ResultadoAnaliseBPOEnum getInstance(String descricao) {
		if (descricao == null) {
			return null;
		}

		for (ResultadoAnaliseBPOEnum resultAnaliseBPO : values()) {
			if (resultAnaliseBPO.getDescricao().equals(descricao)) {
				return resultAnaliseBPO;
			}
		}

		return null;
	}

	public Integer getCodigo() {
		return codigo;
	}

	public void setCodigo(Integer codigo) {
		this.codigo = codigo;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
}