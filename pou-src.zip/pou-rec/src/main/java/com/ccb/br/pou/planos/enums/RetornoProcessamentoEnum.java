package com.ccb.br.pou.planos.enums;

public enum RetornoProcessamentoEnum {
	
    ERRO(Integer.valueOf(1), "ERRO"), 
    FALHA(Integer.valueOf(1), "FALHA"), 
    SUCESSO(Integer.valueOf(3), "SUCESSO");
  
	private Integer codigo;
	private String descricao;

	private RetornoProcessamentoEnum(Integer codigo, String descricao) {
		this.codigo = codigo;
		this.descricao = descricao;
	}

	public static RetornoProcessamentoEnum getInstance(Integer codigo) {
		if (codigo == null) {
			return null;
		}

		for (RetornoProcessamentoEnum tipoIdentidade : values()) {
			if (tipoIdentidade.getCodigo().equals(codigo)) {
				return tipoIdentidade;
			}
		}
		return null;
	}

	public static RetornoProcessamentoEnum getInstance(String descricao) {
		if (descricao == null) {
			return null;
		}

		for (RetornoProcessamentoEnum tipoIdentidade : values()) {
			if (tipoIdentidade.getDescricao().equals(descricao)) {
				return tipoIdentidade;
			}
		}
		return null;
	}

	public Integer getCodigo() {
		return codigo;
	}

	public void setCodigo(Integer codigo) {
		this.codigo = codigo;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
}