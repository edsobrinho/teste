package com.ccb.br.pou.planos.enums;

public enum StatusPedidoEnum {
	
    EM_PREENCHIMENTO(Integer.valueOf(1), "EM_PREENCHIMENTO", "EM PREENCHIMENTO"), 
    PENDENCIA_DE_DOCUMENTOS(Integer.valueOf(2), "PENDENCIA_DE_DOCUMENTOS", "PEND�NCIA DE DOCUMENTOS"), 
    ANALISE_DA_INSTITUICAO(Integer.valueOf(3), "ANALISE_DA_INSTITUICAO", "ANALISE DA INSTITUI��O"), 
    HABILITACAO_NEGADA(Integer.valueOf(4), "HABILITACAO_NEGADA", "HABILITA��O NEGADA"), 
    AGUARDANDO_ACEITE(Integer.valueOf(5), "AGUARDANDO_ACEITE", "AGUARDANDO ACEITE"), 
    ACORDO_NAO_ACEITO(Integer.valueOf(6), "ACORDO_NAO_ACEITO", "ACORDO N�O ACEITO"), 
    PAGAMENTOS_AGENDADOS(Integer.valueOf(7), "PAGAMENTOS_AGENDADOS", "PAGAMENTOS AGENDADOS"), 
    PAGAMENTOS_CONCLUIDOS(Integer.valueOf(8), "PAGAMENTOS_CONCLUIDOS", "PAGAMENTOS CONCLU�DOS");
  
	private Integer codigo;
	private String descricao;
	private String label;

	private StatusPedidoEnum(Integer codigo, String descricao, String label) {
		this.codigo = codigo;
		this.descricao = descricao;
		this.label = label;
	}

	public static StatusPedidoEnum getInstance(Integer codigo) {
		if (codigo == null) {
			return null;
		}

		for (StatusPedidoEnum tipoIdentidade : values()) {
			if (tipoIdentidade.getCodigo().equals(codigo)) {
				return tipoIdentidade;
			}
		}
		return null;
	}

	public static StatusPedidoEnum getInstance(String descricao) {
		if (descricao == null) {
			return null;
		}

		for (StatusPedidoEnum tipoIdentidade : values()) {
			if (tipoIdentidade.getDescricao().equals(descricao)) {
				return tipoIdentidade;
			}
		}
		return null;
	}

	public Integer getCodigo() {
		return codigo;
	}

	public void setCodigo(Integer codigo) {
		this.codigo = codigo;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}
}
