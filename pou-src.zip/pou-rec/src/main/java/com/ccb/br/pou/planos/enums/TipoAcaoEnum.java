package com.ccb.br.pou.planos.enums;

public enum TipoAcaoEnum {

	ORDINARIA(Integer.valueOf(1), "ORDINARIA"), 
    CUMPRIMENTO_SENTENCA_ORIGINARIO_ACAO_CIVIL_PUBLICA(Integer.valueOf(2), "CUMPRIMENTO_SENTENCA_ORIGINARIO_ACAO_CIVIL_PUBLICA"), 
    EXIBICAO_DOCUMENTOS(Integer.valueOf(3), "EXIBICAO_DOCUMENTOS");
  
	private Integer codigo;
	private String descricao;

	private TipoAcaoEnum(Integer codigo, String descricao) {
		this.codigo = codigo;
		this.descricao = descricao;
	}

	public static TipoAcaoEnum getInstance(Integer codigo) {
		if (codigo == null) {
			return null;
		}

		for (TipoAcaoEnum tipoIdentidade : values()) {
			if (tipoIdentidade.getCodigo().equals(codigo)) {
				return tipoIdentidade;
			}
		}
		return null;
	}

	public static TipoAcaoEnum getInstance(String descricao) {
		if (descricao == null) {
			return null;
		}

		for (TipoAcaoEnum tipoIdentidade : values()) {
			if (tipoIdentidade.getDescricao().equals(descricao)) {
				return tipoIdentidade;
			}
		}
		return null;
	}

	public Integer getCodigo() {
		return codigo;
	}

	public void setCodigo(Integer codigo) {
		this.codigo = codigo;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
}