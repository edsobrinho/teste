package com.ccb.br.pou.planos.enums;

public enum TipoContaEnum {
	
   CONTA_CORRENTE(Integer.valueOf(1), "CONTA_CORRENTE"), 
   POUPANCA(Integer.valueOf(2), "POUPANCA");
  
	private Integer codigo;
	private String descricao;

	private TipoContaEnum(Integer codigo, String descricao) {
		this.codigo = codigo;
		this.descricao = descricao;
	}

	public static TipoContaEnum getInstance(Integer codigo) {
		if (codigo == null) {
			return null;
		}

		for (TipoContaEnum tipoConta : values()) {
			if (tipoConta.getCodigo().equals(codigo)) {
				return tipoConta;
			}
		}
		return null;
	}

	public static TipoContaEnum getInstance(String descricao) {
		if (descricao == null) {
			return null;
		}

		for (TipoContaEnum tipoContaEnum : values()) {
			if (tipoContaEnum.getDescricao().equals(descricao)) {
				return tipoContaEnum;
			}
		}
		return null;
	}

	public Integer getCodigo() {
		return codigo;
	}

	public void setCodigo(Integer codigo) {
		this.codigo = codigo;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
}