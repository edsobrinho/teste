package com.ccb.br.pou.planos.enums;

public enum TipoDocumentoEnum {
	
    RG(Integer.valueOf(1), "RG"), 
    RNE(Integer.valueOf(2), "RNE"), 
    CPF(Integer.valueOf(3), "CPF"), 
    OAB(Integer.valueOf(4), "OAB"), 
    OAB_SUPLEMENTAR(Integer.valueOf(5), "OAB_SUPLEMENTAR"), 
    TERMO_INVENTARIANTE(Integer.valueOf(6), "TERMO_INVENTARIANTE"), 
    COPIA_INVENTARIO(Integer.valueOf(7), "COPIA_INVENTARIO"), 
    CERTIDAO_OBITO(Integer.valueOf(8), "CERTIDAO_OBITO"), 
    PROCURACAO(Integer.valueOf(9), "PROCURACAO"), 
    INICIAL(Integer.valueOf(10), "INICIAL"), 
    COPIA_AUTOS(Integer.valueOf(11), "COPIA_AUTOS"), 
    TERMO_QUITACAO_PLANOS_ECONOMICOS(Integer.valueOf(12), "TERMO_QUITACAO_PLANOS_ECONOMICOS"), 
    PETICAO_REGULARIZACAO_POLO_ATIVO(Integer.valueOf(13), "PETICAO_REGULARIZACAO_POLO_ATIVO"), 
    CERTIDAO_CUSTAS(Integer.valueOf(14), "CERTIDAO_CUSTAS"), 
    DECLARACAO_VALORES_ACORDOS_PLANOS_ECONOMICOS(Integer.valueOf(15), "DECLARACAO_VALORES_ACORDOS_PLANOS_ECONOMICOS"), 
    DIRPF(Integer.valueOf(16), "DIRPF"), 
    EXTRATO(Integer.valueOf(17), "EXTRATO"), 
    TERMO_ADESAO(Integer.valueOf(18), "TERMO_ADESAO"), 
    COMPROVANTE_PAGAMENTO(Integer.valueOf(19), "COMPROVANTE_PAGAMENTO"), 
    RACIONAL_CALCULO(Integer.valueOf(20), "RACIONAL_CALCULO");
  
	private Integer codigo;
	private String descricao;

	private TipoDocumentoEnum(Integer codigo, String descricao) {
		this.codigo = codigo;
		this.descricao = descricao;
	}

	public static TipoDocumentoEnum getInstance(Integer codigo) {
		if (codigo == null) {
			return null;
		}

		for (TipoDocumentoEnum tipoDocumento : values()) {
			if (tipoDocumento.getCodigo().equals(codigo)) {
				return tipoDocumento;
			}
		}

		return null;
	}

	public static TipoDocumentoEnum getInstance(String descricao) {
		if (descricao == null) {
			return null;
		}

		for (TipoDocumentoEnum tipoDocumento : values()) {
			if (tipoDocumento.getDescricao().equals(descricao)) {
				return tipoDocumento;
			}
		}

		return null;
	}

	public Integer getCodigo() {
		return codigo;
	}

	public void setCodigo(Integer codigo) {
		this.codigo = codigo;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
}
