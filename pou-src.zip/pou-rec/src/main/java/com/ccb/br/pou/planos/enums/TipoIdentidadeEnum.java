package com.ccb.br.pou.planos.enums;

public enum TipoIdentidadeEnum {
	
	IDENTIDADE(Integer.valueOf(1), "IDENTIDADE"), 
	RNE(Integer.valueOf(2), "RNE");

	private Integer codigo;
	private String descricao;

	private TipoIdentidadeEnum(Integer codigo, String descricao) {
		this.codigo = codigo;
		this.descricao = descricao;
	}

	public static TipoIdentidadeEnum getInstance(Integer codigo) {
		if (codigo == null) {
			return null;
		}

		for (TipoIdentidadeEnum tipoIdentidade : values()) {
			if (tipoIdentidade.getCodigo().equals(codigo)) {
				return tipoIdentidade;
			}
		}
		return null;
	}

	public static TipoIdentidadeEnum getInstance(String descricao) {
		if (descricao == null) {
			return null;
		}

		for (TipoIdentidadeEnum tipoIdentidade : values()) {
			if (tipoIdentidade.getDescricao().equals(descricao)) {
				return tipoIdentidade;
			}
		}
		return null;
	}

	public Integer getCodigo() {
		return codigo;
	}

	public void setCodigo(Integer codigo) {
		this.codigo = codigo;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
}