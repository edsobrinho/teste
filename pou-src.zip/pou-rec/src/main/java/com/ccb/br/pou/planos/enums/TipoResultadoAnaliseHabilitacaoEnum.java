package com.ccb.br.pou.planos.enums;

public enum TipoResultadoAnaliseHabilitacaoEnum {

	HABILITACAO_NEGADA(Integer.valueOf(1), "HABILITACAO_NEGADA"), 
    PROPOSTA_DE_ACORDO(Integer.valueOf(2), "PROPOSTA_DE_ACORDO"), 
    PROPOSTA_DE_ACORDO_COM_VALOR_DIVERGENTE_SIMULADO(Integer.valueOf(2), "PROPOSTA_DE_ACORDO_COM_VALOR_DIVERGENTE_SIMULADO");
  
	private Integer codigo;
	private String descricao;

	private TipoResultadoAnaliseHabilitacaoEnum(Integer codigo, String descricao) {
		this.codigo = codigo;
		this.descricao = descricao;
	}

	public static TipoResultadoAnaliseHabilitacaoEnum getInstance(Integer codigo) {
		if (codigo == null) {
			return null;
		}

		for (TipoResultadoAnaliseHabilitacaoEnum tipoIdentidade : values()) {
			if (tipoIdentidade.getCodigo().equals(codigo)) {
				return tipoIdentidade;
			}
		}
		return null;
	}

	public static TipoResultadoAnaliseHabilitacaoEnum getInstance(String descricao) {
		if (descricao == null) {
			return null;
		}

		for (TipoResultadoAnaliseHabilitacaoEnum tipoIdentidade : values()) {
			if (tipoIdentidade.getDescricao().equals(descricao)) {
				return tipoIdentidade;
			}
		}
		return null;
	}

	public Integer getCodigo() {
		return codigo;
	}

	public void setCodigo(Integer codigo) {
		this.codigo = codigo;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
}