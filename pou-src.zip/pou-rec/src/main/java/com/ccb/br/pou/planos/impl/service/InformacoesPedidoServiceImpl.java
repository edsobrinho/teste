package com.ccb.br.pou.planos.impl.service;

import br.com.bicbanco.bicbase.exceptions.ServiceException;
import br.com.bicbanco.bicbase.service.BaseService;
import com.ccb.br.pou.planos.enums.StatusPedidoEnum;
import com.ccb.br.pou.planos.service.InformacoesPedidoService;
import com.ccb.br.pou.planos.to.InformacoesPedidoTO;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class InformacoesPedidoServiceImpl extends BaseService implements InformacoesPedidoService {
	private static final long serialVersionUID = 1L;

	public InformacoesPedidoServiceImpl() {
	}

	public List<InformacoesPedidoTO> listInformacoesPedido() throws ServiceException {
		return mockListInfoPedidos();
	}

	private List<InformacoesPedidoTO> mockListInfoPedidos() {
		List<InformacoesPedidoTO> pedidos = new ArrayList<InformacoesPedidoTO>();

		InformacoesPedidoTO pedido = new InformacoesPedidoTO();

		pedido.setNumeroProtocolo("HAB-083-20180507-00001532");
		pedido.setCpf("298.474.228-18");
		pedido.setNumeroProcesso("0078900-20.0749.0.10.00");
		pedido.setDataAbertura(new Date());
		pedido.setStatus(StatusPedidoEnum.ANALISE_DA_INSTITUICAO);
		pedidos.add(pedido);

		InformacoesPedidoTO pedido1 = new InformacoesPedidoTO();

		pedido1.setNumeroProtocolo("HAB-083-20180510-00001529");
		pedido1.setCpf("298.474.228-18");
		pedido1.setNumeroProcesso("0078900-20.0761.1.00.0");
		pedido1.setDataAbertura(new Date());
		pedido1.setStatus(StatusPedidoEnum.ANALISE_DA_INSTITUICAO);
		pedidos.add(pedido1);

		InformacoesPedidoTO pedido2 = new InformacoesPedidoTO();

		pedido2.setNumeroProtocolo("HAB-083-20180507-00001508");
		pedido2.setCpf("298.474.228-18");
		pedido2.setNumeroProcesso("0078900-20.0750.1.00.0");
		pedido2.setDataAbertura(new Date());
		pedido2.setStatus(StatusPedidoEnum.ANALISE_DA_INSTITUICAO);
		pedidos.add(pedido2);

		InformacoesPedidoTO pedido3 = new InformacoesPedidoTO();

		pedido3.setNumeroProtocolo("HAB-001-20180504-00001502");
		pedido3.setCpf("298.474.228-18");
		pedido3.setNumeroProcesso("0078900-20.0750.1.00.0");
		pedido3.setDataAbertura(new Date());
		pedido3.setStatus(StatusPedidoEnum.PENDENCIA_DE_DOCUMENTOS);
		pedidos.add(pedido3);

		return pedidos;
	}
}