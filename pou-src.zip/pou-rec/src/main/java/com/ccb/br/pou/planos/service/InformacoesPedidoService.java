package com.ccb.br.pou.planos.service;

import java.util.List;

import com.ccb.br.pou.planos.to.InformacoesPedidoTO;

import br.com.bicbanco.bicbase.exceptions.ServiceException;
import br.com.bicbanco.bicbase.service.Service;

public abstract interface InformacoesPedidoService extends Service {
	public abstract List<InformacoesPedidoTO> listInformacoesPedido() throws ServiceException;
}