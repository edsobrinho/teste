package com.ccb.br.pou.planos.to;

import br.com.bicbanco.bicbase.dto.BaseTO;
import com.ccb.br.pou.planos.enums.AceitePropostaEnum;
import com.google.gson.Gson;
import java.io.Serializable;
import java.util.Date;

public class AceitePropostaTO extends BaseTO {
	
	private static final long serialVersionUID = 1L;
	private String guidPedido;
	private String idProposta;
	private String idPropostaBanco;
	private Date data;
	private AceitePropostaEnum aceite;
	private String motivoRecusa;

	public AceitePropostaTO() {
	}

	public Serializable getKey() {
		return new Serializable[] { guidPedido, idProposta, idPropostaBanco };
	}

	public String getGuidPedido() {
		return guidPedido;
	}

	public void setGuidPedido(String guidPedido) {
		this.guidPedido = guidPedido;
	}

	public String getIdProposta() {
		return idProposta;
	}

	public void setIdProposta(String idProposta) {
		this.idProposta = idProposta;
	}

	public String getIdPropostaBanco() {
		return idPropostaBanco;
	}

	public void setIdPropostaBanco(String idPropostaBanco) {
		this.idPropostaBanco = idPropostaBanco;
	}

	public Date getData() {
		return data;
	}

	public void setData(Date data) {
		this.data = data;
	}

	public AceitePropostaEnum getAceite() {
		return aceite;
	}

	public void setAceite(AceitePropostaEnum aceite) {
		this.aceite = aceite;
	}

	public String getMotivoRecusa() {
		return motivoRecusa;
	}

	public void setMotivoRecusa(String motivoRecusa) {
		this.motivoRecusa = motivoRecusa;
	}

	public String toString() {
		return new Gson().toJson(this);
	}
}