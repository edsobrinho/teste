package com.ccb.br.pou.planos.to;

import java.io.Serializable;

import com.ccb.br.pou.planos.enums.QualificacaoPatronoEnum;
import com.google.gson.Gson;

import br.com.bicbanco.bicbase.dto.BaseTO;

public class AdvogadoTO extends BaseTO {
	private static final long serialVersionUID = 1L;
	private Integer id;
	private String cpf;
	private String nome;
	private IdentidadePatronoTO oab;
	private IdentidadePatronoTO oabSuplementar;
	private IdentidadePatronoTO matriculaDefensor;
	private ContatoTO contato;
	private QualificacaoPatronoEnum qualificacaoPatrono;

	public AdvogadoTO() {
	}

	public Serializable getKey() {
		return id;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public IdentidadePatronoTO getOab() {
		return oab;
	}

	public void setOab(IdentidadePatronoTO oab) {
		this.oab = oab;
	}

	public IdentidadePatronoTO getOabSuplementar() {
		return oabSuplementar;
	}

	public void setOabSuplementar(IdentidadePatronoTO oabSuplementar) {
		this.oabSuplementar = oabSuplementar;
	}

	public IdentidadePatronoTO getMatriculaDefensor() {
		return matriculaDefensor;
	}

	public void setMatriculaDefensor(IdentidadePatronoTO matriculaDefensor) {
		this.matriculaDefensor = matriculaDefensor;
	}

	public ContatoTO getContato() {
		return contato;
	}

	public void setContato(ContatoTO contato) {
		this.contato = contato;
	}

	public QualificacaoPatronoEnum getQualificacaoPatrono() {
		return qualificacaoPatrono;
	}

	public void setQualificacaoPatrono(QualificacaoPatronoEnum qualificacaoPatrono) {
		this.qualificacaoPatrono = qualificacaoPatrono;
	}

	public String toString() {
		return new Gson().toJson(this);
	}
}