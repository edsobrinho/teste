package com.ccb.br.pou.planos.to;

import br.com.bicbanco.bicbase.dto.BaseTO;
import com.google.gson.Gson;
import java.io.Serializable;

public class ArquivoTO extends BaseTO {
	
	private static final long serialVersionUID = 1L;
	private Integer id;
	private String guidPedido;
	private String nomeArquivo;
	private String conteudo;

	public ArquivoTO() {
	}

	public Serializable getKey() {
		return id;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getGuidPedido() {
		return guidPedido;
	}

	public void setGuidPedido(String guidPedido) {
		this.guidPedido = guidPedido;
	}

	public String getNomeArquivo() {
		return nomeArquivo;
	}

	public void setNomeArquivo(String nomeArquivo) {
		this.nomeArquivo = nomeArquivo;
	}

	public String getConteudo() {
		return conteudo;
	}

	public void setConteudo(String conteudo) {
		this.conteudo = conteudo;
	}

	public String toString() {
		return new Gson().toJson(this);
	}
}