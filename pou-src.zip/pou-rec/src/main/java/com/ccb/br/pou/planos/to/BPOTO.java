package com.ccb.br.pou.planos.to;

import br.com.bicbanco.bicbase.dto.BaseTO;
import com.google.gson.Gson;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class BPOTO extends BaseTO {
	private static final long serialVersionUID = 1L;
	private Integer sequencial;
	private Integer idAnaliseBPO;
	private String guidPedido;
	private Date dataSubmissaoBPO;
	private Date dataLiberacaoBPO;
	private List<ResultadoAnaliseBPOTO> itensBPO;

	public BPOTO() {
	}

	public Serializable getKey() {
		return new Serializable[] { sequencial, idAnaliseBPO, guidPedido };
	}

	public Integer getSequencial() {
		return sequencial;
	}

	public void setSequencial(Integer sequencial) {
		this.sequencial = sequencial;
	}

	public Integer getIdAnaliseBPO() {
		return idAnaliseBPO;
	}

	public void setIdAnaliseBPO(Integer idAnaliseBPO) {
		this.idAnaliseBPO = idAnaliseBPO;
	}

	public String getGuidPedido() {
		return guidPedido;
	}

	public void setGuidPedido(String guidPedido) {
		this.guidPedido = guidPedido;
	}

	public Date getDataSubmissaoBPO() {
		return dataSubmissaoBPO;
	}

	public void setDataSubmissaoBPO(Date dataSubmissaoBPO) {
		this.dataSubmissaoBPO = dataSubmissaoBPO;
	}

	public Date getDataLiberacaoBPO() {
		return dataLiberacaoBPO;
	}

	public void setDataLiberacaoBPO(Date dataLiberacaoBPO) {
		this.dataLiberacaoBPO = dataLiberacaoBPO;
	}

	public List<ResultadoAnaliseBPOTO> getItensBPO() {
		if ((itensBPO == null) || (itensBPO.isEmpty())) {
			itensBPO = new ArrayList<ResultadoAnaliseBPOTO>();
		}
		return itensBPO;
	}

	public void setItensBPO(List<ResultadoAnaliseBPOTO> itensBPO) {
		this.itensBPO = itensBPO;
	}

	public String toString() {
		return new Gson().toJson(this);
	}
}