package com.ccb.br.pou.planos.to;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.ccb.br.pou.planos.enums.PlanoEnum;
import com.google.gson.Gson;

import br.com.bicbanco.bicbase.types.Money;

public class ContaPlanoTO extends ContaTO {
	private static final long serialVersionUID = 1L;
	private Integer idContaPlano;
	private PlanoEnum plano;
	private Money saldoBase;
	private Money valorSimulado;
	private Integer diaAniversarioConta;
	private List<HabilitacaoTO> pedidoEmOutrasHabilitacoes;

	public ContaPlanoTO() {
	}

	public Serializable getKey() {
		return idContaPlano;
	}

	public Integer getIdContaPlano() {
		return idContaPlano;
	}

	public void setIdContaPlano(Integer idContaPlano) {
		this.idContaPlano = idContaPlano;
	}

	public PlanoEnum getPlano() {
		return plano;
	}

	public void setPlano(PlanoEnum plano) {
		this.plano = plano;
	}

	public Money getSaldoBase() {
		return saldoBase;
	}

	public void setSaldoBase(Money saldoBase) {
		this.saldoBase = saldoBase;
	}

	public Money getValorSimulado() {
		return valorSimulado;
	}

	public void setValorSimulado(Money valorSimulado) {
		this.valorSimulado = valorSimulado;
	}

	public Integer getDiaAniversarioConta() {
		return diaAniversarioConta;
	}

	public void setDiaAniversarioConta(Integer diaAniversarioConta) {
		this.diaAniversarioConta = diaAniversarioConta;
	}

	public List<HabilitacaoTO> getPedidoEmOutrasHabilitacoes() {
		if ((pedidoEmOutrasHabilitacoes == null) || (pedidoEmOutrasHabilitacoes.isEmpty())) {
			pedidoEmOutrasHabilitacoes = new ArrayList<HabilitacaoTO>();
		}
		return pedidoEmOutrasHabilitacoes;
	}

	public void setPedidoEmOutrasHabilitacoes(List<HabilitacaoTO> pedidoEmOutrasHabilitacoes) {
		this.pedidoEmOutrasHabilitacoes = pedidoEmOutrasHabilitacoes;
	}

	public String toString() {
		return new Gson().toJson(this);
	}
}