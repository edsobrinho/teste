package com.ccb.br.pou.planos.to;

import java.io.Serializable;

import com.ccb.br.pou.planos.enums.TipoContaEnum;
import com.google.gson.Gson;

import br.com.bicbanco.bicbase.dto.BaseTO;

public class ContaTO extends BaseTO {
	private static final long serialVersionUID = 1L;
	private Integer id;
	private String nomeTitular;
	private String cpfCnpj;
	private Integer banco;
	private String nomeBanco;
	private String agencia;
	private String agenciaDV;
	private String numeroConta;
	private String numeroContaDV;
	private TipoContaEnum tipoConta;

	public ContaTO() {
	}

	public Serializable getKey() {
		return id;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getNomeTitular() {
		return nomeTitular;
	}

	public void setNomeTitular(String nomeTitular) {
		this.nomeTitular = nomeTitular;
	}

	public String getCpfCnpj() {
		return cpfCnpj;
	}

	public void setCpfCnpj(String cpfCnpj) {
		this.cpfCnpj = cpfCnpj;
	}

	public Integer getBanco() {
		return banco;
	}

	public void setBanco(Integer banco) {
		this.banco = banco;
	}

	public String getNomeBanco() {
		return nomeBanco;
	}

	public void setNomeBanco(String nomeBanco) {
		this.nomeBanco = nomeBanco;
	}

	public String getAgencia() {
		return agencia;
	}

	public void setAgencia(String agencia) {
		this.agencia = agencia;
	}

	public String getAgenciaDV() {
		return agenciaDV;
	}

	public void setAgenciaDV(String agenciaDV) {
		this.agenciaDV = agenciaDV;
	}

	public String getNumeroConta() {
		return numeroConta;
	}

	public void setNumeroConta(String numeroConta) {
		this.numeroConta = numeroConta;
	}

	public String getNumeroContaDV() {
		return numeroContaDV;
	}

	public void setNumeroContaDV(String numeroContaDV) {
		this.numeroContaDV = numeroContaDV;
	}

	public TipoContaEnum getTipoConta() {
		return tipoConta;
	}

	public void setTipoConta(TipoContaEnum tipoConta) {
		this.tipoConta = tipoConta;
	}

	public String toString() {
		return new Gson().toJson(this);
	}
}