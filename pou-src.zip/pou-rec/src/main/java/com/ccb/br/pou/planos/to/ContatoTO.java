package com.ccb.br.pou.planos.to;

import br.com.bicbanco.bicbase.dto.BaseTO;
import com.google.gson.Gson;
import java.io.Serializable;

public class ContatoTO extends BaseTO {
	
	private static final long serialVersionUID = 1L;
	private Long id;
	private TelefoneTO celular;
	private String email;
	private TelefoneTO telefoneFixo;

	public ContatoTO() {
	}

	public Serializable getKey() {
		return id;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public TelefoneTO getCelular() {
		return celular;
	}

	public void setCelular(TelefoneTO celular) {
		this.celular = celular;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public TelefoneTO getTelefoneFixo() {
		return telefoneFixo;
	}

	public void setTelefoneFixo(TelefoneTO telefoneFixo) {
		this.telefoneFixo = telefoneFixo;
	}

	public String toString() {
		return new Gson().toJson(this);
	}
}