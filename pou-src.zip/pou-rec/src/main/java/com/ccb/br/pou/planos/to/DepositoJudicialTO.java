package com.ccb.br.pou.planos.to;

import java.io.Serializable;
import java.util.Date;

import com.google.gson.Gson;

import br.com.bicbanco.bicbase.dto.BaseTO;

public class DepositoJudicialTO extends BaseTO {
	private static final long serialVersionUID = 1L;
	private Long id;
	private Integer banco;
	private String nomeBanco;
	private String idDepositoJudicial;
	private Date dataValidade;

	public DepositoJudicialTO() {
	}

	public Serializable getKey() {
		return id;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Integer getBanco() {
		return banco;
	}

	public void setBanco(Integer banco) {
		this.banco = banco;
	}

	public String getNomeBanco() {
		return nomeBanco;
	}

	public void setNomeBanco(String nomeBanco) {
		this.nomeBanco = nomeBanco;
	}

	public String getIdDepositoJudicial() {
		return idDepositoJudicial;
	}

	public void setIdDepositoJudicial(String idDepositoJudicial) {
		this.idDepositoJudicial = idDepositoJudicial;
	}

	public Date getDataValidade() {
		return dataValidade;
	}

	public void setDataValidade(Date dataValidade) {
		this.dataValidade = dataValidade;
	}

	public String toString() {
		return new Gson().toJson(this);
	}
}