package com.ccb.br.pou.planos.to;

import br.com.bicbanco.bicbase.dto.BaseTO;
import com.ccb.br.pou.planos.enums.ContextoEnum;
import com.ccb.br.pou.planos.enums.TipoDocumentoEnum;
import com.google.gson.Gson;
import java.io.Serializable;

public class DocumentoTO extends BaseTO {
	private static final long serialVersionUID = 1L;
	private Integer id;
	private String nomeDocumento;
	private TipoDocumentoEnum tipoDocumento;
	private ContextoEnum contexto;
	private Integer idChaveContexto;

	public DocumentoTO() {
	}

	public Serializable getKey() {
		return id;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getNomeDocumento() {
		return nomeDocumento;
	}

	public void setNomeDocumento(String nomeDocumento) {
		this.nomeDocumento = nomeDocumento;
	}

	public TipoDocumentoEnum getTipoDocumento() {
		return tipoDocumento;
	}

	public void setTipoDocumento(TipoDocumentoEnum tipoDocumento) {
		this.tipoDocumento = tipoDocumento;
	}

	public ContextoEnum getContexto() {
		return contexto;
	}

	public void setContexto(ContextoEnum contexto) {
		this.contexto = contexto;
	}

	public Integer getIdChaveContexto() {
		return idChaveContexto;
	}

	public void setIdChaveContexto(Integer idChaveContexto) {
		this.idChaveContexto = idChaveContexto;
	}

	public String toString() {
		return new Gson().toJson(this);
	}
}