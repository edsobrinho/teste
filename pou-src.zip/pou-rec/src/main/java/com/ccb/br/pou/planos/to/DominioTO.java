package com.ccb.br.pou.planos.to;

import br.com.bicbanco.bicbase.dto.BaseTO;
import com.google.gson.Gson;
import java.io.Serializable;
import java.util.List;

public class DominioTO extends BaseTO {
	private static final long serialVersionUID = 1L;
	private Integer id;
	private String nome;
	private List<DominioItemTO> itens;

	public DominioTO() {
	}

	public Serializable getKey() {
		return id;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public List<DominioItemTO> getItens() {
		return itens;
	}

	public void setItens(List<DominioItemTO> itens) {
		this.itens = itens;
	}

	public String toString() {
		return new Gson().toJson(this);
	}
}