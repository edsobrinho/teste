package com.ccb.br.pou.planos.to;

import br.com.bicbanco.bicbase.dto.BaseTO;
import com.google.gson.Gson;
import java.io.Serializable;

public class HabilitacaoTO extends BaseTO {
	private static final long serialVersionUID = 1L;
	private String protocolo;

	public HabilitacaoTO() {
	}

	public Serializable getKey() {
		return protocolo;
	}

	public String getProtocolo() {
		return protocolo;
	}

	public void setProtocolo(String protocolo) {
		this.protocolo = protocolo;
	}

	public String toString() {
		return new Gson().toJson(this);
	}
}