package com.ccb.br.pou.planos.to;

import java.io.Serializable;

import com.ccb.br.pou.planos.enums.EsferaEnum;
import com.google.gson.Gson;

import br.com.bicbanco.bicbase.dto.BaseTO;

public class IdentidadePatronoTO extends BaseTO {
	private static final long serialVersionUID = 1L;
	private Integer id;
	private EsferaEnum esfera;
	private String UF;
	private String numero;

	public IdentidadePatronoTO() {
	}

	public Serializable getKey() {
		return id;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public EsferaEnum getEsfera() {
		return esfera;
	}

	public void setEsfera(EsferaEnum esfera) {
		this.esfera = esfera;
	}

	public String getUF() {
		return UF;
	}

	public void setUF(String uF) {
		UF = uF;
	}

	public String getNumero() {
		return numero;
	}

	public void setNumero(String numero) {
		this.numero = numero;
	}

	public String toString() {
		return new Gson().toJson(this);
	}
}