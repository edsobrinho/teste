package com.ccb.br.pou.planos.to;

import java.io.Serializable;
import java.util.Date;

import com.ccb.br.pou.planos.enums.TipoIdentidadeEnum;
import com.google.gson.Gson;

import br.com.bicbanco.bicbase.dto.BaseTO;

public class IdentidadeTO extends BaseTO {
	private static final long serialVersionUID = 1L;
	private Integer id;
	private String numero;
	private String orgao;
	private String UF;
	private TipoIdentidadeEnum tipo;
	private String classificacao;
	private Date validade;

	public IdentidadeTO() {
	}

	public Serializable getKey() {
		return id;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getNumero() {
		return numero;
	}

	public void setNumero(String numero) {
		this.numero = numero;
	}

	public String getOrgao() {
		return orgao;
	}

	public void setOrgao(String orgao) {
		this.orgao = orgao;
	}

	public String getUF() {
		return UF;
	}

	public void setUF(String uF) {
		UF = uF;
	}

	public TipoIdentidadeEnum getTipo() {
		return tipo;
	}

	public void setTipo(TipoIdentidadeEnum tipo) {
		this.tipo = tipo;
	}

	public String getClassificacao() {
		return classificacao;
	}

	public void setClassificacao(String classificacao) {
		this.classificacao = classificacao;
	}

	public Date getValidade() {
		return validade;
	}

	public void setValidade(Date validade) {
		this.validade = validade;
	}

	public String toString() {
		return new Gson().toJson(this);
	}
}