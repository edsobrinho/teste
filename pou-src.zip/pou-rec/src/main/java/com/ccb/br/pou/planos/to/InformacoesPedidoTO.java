/**
 * 
 */
package com.ccb.br.pou.planos.to;

import java.io.Serializable;
import java.util.Date;

import com.ccb.br.pou.planos.enums.StatusPedidoEnum;

import br.com.bicbanco.bicbase.dto.BaseTO;

/**
 * @author opah01
 *
 */
public class InformacoesPedidoTO extends BaseTO {

	private static final long serialVersionUID = 1L;
	
	private String numeroProtocolo;
	private String cpf;
	private String numeroProcesso;
	private Date dataAbertura;
	private StatusPedidoEnum status;

	@Override
	public Serializable getKey() {
		return numeroProtocolo;
	}

	/**
	 * @return the numeroProtocolo
	 */
	public String getNumeroProtocolo() {
		return numeroProtocolo;
	}

	/**
	 * @param numeroProtocolo the numeroProtocolo to set
	 */
	public void setNumeroProtocolo(String numeroProtocolo) {
		this.numeroProtocolo = numeroProtocolo;
	}

	/**
	 * @return the cpf
	 */
	public String getCpf() {
		return cpf;
	}

	/**
	 * @param cpf the cpf to set
	 */
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	/**
	 * @return the numeroProcesso
	 */
	public String getNumeroProcesso() {
		return numeroProcesso;
	}

	/**
	 * @param numeroProcesso the numeroProcesso to set
	 */
	public void setNumeroProcesso(String numeroProcesso) {
		this.numeroProcesso = numeroProcesso;
	}

	/**
	 * @return the dataAbertura
	 */
	public Date getDataAbertura() {
		return dataAbertura;
	}

	/**
	 * @param dataAbertura the dataAbertura to set
	 */
	public void setDataAbertura(Date dataAbertura) {
		this.dataAbertura = dataAbertura;
	}

	/**
	 * @return the status
	 */
	public StatusPedidoEnum getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(StatusPedidoEnum status) {
		this.status = status;
	}
}