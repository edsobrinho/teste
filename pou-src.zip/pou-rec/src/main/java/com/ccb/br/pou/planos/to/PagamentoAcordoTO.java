package com.ccb.br.pou.planos.to;

import br.com.bicbanco.bicbase.dto.BaseTO;
import br.com.bicbanco.bicbase.types.Money;
import com.ccb.br.pou.planos.enums.StatusPagamentoEnum;
import com.google.gson.Gson;
import java.io.Serializable;
import java.util.Date;

public class PagamentoAcordoTO extends BaseTO {
	private static final long serialVersionUID = 1L;
	private String guidPedido;
	private Integer idPropostaBanco;
	private Date dataPagamento;
	private Money valorPagamento;
	private Integer numeroParcela;
	private ArquivoTO comprovante;
	private StatusPagamentoEnum statusPagamento;
	private String observacoesPagamento;
	private ContaPagamentoTO contaPagamentoAcordo;

	public PagamentoAcordoTO() {
	}

	public Serializable getKey() {
		return null;
	}

	public String getGuidPedido() {
		return guidPedido;
	}

	public void setGuidPedido(String guidPedido) {
		this.guidPedido = guidPedido;
	}

	public Integer getIdPropostaBanco() {
		return idPropostaBanco;
	}

	public void setIdPropostaBanco(Integer idPropostaBanco) {
		this.idPropostaBanco = idPropostaBanco;
	}

	public Date getDataPagamento() {
		return dataPagamento;
	}

	public void setDataPagamento(Date dataPagamento) {
		this.dataPagamento = dataPagamento;
	}

	public Money getValorPagamento() {
		return valorPagamento;
	}

	public void setValorPagamento(Money valorPagamento) {
		this.valorPagamento = valorPagamento;
	}

	public Integer getNumeroParcela() {
		return numeroParcela;
	}

	public void setNumeroParcela(Integer numeroParcela) {
		this.numeroParcela = numeroParcela;
	}

	public ArquivoTO getComprovante() {
		return comprovante;
	}

	public void setComprovante(ArquivoTO comprovante) {
		this.comprovante = comprovante;
	}

	public StatusPagamentoEnum getStatusPagamento() {
		return statusPagamento;
	}

	public void setStatusPagamento(StatusPagamentoEnum statusPagamento) {
		this.statusPagamento = statusPagamento;
	}

	public String getObservacoesPagamento() {
		return observacoesPagamento;
	}

	public void setObservacoesPagamento(String observacoesPagamento) {
		this.observacoesPagamento = observacoesPagamento;
	}

	public ContaPagamentoTO getContaPagamentoAcordo() {
		return contaPagamentoAcordo;
	}

	public void setContaPagamentoAcordo(ContaPagamentoTO contaPagamentoAcordo) {
		this.contaPagamentoAcordo = contaPagamentoAcordo;
	}

	public String toString() {
		return new Gson().toJson(this);
	}
}