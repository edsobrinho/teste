package com.ccb.br.pou.planos.to;

import java.io.Serializable;
import java.util.Date;

import com.ccb.br.pou.planos.enums.QualificacaoEnvolvidoEnum;
import com.google.gson.Gson;

import br.com.bicbanco.bicbase.dto.BaseTO;

public class ParteTO extends BaseTO {
	private static final long serialVersionUID = 1L;
	private Integer id;
	private String cpf;
	private String nome;
	private IdentidadeTO identidade;
	private Date dataNascimento;
	private Boolean falecido;
	private Date dataObito;
	private EnderecoTO enderecoCorrespondencia;
	private ContatoTO contato;
	private QualificacaoEnvolvidoEnum qualificacao;

	public ParteTO() {
	}

	public Serializable getKey() {
		return id;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public IdentidadeTO getIdentidade() {
		return identidade;
	}

	public void setIdentidade(IdentidadeTO identidade) {
		this.identidade = identidade;
	}

	public Date getDataNascimento() {
		return dataNascimento;
	}

	public void setDataNascimento(Date dataNascimento) {
		this.dataNascimento = dataNascimento;
	}

	public Boolean getFalecido() {
		return falecido;
	}

	public void setFalecido(Boolean falecido) {
		this.falecido = falecido;
	}

	public Date getDataObito() {
		return dataObito;
	}

	public void setDataObito(Date dataObito) {
		this.dataObito = dataObito;
	}

	public EnderecoTO getEnderecoCorrespondencia() {
		return enderecoCorrespondencia;
	}

	public void setEnderecoCorrespondencia(EnderecoTO enderecoCorrespondencia) {
		this.enderecoCorrespondencia = enderecoCorrespondencia;
	}

	public ContatoTO getContato() {
		return contato;
	}

	public void setContato(ContatoTO contato) {
		this.contato = contato;
	}

	public QualificacaoEnvolvidoEnum getQualificacao() {
		return qualificacao;
	}

	public void setQualificacao(QualificacaoEnvolvidoEnum qualificacao) {
		this.qualificacao = qualificacao;
	}

	public String toString() {
		return new Gson().toJson(this);
	}
}