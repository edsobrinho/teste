/**
 * 
 */
package com.ccb.br.pou.planos.to;

import java.io.Serializable;
import java.util.Date;

import com.ccb.br.pou.planos.enums.StatusPedidoEnum;

import br.com.bicbanco.bicbase.dto.BaseTO;

/**
 * @author opah01
 *
 */
public class PedidoFiltroTO extends BaseTO {
	
	private static final long serialVersionUID = 1L;
	
	private Date dataFim;
    private Date dataInicio;
    private String guidPedido;
    private Integer quantidadeARetornar;
    private Integer statusCodigo;
    private StatusPedidoEnum status;
	
	@Override
	public Serializable getKey() {
		return guidPedido;
	}

	/**
	 * @return the dataFim
	 */
	public Date getDataFim() {
		return dataFim;
	}

	/**
	 * @param dataFim the dataFim to set
	 */
	public void setDataFim(Date dataFim) {
		this.dataFim = dataFim;
	}

	/**
	 * @return the dataInicio
	 */
	public Date getDataInicio() {
		return dataInicio;
	}

	/**
	 * @param dataInicio the dataInicio to set
	 */
	public void setDataInicio(Date dataInicio) {
		this.dataInicio = dataInicio;
	}

	/**
	 * @return the guidPedido
	 */
	public String getGuidPedido() {
		return guidPedido;
	}

	/**
	 * @param guidPedido the guidPedido to set
	 */
	public void setGuidPedido(String guidPedido) {
		this.guidPedido = guidPedido;
	}

	/**
	 * @return the quantidadeARetornar
	 */
	public Integer getQuantidadeARetornar() {
		return quantidadeARetornar;
	}

	/**
	 * @param quantidadeARetornar the quantidadeARetornar to set
	 */
	public void setQuantidadeARetornar(Integer quantidadeARetornar) {
		this.quantidadeARetornar = quantidadeARetornar;
	}

	/**
	 * @return the status
	 */
	public StatusPedidoEnum getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(StatusPedidoEnum status) {
		this.status = status;
	}

	/**
	 * @return the statusCodigo
	 */
	public Integer getStatusCodigo() {
		return statusCodigo;
	}

	/**
	 * @param statusCodigo the statusCodigo to set
	 */
	public void setStatusCodigo(Integer statusCodigo) {
		this.statusCodigo = statusCodigo;
	}
}