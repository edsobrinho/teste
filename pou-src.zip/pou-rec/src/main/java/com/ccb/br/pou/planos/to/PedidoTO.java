package com.ccb.br.pou.planos.to;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.ccb.br.pou.planos.enums.DestinatarioContaEnum;
import com.ccb.br.pou.planos.enums.StatusPedidoEnum;
import com.google.gson.Gson;

import br.com.bicbanco.bicbase.dto.BaseTO;
import br.com.bicbanco.bicbase.types.Money;

public class PedidoTO extends BaseTO {
	private static final long serialVersionUID = 1L;
	private String guidPedido;
	private String protocolo;
	private Integer idLoteHabilitacao;
	private Date dataAbertura;
	private StatusPedidoEnum statusPedido;
	private Money valorCustasProcessuais;
	private Date dataConfimacaoLeituraBanco;
	private Money valorTotalSimulado;
	private DestinatarioContaEnum destinatarioPagamentoAcordo;
	private ParteTO poupador;
	private List<ParteTO> envolvidosEspolio;
	private AdvogadoTO patrono;
	private ContaPagamentoTO contaPagamentoAcordo;
	private ContaPagamentoTO contaPagamentoHonorario;
	private ProcessoTO processo;
	private List<ContaPlanoTO> contasContempladas;
	private List<DocumentoTO> documentos;
	private BPOTO resultadoBPO;

	public PedidoTO() {
	}

	public Serializable getKey() {
		return new Serializable[] { guidPedido, protocolo };
	}

	public String getGuidPedido() {
		return guidPedido;
	}

	public void setGuidPedido(String guidPedido) {
		this.guidPedido = guidPedido;
	}

	public String getProtocolo() {
		return protocolo;
	}

	public void setProtocolo(String protocolo) {
		this.protocolo = protocolo;
	}

	public Integer getIdLoteHabilitacao() {
		return idLoteHabilitacao;
	}

	public void setIdLoteHabilitacao(Integer idLoteHabilitacao) {
		this.idLoteHabilitacao = idLoteHabilitacao;
	}

	public Date getDataAbertura() {
		return dataAbertura;
	}

	public void setDataAbertura(Date dataAbertura) {
		this.dataAbertura = dataAbertura;
	}

	public StatusPedidoEnum getStatusPedido() {
		return statusPedido;
	}

	public void setStatusPedido(StatusPedidoEnum statusPedido) {
		this.statusPedido = statusPedido;
	}

	public Money getValorCustasProcessuais() {
		return valorCustasProcessuais;
	}

	public void setValorCustasProcessuais(Money valorCustasProcessuais) {
		this.valorCustasProcessuais = valorCustasProcessuais;
	}

	public Date getDataConfimacaoLeituraBanco() {
		return dataConfimacaoLeituraBanco;
	}

	public void setDataConfimacaoLeituraBanco(Date dataConfimacaoLeituraBanco) {
		this.dataConfimacaoLeituraBanco = dataConfimacaoLeituraBanco;
	}

	public Money getValorTotalSimulado() {
		return valorTotalSimulado;
	}

	public void setValorTotalSimulado(Money valorTotalSimulado) {
		this.valorTotalSimulado = valorTotalSimulado;
	}

	public DestinatarioContaEnum getDestinatarioPagamentoAcordo() {
		return destinatarioPagamentoAcordo;
	}

	public void setDestinatarioPagamentoAcordo(DestinatarioContaEnum destinatarioPagamentoAcordo) {
		this.destinatarioPagamentoAcordo = destinatarioPagamentoAcordo;
	}

	public ParteTO getPoupador() {
		return poupador;
	}

	public void setPoupador(ParteTO poupador) {
		this.poupador = poupador;
	}

	public List<ParteTO> getEnvolvidosEspolio() {
		if ((envolvidosEspolio == null) || (envolvidosEspolio.isEmpty())) {
			envolvidosEspolio = new ArrayList<ParteTO>();
		}
		return envolvidosEspolio;
	}

	public void setEnvolvidosEspolio(List<ParteTO> envolvidosEspolio) {
		this.envolvidosEspolio = envolvidosEspolio;
	}

	public AdvogadoTO getPatrono() {
		return patrono;
	}

	public void setPatrono(AdvogadoTO patrono) {
		this.patrono = patrono;
	}

	public ContaPagamentoTO getContaPagamentoAcordo() {
		return contaPagamentoAcordo;
	}

	public void setContaPagamentoAcordo(ContaPagamentoTO contaPagamentoAcordo) {
		this.contaPagamentoAcordo = contaPagamentoAcordo;
	}

	public ContaPagamentoTO getContaPagamentoHonorario() {
		return contaPagamentoHonorario;
	}

	public void setContaPagamentoHonorario(ContaPagamentoTO contaPagamentoHonorario) {
		this.contaPagamentoHonorario = contaPagamentoHonorario;
	}

	public ProcessoTO getProcesso() {
		return processo;
	}

	public void setProcesso(ProcessoTO processo) {
		this.processo = processo;
	}

	public List<ContaPlanoTO> getContasContempladas() {
		if ((contasContempladas == null) || (contasContempladas.isEmpty())) {
			contasContempladas = new ArrayList<ContaPlanoTO>();
		}
		return contasContempladas;
	}

	public void setContasContempladas(List<ContaPlanoTO> contasContempladas) {
		this.contasContempladas = contasContempladas;
	}

	public List<DocumentoTO> getDocumentos() {
		if ((documentos == null) || (documentos.isEmpty())) {
			documentos = new ArrayList<DocumentoTO>();
		}
		return documentos;
	}

	public void setDocumentos(List<DocumentoTO> documentos) {
		this.documentos = documentos;
	}

	public BPOTO getResultadoBPO() {
		return resultadoBPO;
	}

	public void setResultadoBPO(BPOTO resultadoBPO) {
		this.resultadoBPO = resultadoBPO;
	}

	public String toString() {
		return new Gson().toJson(this);
	}
}