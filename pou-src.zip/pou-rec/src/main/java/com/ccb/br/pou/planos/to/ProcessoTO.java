package com.ccb.br.pou.planos.to;

import java.io.Serializable;
import java.util.Date;

import com.ccb.br.pou.planos.enums.TipoAcaoEnum;
import com.ccb.br.pou.planos.enums.TipoProcessoEnum;
import com.google.gson.Gson;

import br.com.bicbanco.bicbase.dto.BaseTO;

public class ProcessoTO extends BaseTO {
	private static final long serialVersionUID = 1L;
	private Integer id;
	private String numeroProcessoCNJ;
	private String numeroProcessoAntigo;
	private String identificadorProcessoSistemaLegado;
	private TipoProcessoEnum orgaoLegal;
	private TipoAcaoEnum tipoAcao;
	private String varaDeOrigem;
	private String comarcaDeOrigem;
	private String UF;
	private Date ajuizadoEm;
	private Date dataProcuracao;
	private String instituicaoNome;

	public ProcessoTO() {
	}

	public Serializable getKey() {
		return id;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getNumeroProcessoCNJ() {
		return numeroProcessoCNJ;
	}

	public void setNumeroProcessoCNJ(String numeroProcessoCNJ) {
		this.numeroProcessoCNJ = numeroProcessoCNJ;
	}

	public String getNumeroProcessoAntigo() {
		return numeroProcessoAntigo;
	}

	public void setNumeroProcessoAntigo(String numeroProcessoAntigo) {
		this.numeroProcessoAntigo = numeroProcessoAntigo;
	}

	public String getIdentificadorProcessoSistemaLegado() {
		return identificadorProcessoSistemaLegado;
	}

	public void setIdentificadorProcessoSistemaLegado(String identificadorProcessoSistemaLegado) {
		this.identificadorProcessoSistemaLegado = identificadorProcessoSistemaLegado;
	}

	public TipoProcessoEnum getOrgaoLegal() {
		return orgaoLegal;
	}

	public void setOrgaoLegal(TipoProcessoEnum orgaoLegal) {
		this.orgaoLegal = orgaoLegal;
	}

	public TipoAcaoEnum getTipoAcao() {
		return tipoAcao;
	}

	public void setTipoAcao(TipoAcaoEnum tipoAcao) {
		this.tipoAcao = tipoAcao;
	}

	public String getVaraDeOrigem() {
		return varaDeOrigem;
	}

	public void setVaraDeOrigem(String varaDeOrigem) {
		this.varaDeOrigem = varaDeOrigem;
	}

	public String getComarcaDeOrigem() {
		return comarcaDeOrigem;
	}

	public void setComarcaDeOrigem(String comarcaDeOrigem) {
		this.comarcaDeOrigem = comarcaDeOrigem;
	}

	public String getUF() {
		return UF;
	}

	public void setUF(String uF) {
		UF = uF;
	}

	public Date getAjuizadoEm() {
		return ajuizadoEm;
	}

	public void setAjuizadoEm(Date ajuizadoEm) {
		this.ajuizadoEm = ajuizadoEm;
	}

	public Date getDataProcuracao() {
		return dataProcuracao;
	}

	public void setDataProcuracao(Date dataProcuracao) {
		this.dataProcuracao = dataProcuracao;
	}

	public String getInstituicaoNome() {
		return instituicaoNome;
	}

	public void setInstituicaoNome(String instituicaoNome) {
		this.instituicaoNome = instituicaoNome;
	}

	public String toString() {
		return new Gson().toJson(this);
	}
}