package com.ccb.br.pou.planos.to;

import br.com.bicbanco.bicbase.dto.BaseTO;
import br.com.bicbanco.bicbase.types.Money;
import com.google.gson.Gson;
import java.io.Serializable;
import java.util.Date;

public class PropostaTO extends BaseTO {
	private static final long serialVersionUID = 1L;
	private String idPropostaBanco;
	private Money valorTotalAcordo;
	private Money valorPoupador;
	private Money valorHonorariosAdvogado;
	private Money valorHonorariosFebrapo;
	private Money valorReembolsoCustas;
	private Integer quantidadeParcelas;
	private Money valorParcela;
	private Date dataPrimeiraParcela;
	private String observacoes;
	private ArquivoTO demonstrativoCalculo;

	public PropostaTO() {
	}

	public Serializable getKey() {
		return idPropostaBanco;
	}

	public String getIdPropostaBanco() {
		return idPropostaBanco;
	}

	public void setIdPropostaBanco(String idPropostaBanco) {
		this.idPropostaBanco = idPropostaBanco;
	}

	public Money getValorTotalAcordo() {
		return valorTotalAcordo;
	}

	public void setValorTotalAcordo(Money valorTotalAcordo) {
		this.valorTotalAcordo = valorTotalAcordo;
	}

	public Money getValorPoupador() {
		return valorPoupador;
	}

	public void setValorPoupador(Money valorPoupador) {
		this.valorPoupador = valorPoupador;
	}

	public Money getValorHonorariosAdvogado() {
		return valorHonorariosAdvogado;
	}

	public void setValorHonorariosAdvogado(Money valorHonorariosAdvogado) {
		this.valorHonorariosAdvogado = valorHonorariosAdvogado;
	}

	public Money getValorHonorariosFebrapo() {
		return valorHonorariosFebrapo;
	}

	public void setValorHonorariosFebrapo(Money valorHonorariosFebrapo) {
		this.valorHonorariosFebrapo = valorHonorariosFebrapo;
	}

	public Money getValorReembolsoCustas() {
		return valorReembolsoCustas;
	}

	public void setValorReembolsoCustas(Money valorReembolsoCustas) {
		this.valorReembolsoCustas = valorReembolsoCustas;
	}

	public Integer getQuantidadeParcelas() {
		return quantidadeParcelas;
	}

	public void setQuantidadeParcelas(Integer quantidadeParcelas) {
		this.quantidadeParcelas = quantidadeParcelas;
	}

	public Money getValorParcela() {
		return valorParcela;
	}

	public void setValorParcela(Money valorParcela) {
		this.valorParcela = valorParcela;
	}

	public Date getDataPrimeiraParcela() {
		return dataPrimeiraParcela;
	}

	public void setDataPrimeiraParcela(Date dataPrimeiraParcela) {
		this.dataPrimeiraParcela = dataPrimeiraParcela;
	}

	public String getObservacoes() {
		return observacoes;
	}

	public void setObservacoes(String observacoes) {
		this.observacoes = observacoes;
	}

	public ArquivoTO getDemonstrativoCalculo() {
		return demonstrativoCalculo;
	}

	public void setDemonstrativoCalculo(ArquivoTO demonstrativoCalculo) {
		this.demonstrativoCalculo = demonstrativoCalculo;
	}

	public String toString() {
		return new Gson().toJson(this);
	}
}