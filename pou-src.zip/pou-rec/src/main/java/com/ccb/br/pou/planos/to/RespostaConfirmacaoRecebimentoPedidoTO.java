package com.ccb.br.pou.planos.to;

import java.io.Serializable;

import com.google.gson.Gson;

import br.com.bicbanco.bicbase.dto.BaseTO;

public class RespostaConfirmacaoRecebimentoPedidoTO extends BaseTO {
	private static final long serialVersionUID = 1L;
	private String guidPedido;

	public RespostaConfirmacaoRecebimentoPedidoTO() {
	}

	public Serializable getKey() {
		return guidPedido;
	}

	public String getGuidPedido() {
		return guidPedido;
	}

	public void setGuidPedido(String guidPedido) {
		this.guidPedido = guidPedido;
	}

	public String toString() {
		return new Gson().toJson(this);
	}
}