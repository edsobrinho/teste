package com.ccb.br.pou.planos.to;

import br.com.bicbanco.bicbase.dto.BaseTO;
import com.google.gson.Gson;
import java.io.Serializable;

public class RespostaOperacaoConfirmarRecebimentoArquivoTO extends BaseTO {
	private static final long serialVersionUID = 1L;
	private String guidPedido;
	private Integer idDocumento;

	public RespostaOperacaoConfirmarRecebimentoArquivoTO() {
	}

	public Serializable getKey() {
		return new Serializable[] { guidPedido, idDocumento };
	}

	public String getGuidPedido() {
		return guidPedido;
	}

	public void setGuidPedido(String guidPedido) {
		this.guidPedido = guidPedido;
	}

	public Integer getIdDocumento() {
		return idDocumento;
	}

	public void setIdDocumento(Integer idDocumento) {
		this.idDocumento = idDocumento;
	}

	public String toString() {
		return new Gson().toJson(this);
	}
}