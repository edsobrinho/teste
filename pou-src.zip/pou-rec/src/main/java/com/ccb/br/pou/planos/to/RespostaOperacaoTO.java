package com.ccb.br.pou.planos.to;

import br.com.bicbanco.bicbase.dto.BaseTO;
import com.ccb.br.pou.planos.enums.RetornoProcessamentoEnum;
import com.google.gson.Gson;
import java.io.Serializable;

public class RespostaOperacaoTO extends BaseTO {
	private static final long serialVersionUID = 1L;
	private String codigoRetorno;
	private RetornoProcessamentoEnum retorno;
	private String descricaoRetorno;

	public RespostaOperacaoTO() {
	}

	public Serializable getKey() {
		return codigoRetorno;
	}

	public String getCodigoRetorno() {
		return codigoRetorno;
	}

	public void setCodigoRetorno(String codigoRetorno) {
		this.codigoRetorno = codigoRetorno;
	}

	public RetornoProcessamentoEnum getRetorno() {
		return retorno;
	}

	public void setRetorno(RetornoProcessamentoEnum retorno) {
		this.retorno = retorno;
	}

	public String getDescricaoRetorno() {
		return descricaoRetorno;
	}

	public void setDescricaoRetorno(String descricaoRetorno) {
		this.descricaoRetorno = descricaoRetorno;
	}

	public String toString() {
		return new Gson().toJson(this);
	}
}