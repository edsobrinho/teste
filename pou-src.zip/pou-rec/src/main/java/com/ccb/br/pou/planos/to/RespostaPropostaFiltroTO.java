package com.ccb.br.pou.planos.to;

import br.com.bicbanco.bicbase.dto.BaseTO;
import com.google.gson.Gson;
import java.io.Serializable;
import java.util.Calendar;

public class RespostaPropostaFiltroTO extends BaseTO {
	private static final long serialVersionUID = 1L;
	private Calendar dataInicio;
	private Calendar dataFim;
	private String guidPedido;

	public RespostaPropostaFiltroTO() {
	}

	public Serializable getKey() {
		return guidPedido;
	}

	public Calendar getDataInicio() {
		return dataInicio;
	}

	public void setDataInicio(Calendar dataInicio) {
		this.dataInicio = dataInicio;
	}

	public Calendar getDataFim() {
		return dataFim;
	}

	public void setDataFim(Calendar dataFim) {
		this.dataFim = dataFim;
	}

	public String getGuidPedido() {
		return guidPedido;
	}

	public void setGuidPedido(String guidPedido) {
		this.guidPedido = guidPedido;
	}

	public String toString() {
		return new Gson().toJson(this);
	}
}