package com.ccb.br.pou.planos.to;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.ccb.br.pou.planos.enums.ContextoEnum;
import com.ccb.br.pou.planos.enums.MotivoNcEnum;
import com.ccb.br.pou.planos.enums.ResultadoAnaliseBPOEnum;
import com.ccb.br.pou.planos.enums.TipoDocumentoEnum;
import com.google.gson.Gson;

import br.com.bicbanco.bicbase.dto.BaseTO;









public class ResultadoAnaliseBPOTO
  extends BaseTO
{
  private static final long serialVersionUID = 1L;
  private Integer idItem;
  private String descricaoItem;
  private ContextoEnum contexto;
  private Integer idChaveContexto;
  private ResultadoAnaliseBPOEnum resultado;
  private TipoDocumentoEnum tipoDocumento;
  private List<MotivoNcEnum> motivosNC;
  
  public ResultadoAnaliseBPOTO() {}
  
  public Serializable getKey()
  {
    return idItem;
  }
  


  public Integer getIdItem()
  {
    return idItem;
  }
  


  public void setIdItem(Integer idItem)
  {
    this.idItem = idItem;
  }
  


  public String getDescricaoItem()
  {
    return descricaoItem;
  }
  


  public void setDescricaoItem(String descricaoItem)
  {
    this.descricaoItem = descricaoItem;
  }
  


  public ContextoEnum getContexto()
  {
    return contexto;
  }
  


  public void setContexto(ContextoEnum contexto)
  {
    this.contexto = contexto;
  }
  


  public Integer getIdChaveContexto()
  {
    return idChaveContexto;
  }
  


  public void setIdChaveContexto(Integer idChaveContexto)
  {
    this.idChaveContexto = idChaveContexto;
  }
  


  public ResultadoAnaliseBPOEnum getResultado()
  {
    return resultado;
  }
  


  public void setResultado(ResultadoAnaliseBPOEnum resultado)
  {
    this.resultado = resultado;
  }
  


  public TipoDocumentoEnum getTipoDocumento()
  {
    return tipoDocumento;
  }
  


  public void setTipoDocumento(TipoDocumentoEnum tipoDocumento)
  {
    this.tipoDocumento = tipoDocumento;
  }
  


  public List<MotivoNcEnum> getMotivosNC()
  {
    if ((motivosNC == null) || (motivosNC.isEmpty())) {
      motivosNC = new ArrayList<MotivoNcEnum>();
    }
    return motivosNC;
  }
  


  public void setMotivosNC(List<MotivoNcEnum> motivosNC)
  {
    this.motivosNC = motivosNC;
  }
  
  public String toString()
  {
    return new Gson().toJson(this);
  }
}