package com.ccb.br.pou.planos.to;

import br.com.bicbanco.bicbase.dto.BaseTO;
import com.ccb.br.pou.planos.enums.MotivoRecusaPedidoEnum;
import com.ccb.br.pou.planos.enums.TipoResultadoAnaliseHabilitacaoEnum;
import com.google.gson.Gson;
import java.io.Serializable;
import java.util.Date;

public class ResultadoAnalisePedidoTO extends BaseTO {
	private static final long serialVersionUID = 1L;
	private String guidPedido;
	private TipoResultadoAnaliseHabilitacaoEnum resultado;
	private MotivoRecusaPedidoEnum motivoRecusaPedido;
	private String subMotivoRecusa;
	private PropostaTO proposta;
	private Date dataAnalise;

	public ResultadoAnalisePedidoTO() {
	}

	public Serializable getKey() {
		return guidPedido;
	}

	public String getGuidPedido() {
		return guidPedido;
	}

	public void setGuidPedido(String guidPedido) {
		this.guidPedido = guidPedido;
	}

	public TipoResultadoAnaliseHabilitacaoEnum getResultado() {
		return resultado;
	}

	public void setResultado(TipoResultadoAnaliseHabilitacaoEnum resultado) {
		this.resultado = resultado;
	}

	public MotivoRecusaPedidoEnum getMotivoRecusaPedido() {
		return motivoRecusaPedido;
	}

	public void setMotivoRecusaPedido(MotivoRecusaPedidoEnum motivoRecusaPedido) {
		this.motivoRecusaPedido = motivoRecusaPedido;
	}

	public String getSubMotivoRecusa() {
		return subMotivoRecusa;
	}

	public void setSubMotivoRecusa(String subMotivoRecusa) {
		this.subMotivoRecusa = subMotivoRecusa;
	}

	public PropostaTO getProposta() {
		return proposta;
	}

	public void setProposta(PropostaTO proposta) {
		this.proposta = proposta;
	}

	public Date getDataAnalise() {
		return dataAnalise;
	}

	public void setDataAnalise(Date dataAnalise) {
		this.dataAnalise = dataAnalise;
	}

	public String toString() {
		return new Gson().toJson(this);
	}
}