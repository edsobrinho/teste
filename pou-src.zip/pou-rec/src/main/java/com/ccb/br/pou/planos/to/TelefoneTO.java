package com.ccb.br.pou.planos.to;

import java.io.Serializable;

import com.google.gson.Gson;

import br.com.bicbanco.bicbase.dto.BaseTO;

public class TelefoneTO extends BaseTO {
	private static final long serialVersionUID = 1L;
	private Integer id;
	private String DDD;
	private String numero;

	public TelefoneTO() {
	}

	public Serializable getKey() {
		return id;
	}

	public String getDDD() {
		return DDD;
	}

	public void setDDD(String dDD) {
		DDD = dDD;
	}

	public String getNumero() {
		return numero;
	}

	public void setNumero(String numero) {
		this.numero = numero;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String toString() {
		return new Gson().toJson(this);
	}
}