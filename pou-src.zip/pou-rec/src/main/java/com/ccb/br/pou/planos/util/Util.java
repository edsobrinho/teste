/**
 * @author opah
 *
 */
package com.ccb.br.pou.planos.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Util {
	public static final String DATA_PATTERN = "yyyyy-mm-dd hh:mm:ss";

	public Util() {
	}

	public static String formatDateToString(Date data, String pattern) {
		return new SimpleDateFormat(pattern).format(data);
	}

	public static Date formatStringToDate(String data, String pattern) {
		Date date = null;
		try {
			date = new SimpleDateFormat(pattern).parse(data);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return date;
	}
}
