/**
 * 
 */
package br.com.bicbanco.pou.dao;

import br.com.bicbanco.bicbase.dao.BaseDAO;
import br.com.bicbanco.pou.dto.ContaPoupancaDTO;

/**
 * @author b090020
 *
 */
public interface ContaPoupancaDAO extends BaseDAO<ContaPoupancaDTO>{

}
