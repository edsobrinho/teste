/**
 * 
 */
package br.com.bicbanco.pou.dao;

import br.com.bicbanco.bicbase.dao.BaseDAO;
import br.com.bicbanco.pou.dto.MovimentoDTO;

/**
 * @author b090020
 *
 */
public interface MovimentoDAO extends BaseDAO<MovimentoDTO>{

}
