/**
 * 
 */
package br.com.bicbanco.pou.dto;

import java.io.Serializable;
import java.util.Date;

import br.com.bicbanco.bicbase.dto.BaseDTO;
import br.com.bicbanco.bicbase.types.Money;

/**
 * @author b090020
 *
 */
public class AniversarioDTO extends BaseDTO{

	/**
	 * 
	 */
	private static final long serialVersionUID = 9191471577437670494L;
	
	private Integer codOrgao;
	private Integer codPlataforma;
	private Integer numConta;
	private Integer numSeq;
	private Date dataAniversario;
	private Money saldo;

	/**
	 * @return the codOrgao
	 */
	public Integer getCodOrgao() {
		return codOrgao;
	}

	/**
	 * @param codOrgao the codOrgao to set
	 */
	public void setCodOrgao(Integer codOrgao) {
		this.codOrgao = codOrgao;
	}

	/**
	 * @return the codPlataforma
	 */
	public Integer getCodPlataforma() {
		return codPlataforma;
	}

	/**
	 * @param codPlataforma the codPlataforma to set
	 */
	public void setCodPlataforma(Integer codPlataforma) {
		this.codPlataforma = codPlataforma;
	}

	/**
	 * @param numConta the numConta to set
	 */
	public void setNumConta(Integer numConta) {
		this.numConta = numConta;
	}

	/**
	 * @return the numConta
	 */
	public Integer getNumConta() {
		return numConta;
	}

	/**
	 * @return the dataAniversario
	 */
	public Date getDataAniversario() {
		return dataAniversario;
	}

	/**
	 * @param dataAniversario the dataAniversario to set
	 */
	public void setDataAniversario(Date dataAniversario) {
		this.dataAniversario = dataAniversario;
	}

	/**
	 * @return the saldo
	 */
	public Money getSaldo() {
		return saldo;
	}

	/**
	 * @param saldo the saldo to set
	 */
	public void setSaldo(Money saldo) {
		this.saldo = saldo;
	}

	/* (non-Javadoc)
	 * @see br.com.bicbanco.bicbase.dto.BaseObject#getKey()
	 */
	@Override
	public Serializable getKey() {
		return new Serializable[]{codOrgao, codPlataforma, numConta, dataAniversario};
	}

	/**
	 * @param numSeq the numSeq to set
	 */
	public void setNumSeq(Integer numSeq) {
		this.numSeq = numSeq;
	}

	/**
	 * @return the numSeq
	 */
	public Integer getNumSeq() {
		return numSeq;
	}


}
