/**
 * 
 */
package br.com.bicbanco.pou.dto;

import java.io.Serializable;
import java.util.Collection;

import br.com.bicbanco.bicbase.dto.BaseDTO;

/**
 *
 */
public class ContaPoupancaDTO extends BaseDTO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 9191471577437670494L;

	private String tipoRegistro;
	private Integer codOrgao;
	private Integer numConta;
	private Integer cpfCnpjRaiz;
	private Integer filialCnpj;
	private Integer cpfCnpjDigito;
	private Integer codigoTitular;
	private Integer codigoCoTitular;
	private String dataAbertura;
	private String dataFechamento;
	private Integer ultimaSeqLancto;
	private Collection<ExtratoContaPoupancaDTO> extratocontaPoupancaDTOList;

	/*
	 * (non-Javadoc)
	 * 
	 * @see br.com.bicbanco.bicbase.dto.BaseObject#getKey()
	 */
	@Override
	public Serializable getKey() {
		return numConta;
	}

	public String getTipoRegistro() {
		return tipoRegistro;
	}

	public void setTipoRegistro(String tipoRegistro) {
		this.tipoRegistro = tipoRegistro;
	}

	public Integer getNumConta() {
		return numConta;
	}

	public void setNumConta(Integer numConta) {
		this.numConta = numConta;
	}

	public Integer getCpfCnpjRaiz() {
		return cpfCnpjRaiz;
	}

	public void setCpfCnpjRaiz(Integer cpfCnpjRaiz) {
		this.cpfCnpjRaiz = cpfCnpjRaiz;
	}

	public Integer getFilialCnpj() {
		return filialCnpj;
	}

	public void setFilialCnpj(Integer filialCnpj) {
		this.filialCnpj = filialCnpj;
	}

	public Integer getCpfCnpjDigito() {
		return cpfCnpjDigito;
	}

	public void setCpfCnpjDigito(Integer cpfCnpjDigito) {
		this.cpfCnpjDigito = cpfCnpjDigito;
	}

	public Integer getCodigoTitular() {
		return codigoTitular;
	}

	public void setCodigoTitular(Integer codigoTitular) {
		this.codigoTitular = codigoTitular;
	}

	public Integer getCodigoCoTitular() {
		return codigoCoTitular;
	}

	public void setCodigoCoTitular(Integer codigoCoTitular) {
		this.codigoCoTitular = codigoCoTitular;
	}

	public String getDataAbertura() {
		return dataAbertura;
	}

	public void setDataAbertura(String dataAbertura) {
		this.dataAbertura = dataAbertura;
	}

	public String getDataFechamento() {
		return dataFechamento;
	}

	public void setDataFechamento(String dataFechamento) {
		this.dataFechamento = dataFechamento;
	}

	public Integer getUltimaSeqLancto() {
		return ultimaSeqLancto;
	}

	public void setUltimaSeqLancto(Integer ultimaSeqLancto) {
		this.ultimaSeqLancto = ultimaSeqLancto;
	}

	public Integer getCodOrgao() {
		return codOrgao;
	}

	public void setCodOrgao(Integer codOrgao) {
		this.codOrgao = codOrgao;
	}

	public void setExtratocontaPoupancaDTOList(Collection<ExtratoContaPoupancaDTO> extratocontaPoupancaDTOList) {
		this.extratocontaPoupancaDTOList = extratocontaPoupancaDTOList;
	}

	public Collection<ExtratoContaPoupancaDTO> getExtratocontaPoupancaDTOList() {
		return extratocontaPoupancaDTOList;
	}

}
