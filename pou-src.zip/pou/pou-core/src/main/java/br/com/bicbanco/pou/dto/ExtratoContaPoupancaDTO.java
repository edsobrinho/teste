/**
 * 
 */
package br.com.bicbanco.pou.dto;

import java.io.Serializable;

import br.com.bicbanco.bicbase.dto.BaseDTO;
import br.com.bicbanco.bicbase.types.Money;

/**
 *
 */
public class ExtratoContaPoupancaDTO extends BaseDTO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 9191471577437670494L;

	private String tipoRegistro;
	private Integer codOrgao;
	private Integer numConta;
	private String dataLancto;
	private Integer seqLancto;
	private String numDocumento;
	private String descrLancto;
	private Integer codLancto;
	private String localLancto;
	private Money valorLancto;
	private String naturezaValorLancto;
	private Money valorSaldo;
	private String naturezaValorSaldo;
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see br.com.bicbanco.bicbase.dto.BaseObject#getKey()
	 */
	@Override
	public Serializable getKey() {
		return numConta;
	}

	public String getTipoRegistro() {
		return tipoRegistro;
	}

	public void setTipoRegistro(String tipoRegistro) {
		this.tipoRegistro = tipoRegistro;
	}

	public Integer getCodOrgao() {
		return codOrgao;
	}

	public void setCodOrgao(Integer codOrgao) {
		this.codOrgao = codOrgao;
	}

	public Integer getNumConta() {
		return numConta;
	}

	public void setNumConta(Integer numConta) {
		this.numConta = numConta;
	}

	public String getDataLancto() {
		return dataLancto;
	}

	public void setDataLancto(String dataLancto) {
		this.dataLancto = dataLancto;
	}

	public Integer getSeqLancto() {
		return seqLancto;
	}

	public void setSeqLancto(Integer seqLancto) {
		this.seqLancto = seqLancto;
	}

	public String getNumDocumento() {
		return numDocumento;
	}

	public void setNumDocumento(String numDocumento) {
		this.numDocumento = numDocumento;
	}

	public String getDescrLancto() {
		return descrLancto;
	}

	public void setDescrLancto(String descrLancto) {
		this.descrLancto = descrLancto;
	}

	public Integer getCodLancto() {
		return codLancto;
	}

	public void setCodLancto(Integer codLancto) {
		this.codLancto = codLancto;
	}

	public String getLocalLancto() {
		return localLancto;
	}

	public void setLocalLancto(String localLancto) {
		this.localLancto = localLancto;
	}

	public Money getValorLancto() {
		return valorLancto;
	}

	public void setValorLancto(Money valorLancto) {
		this.valorLancto = valorLancto;
	}

	public String getNaturezaValorLancto() {
		return naturezaValorLancto;
	}

	public void setNaturezaValorLancto(String naturezaValorLancto) {
		this.naturezaValorLancto = naturezaValorLancto;
	}

	public Money getValorSaldo() {
		return valorSaldo;
	}

	public void setValorSaldo(Money valorSaldo) {
		this.valorSaldo = valorSaldo;
	}

	public String getNaturezaValorSaldo() {
		return naturezaValorSaldo;
	}

	public void setNaturezaValorSaldo(String naturezaValorSaldo) {
		this.naturezaValorSaldo = naturezaValorSaldo;
	}


}
