/**
 * 
 */
package br.com.bicbanco.pou.dto;

import java.io.Serializable;
import java.util.Date;

import br.com.bicbanco.bicbase.dto.BaseDTO;
import br.com.bicbanco.bicbase.types.Money;

/**
 * @author b090020
 *
 */
public class MovimentoDTO extends BaseDTO{

	/**
	 * 
	 */
	private static final long serialVersionUID = -538471113877884262L;
	private AniversarioDTO aniversario;
	private Integer codMovimento;
	private String descMovimento;
	private Date dataLancamento;
	private Money valor;
		
	/**
	 * @return the aniversario
	 */
	public AniversarioDTO getAniversario() {
		return aniversario;
	}

	/**
	 * @param aniversario the aniversario to set
	 */
	public void setAniversario(AniversarioDTO aniversario) {
		this.aniversario = aniversario;
	}

	/**
	 * @return the valor
	 */
	public Money getValor() {
		return valor;
	}

	/**
	 * @param valor the valor to set
	 */
	public void setValor(Money valor) {
		this.valor = valor;
	}

	/**
	 * @return the dataLancamento
	 */
	public Date getDataLancamento() {
		return dataLancamento;
	}

	/**
	 * @param dataLancamento the dataLancamento to set
	 */
	public void setDataLancamento(Date dataLancamento) {
		this.dataLancamento = dataLancamento;
	}
	
	/* (non-Javadoc)
	 * @see br.com.bicbanco.bicbase.dto.BaseObject#getKey()
	 */
	@Override
	public Serializable getKey() {
		// TODO Auto-generated method stub
		return new Serializable[]{aniversario, codMovimento, dataLancamento};
	}

	/**
	 * @param codMovimento the codMovimento to set
	 */
	public void setCodMovimento(Integer codMovimento) {
		this.codMovimento = codMovimento;
	}

	/**
	 * @return the codMovimento
	 */
	public Integer getCodMovimento() {
		return codMovimento;
	}

	/**
	 * @param descMovimento the descMovimento to set
	 */
	public void setDescMovimento(String descMovimento) {
		this.descMovimento = descMovimento;
	}

	/**
	 * @return the descMovimento
	 */
	public String getDescMovimento() {
		return descMovimento;
	}

}
