/**
 * 
 */
package br.com.bicbanco.pou.impl.dao;

import br.com.bicbanco.bicbase.dao.BaseDAOIbatis;
import br.com.bicbanco.pou.dao.AniversarioDAO;
import br.com.bicbanco.pou.dto.AniversarioDTO;

/**
 * @author b090020
 *
 */
public class AniversarioDAOImpl extends BaseDAOIbatis<AniversarioDTO> implements AniversarioDAO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private static final String NAME_SPACE = "aniversario";
	
	@Override
	protected String getNameSpace() {
		return NAME_SPACE;
	}
}
