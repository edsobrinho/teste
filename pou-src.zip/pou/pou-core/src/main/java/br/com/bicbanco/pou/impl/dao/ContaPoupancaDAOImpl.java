/**
 * 
 */
package br.com.bicbanco.pou.impl.dao;

import br.com.bicbanco.bicbase.dao.BaseDAOIbatis;
import br.com.bicbanco.pou.dao.ContaPoupancaDAO;
import br.com.bicbanco.pou.dto.ContaPoupancaDTO;

/**
 * @author b090020
 *
 */
public class ContaPoupancaDAOImpl extends BaseDAOIbatis<ContaPoupancaDTO> implements ContaPoupancaDAO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private static final String NAME_SPACE = "contaPoupanca";
	
	@Override
	protected String getNameSpace() {
		return NAME_SPACE;
	}
}
