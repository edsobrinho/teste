/**
 * 
 */
package br.com.bicbanco.pou.impl.dao;

import br.com.bicbanco.bicbase.dao.BaseDAOIbatis;
import br.com.bicbanco.pou.dao.ExtratoContaPoupancaDAO;
import br.com.bicbanco.pou.dto.ExtratoContaPoupancaDTO;

/**
 * @author b090020
 *
 */
public class ExtratoContaPoupancaDAOImpl extends BaseDAOIbatis<ExtratoContaPoupancaDTO> implements ExtratoContaPoupancaDAO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private static final String NAME_SPACE = "extratoContaPoupanca";
	
	@Override
	protected String getNameSpace() {
		return NAME_SPACE;
	}
}
