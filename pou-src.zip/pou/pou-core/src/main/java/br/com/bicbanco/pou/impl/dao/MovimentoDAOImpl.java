/**
 * 
 */
package br.com.bicbanco.pou.impl.dao;

import br.com.bicbanco.bicbase.dao.BaseDAOIbatis;
import br.com.bicbanco.pou.dao.MovimentoDAO;
import br.com.bicbanco.pou.dto.MovimentoDTO;

/**
 * @author b090020
 *
 */
public class MovimentoDAOImpl extends BaseDAOIbatis<MovimentoDTO> implements
		MovimentoDAO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private static final String NAME_SPACE = "movimento";
	
	@Override
	protected String getNameSpace() {
		return NAME_SPACE;
	}
}
