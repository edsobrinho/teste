package br.com.bicbanco.pou.impl.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import br.com.bicbanco.bicbase.ejb.BicSender;
import br.com.bicbanco.bicbase.exceptions.ServiceException;
import br.com.bicbanco.bicbase.service.BaseService;
import br.com.bicbanco.bicbase.util.FormatUtil;
import br.com.bicbanco.cgp.enums.ConsultaPessoaRelacionamentoEnum;
import br.com.bicbanco.cgp.enums.SituacaoCadastroEnum;
import br.com.bicbanco.cgp.enums.TipoPessoaEnum;
import br.com.bicbanco.cgp.facade.PessoaCGPFacade;
import br.com.bicbanco.cgp.to.PessoaTO;
import br.com.bicbanco.ctt.exceptions.ProdutoClienteContaException;
import br.com.bicbanco.ctt.facade.ProdutoClienteContaFacade;
import br.com.bicbanco.ctt.to.CoTitularProdutoContaTO;
import br.com.bicbanco.ctt.to.ProdutoClienteTO;
import br.com.bicbanco.pou.service.InformacoesContaService;
import br.com.bicbanco.pou.to.InformacoesContaTO;
import br.com.bicbanco.pou.to.MensagemFepScadTO;
import net.sf.layoutParser.processor.LayoutException;
import net.sf.layoutParser.processor.LayoutProcessor;
import net.sf.layoutParser.to.BaseNameSpaceTO;

public class InformacoesContaServiceImpl extends BaseService implements InformacoesContaService {


	/**
	 * 
	 */
	private static final long serialVersionUID = -5170420523363699514L;
	
	private static final Integer TIPO_CONTA_POUPANCA = new Integer(3);
	private static final Integer COD_MODALIDADE_POUPANCA = new Integer(4501);
	private static final String SIGLA_SISTEMA = "POU";
	private static final String MEIO_ORIGEM = "I";
	
	private ProdutoClienteContaFacade produtoClienteContaFacade;
	private PessoaCGPFacade pessoaCGPFacade;
	private BicSender bicSender; 
	
	private static final Logger logger = Logger.getLogger(InformacoesContaServiceImpl.class);

	public List<InformacoesContaTO> listInformacoesConta(Integer codSuc) throws ServiceException{
		List<InformacoesContaTO> result = null;
//		List<ProdutoClienteTO> produtos = produtoClienteContaFacade.findProdutosAtivosTitularByModalidade(codSuc, Collections.singletonList(COD_MODALIDADE_POUPANCA));
		List<ProdutoClienteTO> produtos = mockListProduto();
		if(produtos != null && !produtos.isEmpty()){
			Map<Integer, PessoaTO> mapPessoas = getMapPessoas(produtos);
			result = new ArrayList<InformacoesContaTO>();
			for (ProdutoClienteTO to : produtos) {
				result.add(getInformacoesContaTO(to, mapPessoas));
			}
		}
		return result;
	}	
	
	public InformacoesContaTO getInformacoesConta(Integer codigoOrgao, Integer codSuc, Integer numeroConta) throws ServiceException{
		InformacoesContaTO result = null;
		ProdutoClienteTO to = mockProdutoCliente();//produtoClienteContaFacade.buscarProdutoAtivoByPessoaCodigoOrgaoNumeroConta(codSuc, codigoOrgao, numeroConta);
		Map<Integer, PessoaTO> mapPessoas = getMapPessoas(Collections.singletonList(to));
		result = getInformacoesContaTO(to, mapPessoas);
		return result;
	}
	
	public String getNomePessoa(Integer suc) throws ServiceException{
		String result = null;
		Set<ConsultaPessoaRelacionamentoEnum> tipoFiltro = new HashSet<ConsultaPessoaRelacionamentoEnum>();
		tipoFiltro.add(ConsultaPessoaRelacionamentoEnum.CONTROLE_CADASTRO);
		PessoaTO pessoa = pessoaCGPFacade.findPessoaByCodigo(suc, tipoFiltro);
		if(pessoa != null){
			result = pessoa.getNome();
		}
		return result;
	}
	
	public void insertCoTitular(InformacoesContaTO to) throws ProdutoClienteContaException, ServiceException{
		CoTitularProdutoContaTO coTitularProdutoContaTO = getCoTitularProdutoContaTO(to);
		coTitularProdutoContaTO.setDataAbertura(coTitularProdutoContaTO.getDataAlteracao());
		produtoClienteContaFacade.incluirCoTitularConta(coTitularProdutoContaTO);
		completaInformacoes(to);
		MensagemFepScadTO scad = buildSCAD(to);
		enviarMensagemScadFep(scad);
	}
	
	public void updateCoTitular(InformacoesContaTO to) throws ProdutoClienteContaException, ServiceException{
		CoTitularProdutoContaTO coTitularProdutoContaTO = getCoTitularProdutoContaTO(to);
		coTitularProdutoContaTO.setCodigoCoTitular(to.getSucCoTitularAnterior());
		coTitularProdutoContaTO.setDataEncerramento(coTitularProdutoContaTO.getDataAlteracao());
		produtoClienteContaFacade.encerrarCoTitularConta(coTitularProdutoContaTO);
		coTitularProdutoContaTO.setCodigoCoTitular(to.getSucCoTitular());
		coTitularProdutoContaTO.setDataEncerramento(null);
		coTitularProdutoContaTO.setDataAbertura(coTitularProdutoContaTO.getDataAlteracao());
		produtoClienteContaFacade.incluirCoTitularConta(coTitularProdutoContaTO);
		completaInformacoes(to);
		MensagemFepScadTO scad = buildSCAD(to);
		enviarMensagemScadFep(scad);
	}
	
	public void deleteCoTitular(InformacoesContaTO to) throws ProdutoClienteContaException, ServiceException{
		CoTitularProdutoContaTO coTitularProdutoContaTO = getCoTitularProdutoContaTO(to);
		coTitularProdutoContaTO.setDataAlteracao(new Date());
		coTitularProdutoContaTO.setDataEncerramento(new Date());
		produtoClienteContaFacade.encerrarCoTitularConta(coTitularProdutoContaTO);
		to.zerarDadosCoTitular();
		completaInformacoes(to);
		MensagemFepScadTO scad = buildSCAD(to);
		enviarMensagemScadFep(scad);
	}
	
	private void completaInformacoes(InformacoesContaTO to) throws ServiceException{
		Map<Integer, PessoaTO> mapPessoas = getMapPessoas(to);
		PessoaTO titular = mapPessoas.get(to.getSucTitular());
		if(titular.getAgenciaResponsavel() != null && titular.getAgenciaResponsavel().getCodigoGerente() != null){
			to.setCodGerente(titular.getAgenciaResponsavel().getCodigoGerente());
		}else{
			to.setCodGerente(new Integer(0));
		}
		if(TipoPessoaEnum.PESSOA_FISICA.equals(titular.getTipoPessoa())){
			to.setIsPFTitular(Boolean.TRUE);
		}else if(TipoPessoaEnum.PESSOA_JURIDICA.equals(titular.getTipoPessoa())){
			to.setIsPFTitular(Boolean.FALSE);
		}
		if(titular.getPessoaFisica() != null && titular.getPessoaFisica().getDataNascimento() != null){
			to.setDataNascimentoTitular(titular.getPessoaFisica().getDataNascimento());
		}
		to.setNomeTitular(titular.getNome());
		to.setCpfCnpjTitular(getCPFCNPJ(titular, to.getIsPFTitular()));
		to.setIsClienteCCBTitular(StringUtils.equalsIgnoreCase("S", titular.getIndicadorClienteCCB()));
		to.setIsDadosFATCAInformadoTitular(StringUtils.equalsIgnoreCase("S", titular.getDadosFATCAInformado()));
		to.setIsClienteVencidoTitular(SituacaoCadastroEnum.VENCIDO.equals(titular.getSituacaoCadastro()));
		if(to.getSucCoTitular() != null){
			PessoaTO coTitular = mapPessoas.get(to.getSucCoTitular());
			if(coTitular.getPessoaFisica() != null && coTitular.getPessoaFisica().getDataNascimento() != null){
				to.setDataNascimentoCoTitular(coTitular.getPessoaFisica().getDataNascimento());
			}
			to.setNomeCoTitular(coTitular.getNome());
			if(TipoPessoaEnum.PESSOA_FISICA.equals(coTitular.getTipoPessoa())){
				to.setIsPFCoTitular(Boolean.TRUE);
			}else if(TipoPessoaEnum.PESSOA_JURIDICA.equals(coTitular.getTipoPessoa())){
				to.setIsPFCoTitular(Boolean.FALSE);
			}
			to.setCpfCnpjCoTitular(getCPFCNPJ(coTitular, to.getIsPFCoTitular()));
			
			to.setIsClienteCCBCoTitular(StringUtils.equalsIgnoreCase("S", coTitular.getIndicadorClienteCCB()));
			to.setIsDadosFATCAInformadoCoTitular(StringUtils.equalsIgnoreCase("S", coTitular.getDadosFATCAInformado()));
			to.setIsClienteVencidoTitular(SituacaoCadastroEnum.VENCIDO.equals(coTitular.getSituacaoCadastro()));
		}
	}
	
	private CoTitularProdutoContaTO getCoTitularProdutoContaTO(InformacoesContaTO to){
		CoTitularProdutoContaTO result = new CoTitularProdutoContaTO();
		result.setDataAlteracao(new Date());
		result.setCodigoCoTitular(to.getSucCoTitular());
		result.setCodigoPessoa(to.getSucTitular());
		result.setCodigoOrgao(to.getCodOrgao());
		result.setCodigoPlataforma(to.getCodPlataforma());
		result.setNumeroConta(to.getNumConta());
		result.setTipoConta(TIPO_CONTA_POUPANCA);
		result.setDataAbertura(to.getDataAbertura());
		return result;
	}
	
	private InformacoesContaTO getInformacoesContaTO(ProdutoClienteTO to, Map<Integer, PessoaTO> mapPessoas){
		InformacoesContaTO result = new InformacoesContaTO();
		result.setCodOrgao(to.getCodigoOrgao());
		result.setCodPlataforma(to.getCodigoPlataforma());
		result.setNumConta(to.getNumeroConta());
		result.setDataAbertura(to.getDataAbertura());
		result.setSucTitular(to.getCodigoPessoa());
		PessoaTO pessoaTitular = mapPessoas.get(to.getCodigoPessoa());
		if(pessoaTitular != null){
			result.setNomeTitular(pessoaTitular.getNome());
		}
		result.setSucCoTitularAnterior(to.getCodigoPessoaCoTitular());
		result.setSucCoTitular(to.getCodigoPessoaCoTitular());
		if(to.getCodigoPessoaCoTitular() != null){
			PessoaTO pessoaCoTitular = mapPessoas.get(to.getCodigoPessoaCoTitular());
			if(pessoaCoTitular != null){
				result.setNomeCoTitular(pessoaCoTitular.getNome());
			}
		}
		return result;
	}
	
	private Map<Integer, PessoaTO> getMapPessoas(List<ProdutoClienteTO> produtos) throws ServiceException{
		Set<Integer> codsPessoa = new HashSet<Integer>();
		Map<Integer, PessoaTO> result = new HashMap<Integer, PessoaTO>();
		for (ProdutoClienteTO to : produtos) {
			codsPessoa.add(to.getCodigoPessoa());
			if(to.getCodigoPessoaCoTitular() != null){
				codsPessoa.add(to.getCodigoPessoaCoTitular());
			}
		}
		Set<ConsultaPessoaRelacionamentoEnum> tipoFiltro = new HashSet<ConsultaPessoaRelacionamentoEnum>();
		List<PessoaTO> pessoas = pessoaCGPFacade.findPessoasByCodigo(codsPessoa, tipoFiltro);
		for (PessoaTO pessoa : pessoas) {
			result.put(pessoa.getCodigoPessoa(), pessoa);
		}
		return result;
	}
	
	private Map<Integer, PessoaTO> getMapPessoas(InformacoesContaTO to) throws ServiceException{
		Set<Integer> codsPessoa = new HashSet<Integer>();
		Map<Integer, PessoaTO> result = new HashMap<Integer, PessoaTO>();
		codsPessoa.add(to.getSucTitular());
		if(to.getSucCoTitular() != null){
			codsPessoa.add(to.getSucCoTitular());
		}
		Set<ConsultaPessoaRelacionamentoEnum> tipoFiltro = new HashSet<ConsultaPessoaRelacionamentoEnum>();
		tipoFiltro.add(ConsultaPessoaRelacionamentoEnum.AGENCIA_RESPONSAVEL);
		tipoFiltro.add(ConsultaPessoaRelacionamentoEnum.PESSOA_FISICA);
		tipoFiltro.add(ConsultaPessoaRelacionamentoEnum.CPF_CNPJ);
		tipoFiltro.add(ConsultaPessoaRelacionamentoEnum.CONTROLE_CADASTRO);
		tipoFiltro.add(ConsultaPessoaRelacionamentoEnum.GRUPO_FATCA_COMPLETO);
		List<PessoaTO> pessoas = pessoaCGPFacade.findPessoasByCodigo(codsPessoa, tipoFiltro);
		for (PessoaTO pessoa : pessoas) {
			result.put(pessoa.getCodigoPessoa(), pessoa);
		}
		return result;
	}
	
	private MensagemFepScadTO buildSCAD(InformacoesContaTO to) {
		MensagemFepScadTO scad = new MensagemFepScadTO();
		Calendar cal = new GregorianCalendar();
		String nsu = cal.get(Calendar.HOUR_OF_DAY) + "" + cal.get(Calendar.MINUTE) + "" + cal.get(Calendar.SECOND);
		scad.setIdentificacaoCanal(SIGLA_SISTEMA); //Identifica��o do Canal   
		scad.setAnoMovimento(cal.get(Calendar.YEAR));//Data do Movimento AAAA
		scad.setMesMovimento(cal.get(Calendar.MONTH) + 1);//Data do Movimento MM
		scad.setDiaMovimento(cal.get(Calendar.DAY_OF_MONTH)); //Data do Movimento DD 
		scad.setNumeroSequencialUnico(new Integer(nsu)); //N�mero Sequ�ncial �nico Dentro da Data
		scad.setMeioOrigem(MEIO_ORIGEM); //Meio Origem
		scad.setCodigoAgencia(to.getCodOrgao()); //C�digo da Ag�ncia 
		scad.setNumeroConta(to.getNumConta() % 100000000); //N�mero da Conta
		scad.setCodigoGerente(to.getCodGerente()); //C�digo do Gerente
		if(to.getIsPFTitular() != null && to.getIsPFTitular()){
			scad.setTipoPessoa("F");
		}else if(to.getIsPFTitular() != null && !to.getIsPFTitular()){
			scad.setTipoPessoa("J");
		}else{
			scad.setTipoPessoa(" ");
		}
		scad.setCodigoPrimeiroTitular(to.getSucTitular()); //SUC do 1o Titular
		scad.setDataNascimentoPrimeiroTitular(to.getDataNascimentoTitular()); //Data de Nascimento 1o Titular no formato AAAAMMDD
		scad.setNomePrimeiroTitular(getMaxSizeString(to.getNomeTitular(), 40)); //Nome do 1o Titular
		scad.setCpfCnpjPrimeiroTitular(to.getCpfCnpjTitular()); //CPF/CNPJ do 1o Titular
		if (to.getIsClienteCCBTitular() != null && to.getIsClienteCCBTitular()) {
			scad.setIndicadorTipoClientePrimeiroTitular("A");
		}else{
			scad.setIndicadorTipoClientePrimeiroTitular("");
		}
		if(to.getIsDadosFATCAInformadoTitular() != null && to.getIsDadosFATCAInformadoTitular()){
			scad.setIndicadorFatcaPrimeiroTitular("0");
		}else{
			scad.setIndicadorFatcaPrimeiroTitular("1");
		}
		if(to.getIsClienteVencidoTitular() != null && to.getIsClienteVencidoTitular()){
			scad.setIndicadorVencimentoCadastralPrimeiroTitular("1");
		}else{
			scad.setIndicadorVencimentoCadastralPrimeiroTitular("0");
		}
		if(to.getSucCoTitular() != null){
			scad.setCodigoSegundoTitular(to.getSucCoTitular()); //SUC do 2o Titular
			scad.setDataNascimentoSegundoTitular(to.getDataNascimentoCoTitular()); //Data de Nascimento 2o Titular no formato AAAAMMDD
			scad.setNomeSegundoTitular(getMaxSizeString(to.getNomeCoTitular(), 40)); //Nome do 2o Titular
			scad.setCpfCnpjSegundoTitular(to.getCpfCnpjCoTitular()); //CPF/CNPJ do 2o Titular
			if (to.getIsClienteCCBCoTitular() != null && to.getIsClienteCCBCoTitular()) {
				scad.setIndicadorTipoClienteSegundoTitular("A");
			}else{
				scad.setIndicadorTipoClienteSegundoTitular("");
			}
			if(to.getIsDadosFATCAInformadoCoTitular() != null && to.getIsDadosFATCAInformadoCoTitular()){
				scad.setIndicadorFatcaSegundoTitular("0");
			}else{
				scad.setIndicadorFatcaSegundoTitular("1");
			}
			if(to.getIsClienteVencidoCoTitular() != null && to.getIsClienteVencidoCoTitular()){
				scad.setIndicadorVencimentoCadastralSegundoTitular("1");
			}else{
				scad.setIndicadorVencimentoCadastralSegundoTitular("0");
			}
		}
		scad.setIndicadorTalaoCheques("0");
	    
		return scad;
	}
	
	public void enviarMensagemScadFep(MensagemFepScadTO mensagem) throws ServiceException{
		try
		{
			BaseNameSpaceTO nameSpace = new BaseNameSpaceTO();
			nameSpace.setNamePrefix("layoutScad");
			nameSpace.setNameSufix("SCAD");

			LayoutProcessor processor = LayoutProcessor.newInstanceFor(nameSpace);
			String msgFep = StringUtils.substring(processor.format(mensagem), 0, 196);
			logger.info("Enviando mensagem ao FEP: " + msgFep);
			bicSender.sendMessage(FormatUtil.retirarAcentuacao(msgFep));
		}
		catch (LayoutException e)
		{
			throw new ServiceException("Erro ao enviar a mensagem para o FEP.", e);
		}
	}
	
	private String getMaxSizeString(String aux, int maxSize){
		String result = null;
		if(aux != null){
			int tamanho = aux.length() <= maxSize ? aux.length() : maxSize;
			result = aux.substring(0, tamanho);
		}
		return result;
	}
	
	private Long getCPFCNPJ(PessoaTO pessoa, boolean isPF){
		String strCpfCnpj = String.format("%02d", pessoa.getNumeroDigitoCpfCnpj());
		if(!isPF){
			strCpfCnpj = String.format("%04d", pessoa.getNumeroFilialCpjCnpj()) + strCpfCnpj;
		}
		strCpfCnpj = pessoa.getNumeroRaizCpfCnpj() + strCpfCnpj;
		return new Long(strCpfCnpj);
	}
	
	private List<ProdutoClienteTO> mockListProduto(){
		
		List<ProdutoClienteTO> produtos = new ArrayList<ProdutoClienteTO>();
		
		ProdutoClienteTO produto = null;
		
		for (int i = 0; i < 100; i++) {
		
			produto = new ProdutoClienteTO();
			
			produto.setCodigoPessoa(aleotorioCodPessoa());
			produto.setCodigoPessoaCoTitular(aleotorioCodPessoa());
			
			produto.setCodigoModalidade(COD_MODALIDADE_POUPANCA);
			produto.setCodigoOrgao(aleatorioEntre(1, 99));
			produto.setCodigoOrgaoContaVinculada(aleatorioEntre(1, 99));
			
			produto.setNumeroConta(aleatorioEntre(1, 999999));
			produto.setNumeroSequenciaContrato(BigDecimal.valueOf(aleatorioEntre(1, 99999999)));
			
			produto.setCodigoPlataforma(aleatorioEntre(1, 9999));
			produto.setDescricaoAgencia(getNomeAleatorio());
			
			produto.setDataInclusaoRegistro(new Date());
			produto.setDataAbertura(new Date());
			
			produtos.add(produto);
		}
		
		return produtos;
	}
	
	private ProdutoClienteTO mockProdutoCliente(){
		
		List<ProdutoClienteTO> produtos = mockListProduto();	
		ProdutoClienteTO produto = produtos.get(aleatorioEntre(0, 99));
	
		return produto;
	}

	public String getNomeAleatorio() {
		
		String[] razoesSocial = { "AKATE YIKISYAI I SIJ KTVE", "AKIKIS I SEAKESEIS AKV I YIK KTVE", "AKIKIS TIYAVIS",
				"AKIKIS TIYAVIS S E", "AKSE YIKSTSETISE VI IZSES KTVE", "AKTISKIVAEK SASTIKES KTVE",
				"ATS ZSESAK TIYKIKISAE I SISVAYIS", "ESIE YIKISYAI I SIJSIS KTVE", "IKSIK TISSIASE VE SAKVE",
				"ISIJSISS S/Y KTVE", "ISIZ EVAYIKE KTVE", "ISJIKAI  KIKSIK TESIS", "KEAZ ISISAI TIXIASE",
				"KIESAVEKVI SEZIKI VIS SEKTIS", "KTSZ SISV YIK VI IKITSIKAYIS KTVE", "S V AKYISJISEYIIS",
				"SAYESVI IKAVIASE VI EKVSEVI", "YVK IKITSI YIKTSEK VAST KTVE", "EVIKIAKI EKVIS JAKTI YISTE",
				"IVIKI JKIES", "(ISJIKAI) YKIKIKTI VE SAKVE VAKHES", "00750792/0001-11", "01 ITAYAI VI KITES",
				"05 VI KEAI JESTAYAJEYIIS KTVE", "0KAKJAI SAZIASI YHEJEVIKSI", "0SEKVEVIS VI SEKTEKE TAKHI",
				"0SSE YIKEKISI", "1  YEST VI SIS VI AKIVIS EKI IS SSE", "1 K YIK VI SIE I EST VI YIESI KTVE",
				"1 SS T VYS YESKIS E S V EEKAYAKI", "1 TEZIKAIKETI VI JSITISTI, SISASTSI", "1 TEZIKAIKETI VI KITES",
				"1 YESTISAI VI SIS.VI AKIV.SEKTIS", "1+1 AKJISTEVISE I IXJISTEVISE KTVE",
				"1� SISVAYI KITESAEK I SISASTSEK VI YEAEZE KT", "10 KISASTAYE I TSEKSJISTIS KTVE",
				"10 TEZIKAIKETI VI KITES", "10 VI IETEZSI JESTAYAJEYIIS I IKJSIIKVAKIKTIS S.E", "1000 KESYES SEK",
				"1001 AKV EST VI ZISSEYHE KTVE", "101 IKJSIIKVAKIKTIS I JEST KTVE", "101 KAX YIKY. I JSIKIKV. KTVE",
				"1081 - YIKISYAI VI KIVIAS KTVE", "11 E YIKISYAI VI KEKETETESEVIS KTVE",
				"12 VI SITIKZSI ESSIJIYEESAE AKYI I IKJSIIKVAKIKTIS", "13 YESTISAI VI KITES",
				"147 EETI JIYES VIKAVISY KTVE", "15 ITAYAI VI KITES YESTISAI", "15 TEZIKAEI VI KITES VE YEJATEK  SJ",
				"15 VI KIVIKZSI KIV I ETAK KTVE", "164 JESTAYAJEYIIS S/E", "19 VI TIVISIASI IKJ JEST KTVE",
				"1981 JESTAYAJEYIIS KTVE", "1986SEZSAIK KIAS VI KIKKI",
				"1E.ASSIJE JSISZATISAEKE AKVIJIKVIKTI VI YEKJAKES", "1ITAYAEK VI SISASTSI VI AKIVIAS",
				"2 ASKEIS JSIVETIS VI JITSIKII KTVE", "2 ITAYAI VAST.VI JSITISTI VI TATEKI",
				"2 JEJEI YIKISYAI VI VIAY KTVE", "2 K YIKK TSETES I VISV. KTVE", "2 KK VIYISEYIIS KTVE",
				"2 V EVK I JESTAYAJEYIIS KTVE", "2 YESTISAI VI JSITISTIS", "2.0 HITIAS S.E", "202 JESTAYAJEYIIS S/E",
				"23 KITISS YIKISYAI VI VIAYEKIS KTVE", "23 TEZIKAEI VI KITES", "28 SSEES YIK. VASTS. I SIJSIS. KTVE",
				"2EYT YIKSTSEYIIS KTVE", "2J SISVAYIS I TSEKSJISTIS KTVE KI", "2J YIKISYAI VI VIAY KTVE KI",
				"2K JESTAYAJEYIIS KTVE", "2K KEKHESAE I YIKTIYYIIS KTVE", "2KZS JESTAYAJEYIIS KTVE",
				"2S SISVAYIS TIYKAYIS KTVE", "2SK YIKISYAI AKV VI ZIKZES HAVSEEKAYES", "2SY YIKSEKTISAE S Y KTVE KI",
				"2TKS YIKISYAI AKVESTSAE I SISVAYIS VI JKIES KTVE", "2TKS YIKISYAI I SISVAYIS VI JKIES KTVE KI",
				"2V ESSIJIYEESAE KTVE", "2ZYEJATEK S/E", "3 ASKEIS JESTAYAJEYIIS KTVE", "3 I KITEAS",
				"3 S AKTISKETAYE KTVE", "3 SAK-SIK AKT KIS VI TSITES EET KTV", "3 W SIKYEYIIS KE WIZ KTVE",
				"3 YISEYIIS YIK. IXJ. KTVE", "3000 SYHETIS SIEV YIKJEKY", "31 VI JEKIASI IKJSIIKV AKIZ KTVE",
				"3E IKJSIIKV. AKIZ. KTVE", "3E IKJSIIKVAKIKTIS AKIZAKAESAIS KTV", "3E JSIV. QEAKAYIS VI KAKJIZE KTVE",
				"3E KESKITAKS I JSIVEYIIS KTVE", "3E VITISSIKTIS I VISAKTITEKTIS KTVE", "3E YISES I VITISSIKTIS KTVE",
				"3J AKVISTAKIKTIS I JESTAYAJEYIIS SE", "3J EKAKIKTIS KTVE KI", "3J JESTAYAJEYIIS SIYAEAS KTVE" };
		
		return razoesSocial[aleatorioEntre(0,97)];
	}
	
	public int aleotorioCodPessoa() {

		int[] codigos = { 1274080, 1273564, 1268186, 1268087, 1267937, 1267823, 1266601, 1265476, 1265282, 1264393,
				1262835, 1261973, 1261535, 1261438, 1261437, 1261419, 1260536, 1260517, 1260513, 1260256, 1259832,
				1258056, 1256730, 1256326, 1256320, 1256312, 1226662, 1226095, 1225405, 1225192, 1224386, 1223742,
				1222730, 1222479, 1220914, 1219778, 1218710, 1217182, 1215336, 1215311, 1214588, 1214182, 1213959,
				1213529, 1213525, 1212990, 1212254, 1212210, 1212084, 1211976, 1206045, 1206039, 1206036, 1204364,
				1203803, 1203628, 1202698, 1191278, 1191271, 1190905, 1189455, 1187655, 1187366, 1186517, 1183974,
				1183666, 1183658, 1183235, 1182244, 1181921, 1180135, 1179148, 1178057, 1177746, 1174238, 1173980,
				1173899, 1173643, 1173640, 1173457, 1171333, 1170601, 1170597, 1170413, 1169923, 1169757, 1166464,
				1165806, 1165805, 1165804, 1165803, 1165801, 1165800, 1165799, 1165798, 1165620, 1164652, 1164264,
				1162538, 1161167, 1158540, 1158539, 1155337, 1154921, 1154847, 1152191, 1149730, 1149724, 1149720,
				1149601, 1149462, 1149460, 1148312, 1148306, 1148305, 1148303, 1147050, 1146862, 1146632, 1146536,
				1146530, 1146308, 1146238, 1145983, 1145976, 1145874, 1145504, 1144692, 1144583, 1143702, 1143349,
				1143112, 1141151, 1141139, 1137196, 1136443, 1136432, 1133645, 1132964, 1132962, 1131178, 1131167,
				1129542, 1127923, 1126554, 1126547, 1126014, 1125914, 1125195, 1125142, 1123690, 1122656, 1122426,
				1122424, 1122266, 1122246, 1121998, 1121814, 1121811, 1121810, 1121807, 1121804, 1121442, 1121223,
				1120291, 1119356, 1118894, 1118656, 1118642, 1118474, 1117491, 1117486, 1117083, 1116897, 1116350,
				1115268, 1114983, 1114830, 1114402, 1114400, 1114095, 1113636, 1113625, 1112427, 1111050, 1109922,
				1109916, 1109906, 1109201, 1109184, 1109175, 1108462, 1107579, 1107363, 1107361, 1107353, 1107352,
				1107126, 1106933, 1106932, 1106931, 1106721, 1106693, 1105845, 1105834, 1105400, 1105397, 1105131,
				1104984, 1104933, 1104573, 1104130, 1103930, 1103744, 1103716, 1103645, 1103411, 1103409, 1103406,
				1103404, 1103402, 1103400, 1103398, 1101356, 1101354, 1101352, 1101350, 1101348, 1101344, 1101342,
				1101319, 1101318, 1101316, 1101308, 1101306, 1101304, 1101291, 1101286, 1100629, 1100628, 1099869,
				1099865, 1099863, 1099860, 1099459, 1099458, 1099456, 1099454, 1099451, 1099449, 1099447, 1099445,
				1099443, 1099441, 1099437, 1098628, 1098143, 1098135, 1097720, 1097718, 1097716, 1097712, 1097710,
				1097708, 1097702, 1097699, 1097697, 1097691, 1097684, 1097442, 1097232, 1096826, 1095649, 1095641,
				1094860, 1094833, 1094832, 1094637, 1094633, 1094631, 1094629, 1094627, 1094625, 1094620, 1094617,
				1094611, 1094607, 1094605, 1094603, 1094601, 1094599, 1094597, 1094595, 1094593, 1094591, 1094589,
				1094586, 1094584, 1094449, 1094435, 1094195, 1094186, 1094062, 1093925, 1093838, 1093800, 1093794,
				1093775, 1093431, 1092742, 1092182, 1092180, 1091945, 1091898, 1091414, 1091303, 1091075, 1091073,
				1091047, 1090675, 1089607, 1089310, 1089301, 1088619, 1088341, 1088332, 1088292, 1087897, 1087874,
				1087178, 1087170, 1087164, 1086770, 1086722, 1086189, 1085492, 1085207, 1084528, 1083924, 1083048,
				1082296, 1082286, 1082266, 1082254, 1081980, 1081931, 1081909, 1081379, 1081370, 1081128, 1080594,
				1080150, 1079961, 1079953, 1079907, 1079290, 1078913, 1078905, 1078710, 1078377, 1078355, 1078337,
				1078321, 1077961, 1077936, 1077777, 1077775, 1077221, 1077208, 1077189, 1077181, 1077061, 1077051,
				1077049, 1077046, 1077045, 1077041, 1076653, 1076636, 1076188, 1074250, 1073548, 1073540, 1073521,
				1073520, 1072684, 1072676, 1072660, 1072658, 1072016, 1072001, 1071999, 1069490, 1069477, 1067022,
				1067012, 1064497, 1064055, 1064054, 1063837, 1063823, 1063802, 1063397, 1063383, 1063380, 1063235,
				1063233, 1063231, 1063218, 1063212, 1063209, 1062746, 1062743, 1062710, 1062124, 1062115, 1061556,
				1061549, 1061537, 1061363, 1061360, 1061348, 1061346, 1061344, 1061131, 1061126, 1061123, 1060969,
				1060965, 1060961, 1060953, 1060951, 1060763, 1060752, 1060281, 1060279, 1060277, 1060275, 1059079,
				1059042, 1059036, 1058470, 1057823, 1057779, 1057437, 1057415, 1057212, 1057188, 1057179, 1057000,
				1056998, 1056743, 1055846, 1055837, 1055134, 1055111, 1055094, 1054818, 1054178, 1053968, 1053956,
				1053946, 1053772, 1053743, 1053437, 1053409, 1053396, 1052942, 1052698, 1052696, 1052695, 1052679,
				1044830, 1043767, 1043764, 1041834, 1041792, 1040849, 1040847, 1037544, 1034710, 1034699, 1033327,
				1032218, 1028740, 1028705, 1028092, 1027533, 1027508, 1027287, 1027285, 1027283, 1027034, 1027026,
				1026865, 1026820, 1026610, 1026487, 1025937, 1025930, 1025914, 1025536, 1025390, 1025361, 1025259,
				1025257, 1025255, 1025013, 1025011, 1024839, 1024464, 1024429, 1024269, 1023607, 1022776, 1021927,
				1020930, 1020416, 1019192, 1019182, 1018801, 1018776, 1018201, 1018194, 1018170, 1017774, 1017769,
				1017766, 1017242, 1017229, 1017227, 1017225, 1017223, 1017221, 1017219, 1017217, 1017215, 1016303,
				1016300, 1016298, 1016296, 1016294, 1015898, 1015337, 1015326, 1014874, 1014845, 1014443, 1014441,
				1013165, 1012644, 1011519, 1011515, 1011508, 1010936, 1009719, 1009676, 1009092, 1009090, 1009088,
				1008617, 1007849, 1007404, 1007384, 1006384, 1005901, 1005486, 1005484, 1004935, 1004918, 1004621,
				1004617, 1004612, 1003555, 1003552, 1003249, 1002878, 1002570, 1002536, 1002533, 1002531, 1001881,
				1001857, 1001840, 1001826, 1001530, 1001511, 1001508, 1001496, 1001203, 1001178, 1000113, 1000109,
				1000010, 999826, 999693, 999340, 999335, 999333, 999122, 998936, 998822, 998814, 998812, 998796, 998630,
				998627, 998617, 998509, 998336, 998329, 998103, 997939, 997935, 997932, 997923, 997795, 997791, 997712,
				997649, 997533, 997405, 997288, 997266, 997157, 997136, 997134, 997132, 997130, 997128, 997126, 997124,
				997122, 997023, 996765, 996759, 996735, 996734, 996538, 996530, 996357, 996355, 996353, 996351, 996349,
				996345, 996331, 996324, 996208, 996195, 996189, 996049, 995936, 995781, 995776, 995568, 995555, 995479,
				995251, 995046, 995038, 995021, 995017, 994709, 994695, 994058, 993872, 993868, 993849, 993552, 993390,
				993380, 993179, 992977, 992973, 992688, 992685, 992352, 992132, 991797, 991104, 990752, 990729, 990709,
				990708, 990701, 990520, 990459, 990032, 989853, 989832, 989821, 989807, 989546, 989301, 989287, 988984,
				988756, 988753, 988745, 988551, 988515, 988205, 988177, 987909, 987533, 987528, 987522, 987125, 987087,
				987077, 986916, 986867, 986579, 986568, 986548, 986536, 986534, 986533, 986527, 986515, 986194, 986192,
				985855, 985847, 985818, 985677, 985639, 985380, 985060, 985040, 985038, 984869, 984719, 984695, 984690,
				984531, 984290, 984270, 984127, 983943, 983868, 983678, 983666, 983282, 983280, 983149, 983147, 982930,
				982926, 982893, 982885, 982881, 982875, 982681, 982623, 982615, 982372, 982157, 982155, 982146, 982134,
				981460, 981017, 980995, 980817, 980816, 980783, 980572, 980547, 980311, 980291, 980284, 979842, 979727,
				979709, 979355, 979196, 979069, 978943, 978733, 978699, 978532, 978451, 978432, 978430, 978228, 978012,
				978010, 977981, 977979, 977977, 977975, 977973, 977717, 977563, 977555, 977553, 977551, 977374, 977367,
				977264, 977258, 977255, 977240, 977238, 977236, 977234, 977232, 977115, 977093, 976926, 976740, 976727,
				976555, 976547, 976545, 976543, 976541, 976539, 976537, 976535, 976533, 976531, 976529, 976525, 976517,
				976513, 976332, 976329, 976327, 976159, 976152, 975978, 975955, 975939, 975911, 975654, 975640, 975509,
				975462, 975009, 974748, 974723, 974720, 974509, 974506, 974502, 974204, 974189, 974136, 974123, 973559,
				973535, 973519, 973508, 973498, 973241, 973090, 973074, 973058, 973052, 972825, 972544, 972516, 972217,
				971915, 971892, 971873, 971712, 971488, 971228, 971227, 971217, 970516, 970491, 970465, 970452, 970185,
				970167, 970119, 969736, 969436, 969430, 968848, 968597, 968559, 967891, 967835, 967613, 967593, 967221,
				967215, 967175, 966889, 966435, 966425, 966162, 966035, 966024, 965852, 965736, 965724, 965722, 965720,
				965490, 965152, 965148, 965138, 964904, 964765, 964442, 964422, 964323, 964317, 964111, 964063, 962942,
				962916, 962555, 962367, 962359, 962352, 962347, 962343, 962298, 962203, 962120, 962104, 961975, 961965,
				961877, 961758, 961595, 961217, 959799, 959693, 959616, 959614, 959612, 959610, 959608, 959606, 959604,
				959602, 959600, 959488, 959357, 957641, 957633, 957631, 957628, 957626, 957623, 957616, 957594, 956976,
				956972, 956960, 956952, 956932, 956927, 955804, 955797, 955131, 955107, 955074, 953929, 953928, 953919,
				953739, 953036, 953023, 952391, 952384, 952366, 952082, 952052, 951800, 951796, 951606, 951459, 951456,
				951455, 951430, 951424, 951419, 951406, 951389, 951384, 951287, 951278, 951245, 951244, 951242, 951057,
				951054, 951041, 950993, 950962 };

		return codigos[aleatorioEntre(0, 999)];
	}
	
	public int aleatorioEntre(int min, int max) {
		
		Random rand = new Random();
		
		return min + rand.nextInt(max);
	}
	
	public void setProdutoClienteContaFacade(ProdutoClienteContaFacade produtoClienteContaFacade) {
		this.produtoClienteContaFacade = produtoClienteContaFacade;
	}

	public void setPessoaCGPFacade(PessoaCGPFacade pessoaCGPFacade) {
		this.pessoaCGPFacade = pessoaCGPFacade;
	}

	public void setBicSender(BicSender bicSender) {
		this.bicSender = bicSender;
	}
}
