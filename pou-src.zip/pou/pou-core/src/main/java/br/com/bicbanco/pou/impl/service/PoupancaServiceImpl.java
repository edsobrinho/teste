/**
 * 
 */
package br.com.bicbanco.pou.impl.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;

import org.apache.log4j.Logger;
import org.springframework.util.Assert;

import br.com.bicbanco.bicbase.exceptions.DAOException;
import br.com.bicbanco.bicbase.exceptions.ServiceException;
import br.com.bicbanco.bicbase.service.BaseService;
import br.com.bicbanco.bicbase.view.filter.CrudFilter;
import br.com.bicbanco.pou.dao.AniversarioDAO;
import br.com.bicbanco.pou.dao.ContaPoupancaDAO;
import br.com.bicbanco.pou.dao.ExtratoContaPoupancaDAO;
import br.com.bicbanco.pou.dao.MovimentoDAO;
import br.com.bicbanco.pou.dto.AniversarioDTO;
import br.com.bicbanco.pou.dto.ContaPoupancaDTO;
import br.com.bicbanco.pou.dto.ExtratoContaPoupancaDTO;
import br.com.bicbanco.pou.dto.MovimentoDTO;
import br.com.bicbanco.pou.service.PoupancaService;

/**
 * @author b090020
 * 
 */
public class PoupancaServiceImpl extends BaseService implements PoupancaService {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private AniversarioDAO aniversarioDAO;
	private MovimentoDAO movimentoDAO;
	private ContaPoupancaDAO contaPoupancaDAO;
	private ExtratoContaPoupancaDAO extratoContaPoupancaDAO;
	private static final Logger logger = Logger.getLogger(PoupancaServiceImpl.class);

	public Collection<AniversarioDTO> listAniversarios(Integer codOrgao, Integer codPlataforma, Integer numConta) {
		AniversarioDTO filtro = new AniversarioDTO();
		filtro.setCodOrgao(codOrgao);
		filtro.setCodPlataforma(codPlataforma);
		filtro.setNumConta(numConta);
		return aniversarioDAO.findByExample(filtro);
	}

	public Collection<MovimentoDTO> listMovimentos(Integer codOrgao, Integer codPlataforma, Integer numConta) {
		return listMovimentos(codOrgao, codPlataforma, numConta, null);
	}

	public Collection<MovimentoDTO> listMovimentos(Integer codOrgao, Integer codPlataforma, Integer numConta, Date dataAniversario) {
		MovimentoDTO filtro = new MovimentoDTO();
		AniversarioDTO aniversario = new AniversarioDTO();
		aniversario.setCodOrgao(codOrgao);
		aniversario.setCodPlataforma(codPlataforma);
		aniversario.setNumConta(numConta);
		if (dataAniversario != null) {
			aniversario.setDataAniversario(dataAniversario);
		}
		filtro.setAniversario(aniversario);
		return movimentoDAO.findByExample(filtro);
	}

	/**
	 * @param aniversarioDAO the aniversarioDAO to set
	 */
	public void setAniversarioDAO(AniversarioDAO aniversarioDAO) {
		this.aniversarioDAO = aniversarioDAO;
	}

	/**
	 * @param movimentoDAO the movimentoDAO to set
	 */
	public void setMovimentoDAO(MovimentoDAO movimentoDAO) {
		this.movimentoDAO = movimentoDAO;
	}

	public void setContaPoupancaDAO(ContaPoupancaDAO contaPoupancaDAO) {
		this.contaPoupancaDAO = contaPoupancaDAO;
	}

	public void setExtratoContaPoupancaDAO(ExtratoContaPoupancaDAO extratoContaPoupancaDAO) {
		this.extratoContaPoupancaDAO = extratoContaPoupancaDAO;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see br.com.bicbanco.pou.service.PoupancaService#listContaPoupancaPorAgenciaConta(java.lang.Integer, java.lang.Integer)
	 */
	public Collection<ContaPoupancaDTO> listContaPoupancaPorAgenciaConta(Integer codOrgao, Integer numConta) throws ServiceException {
		try {
			Assert.notNull(codOrgao);
			Assert.notNull(numConta);
		} catch (RuntimeException e) {
			throw new ServiceException("Par�metros da pesquisa de conta poupan�a n�o informados ou incorretos.");
		}

		ContaPoupancaDTO contaPoupancaParam = new ContaPoupancaDTO();
		contaPoupancaParam.setCodOrgao(codOrgao);
		contaPoupancaParam.setNumConta(numConta);
		Collection<ContaPoupancaDTO> contaPoupancaList = null;
		try {
			contaPoupancaList = this.contaPoupancaDAO.findByExample(contaPoupancaParam);
		} catch (DAOException e) {
			throw new ServiceException("Erro na consulta no banco de dados.", e);
		}
		return contaPoupancaList;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see br.com.bicbanco.pou.service.PoupancaService#listContaPoupancaPorCnpj(java.lang.Integer, java.lang.Integer, java.lang.Integer)
	 */
	public Collection<ContaPoupancaDTO> listContaPoupancaPorCnpj(Integer raizCnpj, Integer filialCnpj, Integer digitoCnpj) throws ServiceException {
		try {
			Assert.notNull(raizCnpj);
			Assert.notNull(filialCnpj);
			Assert.notNull(digitoCnpj);
		} catch (RuntimeException e) {
			throw new ServiceException("Par�metros da pesquisa de conta poupan�a n�o informados ou incorretos.");
		}

		ContaPoupancaDTO contaPoupancaParam = new ContaPoupancaDTO();
		contaPoupancaParam.setCpfCnpjRaiz(raizCnpj);
		contaPoupancaParam.setFilialCnpj(filialCnpj);
		contaPoupancaParam.setCpfCnpjDigito(digitoCnpj);
		Collection<ContaPoupancaDTO> contaPoupancaList = null;
		try {
			contaPoupancaList = this.contaPoupancaDAO.findByExample(contaPoupancaParam);
		} catch (DAOException e) {
			throw new ServiceException("Erro na consulta no banco de dados.", e);
		}
		return contaPoupancaList;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see br.com.bicbanco.pou.service.PoupancaService#listContaPoupancaPorCpf(java.lang.Integer, java.lang.Integer)
	 */
	public Collection<ContaPoupancaDTO> listContaPoupancaPorCpf(Integer raizCpf, Integer digitoCpf) throws ServiceException {
		try {
			Assert.notNull(raizCpf);
			Assert.notNull(digitoCpf);
		} catch (RuntimeException e) {
			throw new ServiceException("Par�metros da pesquisa de conta poupan�a n�o informados ou incorretos.");
		}

		ContaPoupancaDTO contaPoupancaParam = new ContaPoupancaDTO();
		contaPoupancaParam.setCpfCnpjRaiz(raizCpf);
		contaPoupancaParam.setCpfCnpjDigito(digitoCpf);
		Collection<ContaPoupancaDTO> contaPoupancaList = null;
		try {
			contaPoupancaList = this.contaPoupancaDAO.findByExample(contaPoupancaParam);
		} catch (DAOException e) {
			throw new ServiceException("Erro na consulta no banco de dados.", e);
		}
		return contaPoupancaList;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see br.com.bicbanco.pou.service.PoupancaService#listExtratoContaPoupanca(br.com.bicbanco.pou.dto.ExtratoContaPoupancaDTO)
	 */
	public Collection<ExtratoContaPoupancaDTO> listExtratoContaPoupanca(Integer codOrgao, Integer numConta, Date dataLanctoInicial,
			Date dataLanctoFinal) throws ServiceException {
		logger.info("INI: listExtratoContaPoupanca");
		try {
			Assert.notNull(codOrgao);
			Assert.notNull(numConta);
			Assert.notNull(dataLanctoInicial);
			Assert.notNull(dataLanctoFinal);
		} catch (IllegalArgumentException e) {
			logger.error(e);
			throw new ServiceException("Par�metros da pesquisa do extrato de conta poupan�a n�o informados ou incorretos.", e);
		}

		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		Date dataLanctoInicialBase;
		try {
			dataLanctoInicialBase = sdf.parse("01/01/1999");
		} catch (ParseException e1) {
			logger.error(e1);
			throw new ServiceException("Erro nas datas de lancamentos.", e1);
		}
		if (dataLanctoInicial.before(dataLanctoInicialBase)) {
			dataLanctoInicial = dataLanctoInicialBase;
		}
		Date dataLanctoFinalBase = new Date(System.currentTimeMillis());
		if (dataLanctoFinal.after(dataLanctoFinalBase)) {
			dataLanctoFinal = dataLanctoFinalBase;
		}

		CrudFilter filter = new CrudFilter();
		filter.addEquals("codOrgao", codOrgao);
		filter.addEquals("numConta", numConta);
		filter.addBetween("dataLancto", dataLanctoInicial, dataLanctoFinal);
		Collection<ExtratoContaPoupancaDTO> extratoContaPoupancaList = null;
		try {
			extratoContaPoupancaList = this.extratoContaPoupancaDAO.filter(filter);
			logger.info("EXEC: listExtratoContaPoupanca retorno: " + extratoContaPoupancaList);
		} catch (DAOException e) {
			logger.error(e);
			throw new ServiceException("Erro na recupera��o dos dados.", e);
		}
		logger.info("FIM: listExtratoContaPoupanca");
		return extratoContaPoupancaList;
	}
}
