/**
 * 
 */
package br.com.bicbanco.pou.planos.conversor;

/**
 * @author opah01
 *
 */
public interface IConversor<LOCAL, REMOTO> {
	LOCAL converteDoRemoto(REMOTO remoto);
	REMOTO converteParaRemoto(LOCAL local);
}
