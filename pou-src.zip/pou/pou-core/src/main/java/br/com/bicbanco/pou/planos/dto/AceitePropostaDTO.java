/**
 * AceiteProposta.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf031428.03 v72314182347
 */

package br.com.bicbanco.pou.planos.dto;

import java.io.Serializable;
import java.util.Date;

import br.com.bicbanco.bicbase.dto.BaseDTO;
import br.com.bicbanco.pou.planos.enums.AceitePropostaEnum;

/**
 * 
 * @author opah01
 *
 */
public class AceitePropostaDTO extends BaseDTO {
    
	private static final long serialVersionUID = 1L;
	
	/**
	 *  Identificador �nico Global do Pedido de Habilita��o.
	 */
	private String guidPedido;
	
	/**
	 * Identificador Interno da Proposta.
	 */
    private String idProposta;
    
	/**
	 * Identificador Origem da Proposta (gerado pela Instituic�o / Banco) pela opera��o "cadastrarResultadoAnalisePedido"
	 */
    private String idPropostaBanco;
    
    /**
     * Data da visualiza��o / Aceite do Poupador.
     * format:AAAA-MM-DD HH:MM:SS
     */
    private Date data;
    
    /**
     * Aceite do Poupador: 1 - ACEITE; 2 - RECUSADO.
     */
    private AceitePropostaEnum aceite;
    
    /**
     * Motivo da Recusa da Proposta informado pelo Poupador.
     */
    private String motivoRecusa;

    public AceitePropostaDTO() {
    }

    @Override
	public Serializable getKey() {
		return  new Serializable[]{guidPedido, idProposta, idPropostaBanco};
	}

	/**
	 * @return the guidPedido
	 */
	public String getGuidPedido() {
		return guidPedido;
	}

	/**
	 * @param guidPedido the guidPedido to set
	 */
	public void setGuidPedido(String guidPedido) {
		this.guidPedido = guidPedido;
	}

	/**
	 * @return the idProposta
	 */
	public String getIdProposta() {
		return idProposta;
	}

	/**
	 * @param idProposta the idProposta to set
	 */
	public void setIdProposta(String idProposta) {
		this.idProposta = idProposta;
	}

	/**
	 * @return the idPropostaBanco
	 */
	public String getIdPropostaBanco() {
		return idPropostaBanco;
	}

	/**
	 * @param idPropostaBanco the idPropostaBanco to set
	 */
	public void setIdPropostaBanco(String idPropostaBanco) {
		this.idPropostaBanco = idPropostaBanco;
	}

	/**
	 * @return the data
	 */
	public Date getData() {
		return data;
	}

	/**
	 * @param data the data to set
	 */
	public void setData(Date data) {
		this.data = data;
	}

	/**
	 * @return the aceite
	 */
	public AceitePropostaEnum getAceite() {
		return aceite;
	}

	/**
	 * @param aceite the aceite to set
	 */
	public void setAceite(AceitePropostaEnum aceite) {
		this.aceite = aceite;
	}

	/**
	 * @return the motivoRecusa
	 */
	public String getMotivoRecusa() {
		return motivoRecusa;
	}

	/**
	 * @param motivoRecusa the motivoRecusa to set
	 */
	public void setMotivoRecusa(String motivoRecusa) {
		this.motivoRecusa = motivoRecusa;
	}
    
}
