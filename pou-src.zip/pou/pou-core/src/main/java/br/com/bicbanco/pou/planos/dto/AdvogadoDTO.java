/**
 * Advogado.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf031428.03 v72314182347
 */

package br.com.bicbanco.pou.planos.dto;

import java.io.Serializable;

import br.com.bicbanco.bicbase.dto.BaseDTO;
import br.com.bicbanco.pou.planos.enums.QualificacaoPatronoEnum;

/**
 * 
 * @author opah01
 *
 */
public class AdvogadoDTO extends BaseDTO  {
	
	private static final long serialVersionUID = 1L;
	
	/**
	 * Identificador do Patrono do Processo.
	 */
	private Integer id;
	
	/**
	 * CPF do Patrono.
	 */
    private String CPF;
    
    /**
     * Nome do Patrono.
     */
    private String nome;
    
    private IdentidadePatronoDTO OAB;
    private IdentidadePatronoDTO OABSuplementar;
    private IdentidadePatronoDTO matriculaDefensor;
    private ContatoDTO contato;
    
    /**
     * Qualifica��o do Patrono: ADVOGADO; DEFENSOR.
     */
    private QualificacaoPatronoEnum qualificacaoPatrono;
    
    @Override
	public Serializable getKey() {
		return id;
	}
    
	/**
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}
	
	/**
	 * @param id the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}
	
	/**
	 * @return the cPF
	 */
	public String getCPF() {
		return CPF;
	}
	
	/**
	 * @param cPF the cPF to set
	 */
	public void setCPF(String cPF) {
		CPF = cPF;
	}
	
	/**
	 * @return the nome
	 */
	public String getNome() {
		return nome;
	}
	
	/**
	 * @param nome the nome to set
	 */
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	/**
	 * @return the oAB
	 */
	public IdentidadePatronoDTO getOAB() {
		return OAB;
	}
	
	/**
	 * @param oAB the oAB to set
	 */
	public void setOAB(IdentidadePatronoDTO oAB) {
		OAB = oAB;
	}
	
	/**
	 * @return the oABSuplementar
	 */
	public IdentidadePatronoDTO getOABSuplementar() {
		return OABSuplementar;
	}
	
	/**
	 * @param oABSuplementar the oABSuplementar to set
	 */
	public void setOABSuplementar(IdentidadePatronoDTO oABSuplementar) {
		OABSuplementar = oABSuplementar;
	}
	
	/**
	 * @return the matriculaDefensor
	 */
	public IdentidadePatronoDTO getMatriculaDefensor() {
		return matriculaDefensor;
	}
	
	/**
	 * @param matriculaDefensor the matriculaDefensor to set
	 */
	public void setMatriculaDefensor(IdentidadePatronoDTO matriculaDefensor) {
		this.matriculaDefensor = matriculaDefensor;
	}
	
	/**
	 * @return the contato
	 */
	public ContatoDTO getContato() {
		return contato;
	}
	
	/**
	 * @param contato the contato to set
	 */
	public void setContato(ContatoDTO contato) {
		this.contato = contato;
	}
	
	/**
	 * @return the qualificacaoPatrono
	 */
	public QualificacaoPatronoEnum getQualificacaoPatrono() {
		return qualificacaoPatrono;
	}
	
	/**
	 * @param qualificacaoPatrono the qualificacaoPatrono to set
	 */
	public void setQualificacaoPatrono(QualificacaoPatronoEnum qualificacaoPatrono) {
		this.qualificacaoPatrono = qualificacaoPatrono;
	}
}