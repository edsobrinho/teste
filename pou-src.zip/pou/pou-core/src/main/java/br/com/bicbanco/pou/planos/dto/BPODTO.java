/**
 * BPO.java
 *
 */
package br.com.bicbanco.pou.planos.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import br.com.bicbanco.bicbase.dto.BaseDTO;

public class BPODTO extends BaseDTO  {
	
	private static final long serialVersionUID = 1L;
	
	private Integer sequencial;
	private Integer idAnaliseBPO;
    private String guidPedido;
    private Date dataSubmissaoBPO;
    private Date dataLiberacaoBPO;
    private List<ResultadoAnaliseBPODTO> itensBPO;

    public BPODTO(){}
    
    @Override
    public Serializable getKey() {
    	return new Serializable[]{sequencial,idAnaliseBPO, guidPedido};
    }

	/**
	 * @return the sequencial
	 */
	public Integer getSequencial() {
		return sequencial;
	}

	/**
	 * @param sequencial the sequencial to set
	 */
	public void setSequencial(Integer sequencial) {
		this.sequencial = sequencial;
	}

	/**
	 * @return the idAnaliseBPO
	 */
	public Integer getIdAnaliseBPO() {
		return idAnaliseBPO;
	}

	/**
	 * @param idAnaliseBPO the idAnaliseBPO to set
	 */
	public void setIdAnaliseBPO(Integer idAnaliseBPO) {
		this.idAnaliseBPO = idAnaliseBPO;
	}

	/**
	 * @return the guidPedido
	 */
	public String getGuidPedido() {
		return guidPedido;
	}

	/**
	 * @param guidPedido the guidPedido to set
	 */
	public void setGuidPedido(String guidPedido) {
		this.guidPedido = guidPedido;
	}

	/**
	 * @return the dataSubmissaoBPO
	 */
	public Date getDataSubmissaoBPO() {
		return dataSubmissaoBPO;
	}

	/**
	 * @param dataSubmissaoBPO the dataSubmissaoBPO to set
	 */
	public void setDataSubmissaoBPO(Date dataSubmissaoBPO) {
		this.dataSubmissaoBPO = dataSubmissaoBPO;
	}

	/**
	 * @return the dataLiberacaoBPO
	 */
	public Date getDataLiberacaoBPO() {
		return dataLiberacaoBPO;
	}

	/**
	 * @param dataLiberacaoBPO the dataLiberacaoBPO to set
	 */
	public void setDataLiberacaoBPO(Date dataLiberacaoBPO) {
		this.dataLiberacaoBPO = dataLiberacaoBPO;
	}

	/**
	 * @return the itensBPO
	 */
	public List<ResultadoAnaliseBPODTO> getItensBPO() {
		return itensBPO;
	}

	/**
	 * @param itensBPO the itensBPO to set
	 */
	public void setItensBPO(List<ResultadoAnaliseBPODTO> itensBPO) {
		this.itensBPO = itensBPO;
	}
}