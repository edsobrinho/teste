/**
 * 
 */
package br.com.bicbanco.pou.planos.dto;

import java.io.Serializable;

import br.com.bicbanco.bicbase.dto.BaseDTO;
import br.com.bicbanco.pou.planos.enums.TipoContaEnum;

/**
 * @author opah01
 *
 */
public class ContaDTO extends BaseDTO {
	
	private static final long serialVersionUID = 1L;
	
	private Long id;
	private String nomeTitular;
	private String cpfCnpj;
	private Integer banco;
	private String nomeBanco;
	private String agencia;
	private String agenciaDV;
	private String numeroConta;
	private String numeroContaDV;
	private TipoContaEnum tipoConta;
	
	@Override
	public Serializable getKey() {
		return id;
	}

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the nomeTitular
	 */
	public String getNomeTitular() {
		return nomeTitular;
	}

	/**
	 * @param nomeTitular the nomeTitular to set
	 */
	public void setNomeTitular(String nomeTitular) {
		this.nomeTitular = nomeTitular;
	}

	/**
	 * @return the cpfCnpj
	 */
	public String getCpfCnpj() {
		return cpfCnpj;
	}

	/**
	 * @param cpfCnpj the cpfCnpj to set
	 */
	public void setCpfCnpj(String cpfCnpj) {
		this.cpfCnpj = cpfCnpj;
	}

	/**
	 * @return the banco
	 */
	public Integer getBanco() {
		return banco;
	}

	/**
	 * @param banco the banco to set
	 */
	public void setBanco(Integer banco) {
		this.banco = banco;
	}

	/**
	 * @return the nomeBanco
	 */
	public String getNomeBanco() {
		return nomeBanco;
	}

	/**
	 * @param nomeBanco the nomeBanco to set
	 */
	public void setNomeBanco(String nomeBanco) {
		this.nomeBanco = nomeBanco;
	}

	/**
	 * @return the agencia
	 */
	public String getAgencia() {
		return agencia;
	}

	/**
	 * @param agencia the agencia to set
	 */
	public void setAgencia(String agencia) {
		this.agencia = agencia;
	}

	/**
	 * @return the agenciaDV
	 */
	public String getAgenciaDV() {
		return agenciaDV;
	}

	/**
	 * @param agenciaDV the agenciaDV to set
	 */
	public void setAgenciaDV(String agenciaDV) {
		this.agenciaDV = agenciaDV;
	}

	/**
	 * @return the numeroConta
	 */
	public String getNumeroConta() {
		return numeroConta;
	}

	/**
	 * @param numeroConta the numeroConta to set
	 */
	public void setNumeroConta(String numeroConta) {
		this.numeroConta = numeroConta;
	}

	/**
	 * @return the numeroContaDV
	 */
	public String getNumeroContaDV() {
		return numeroContaDV;
	}

	/**
	 * @param numeroContaDV the numeroContaDV to set
	 */
	public void setNumeroContaDV(String numeroContaDV) {
		this.numeroContaDV = numeroContaDV;
	}

	/**
	 * @return the tipoConta
	 */
	public TipoContaEnum getTipoConta() {
		return tipoConta;
	}

	/**
	 * @param tipoConta the tipoConta to set
	 */
	public void setTipoConta(TipoContaEnum tipoConta) {
		this.tipoConta = tipoConta;
	}

}
