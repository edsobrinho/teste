/**
 * 
 */
package br.com.bicbanco.pou.planos.dto;

import java.io.Serializable;

import br.com.bicbanco.bicbase.dto.BaseDTO;

/**
 * @author opah01
 *
 */
public class ContaPagamentoDTO extends BaseDTO {
	
	private static final long serialVersionUID = 1L;
	
	private Integer id;
	private ContaDTO contaBancaria;
	private DepositoJudicialDTO contaJudicial;
	
	@Override
	public Serializable getKey() {
		return id;
	}

	/**
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}

	/**
	 * @return the contaBancaria
	 */
	public ContaDTO getContaBancaria() {
		return contaBancaria;
	}

	/**
	 * @param contaBancaria the contaBancaria to set
	 */
	public void setContaBancaria(ContaDTO contaBancaria) {
		this.contaBancaria = contaBancaria;
	}

	/**
	 * @return the contaJudicial
	 */
	public DepositoJudicialDTO getContaJudicial() {
		return contaJudicial;
	}

	/**
	 * @param contaJudicial the contaJudicial to set
	 */
	public void setContaJudicial(DepositoJudicialDTO contaJudicial) {
		this.contaJudicial = contaJudicial;
	}
}