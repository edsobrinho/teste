/**
 * 
 */
package br.com.bicbanco.pou.planos.dto;

import java.util.List;

import br.com.bicbanco.bicbase.types.Money;
import br.com.bicbanco.pou.planos.enums.PlanoEnum;

/**
 * @author opah01
 *
 */
public class ContaPlanoDTO extends ContaDTO {
	
	private static final long serialVersionUID = 1L;

	private Integer idContaPlano;
    private PlanoEnum plano;
    private Money saldoBase;
    private Money valorSimulado;
    private Integer diaAniversarioConta;
    private List<HabilitacaoDTO> pedidoEmOutrasHabilitacoes;
    
    /**
	 * @return the idContaPlano
	 */
	public Integer getIdContaPlano() {
		return idContaPlano;
	}
	
	/**
	 * @param idContaPlano the idContaPlano to set
	 */
	public void setIdContaPlano(Integer idContaPlano) {
		this.idContaPlano = idContaPlano;
	}
	
	/**
	 * @return the plano
	 */
	public PlanoEnum getPlano() {
		return plano;
	}
	
	/**
	 * @param plano the plano to set
	 */
	public void setPlano(PlanoEnum plano) {
		this.plano = plano;
	}
	
	/**
	 * @return the saldoBase
	 */
	public Money getSaldoBase() {
		return saldoBase;
	}
	
	/**
	 * @param saldoBase the saldoBase to set
	 */
	public void setSaldoBase(Money saldoBase) {
		this.saldoBase = saldoBase;
	}
	
	/**
	 * @return the valorSimulado
	 */
	public Money getValorSimulado() {
		return valorSimulado;
	}
	
	/**
	 * @param valorSimulado the valorSimulado to set
	 */
	public void setValorSimulado(Money valorSimulado) {
		this.valorSimulado = valorSimulado;
	}
	
	/**
	 * @return the diaAniversarioConta
	 */
	public Integer getDiaAniversarioConta() {
		return diaAniversarioConta;
	}
	
	/**
	 * @param diaAniversarioConta the diaAniversarioConta to set
	 */
	public void setDiaAniversarioConta(Integer diaAniversarioConta) {
		this.diaAniversarioConta = diaAniversarioConta;
	}
	
	/**
	 * @return the pedidoEmOutrasHabilitacoes
	 */
	public List<HabilitacaoDTO> getPedidoEmOutrasHabilitacoes() {
		return pedidoEmOutrasHabilitacoes;
	}

	/**
	 * @param pedidoEmOutrasHabilitacoes the pedidoEmOutrasHabilitacoes to set
	 */
	public void setPedidoEmOutrasHabilitacoes(List<HabilitacaoDTO> pedidoEmOutrasHabilitacoes) {
		this.pedidoEmOutrasHabilitacoes = pedidoEmOutrasHabilitacoes;
	}
}