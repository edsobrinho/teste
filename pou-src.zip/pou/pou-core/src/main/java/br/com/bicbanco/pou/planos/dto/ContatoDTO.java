/**
 * 
 */
package br.com.bicbanco.pou.planos.dto;

import java.io.Serializable;

import br.com.bicbanco.bicbase.dto.BaseDTO;

/**
 * @author opah01
 *
 */
public class ContatoDTO extends BaseDTO {
	
	private static final long serialVersionUID = 1L;

	private Long id;
	
	/**
	 * Telefone celular do Contato informado.
	 */
	private TelefoneDTO celular;
	
	/**
	 * E-mail de Contato.
	 */
	private String email;
	
	/**
	 * Telefone Fixo do Contato informado.
	 */
	private TelefoneDTO telefoneFixo;

	@Override
	public Serializable getKey() {
		return id;
	}
	
	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}
	/**
	 * @return the celular
	 */
	public TelefoneDTO getCelular() {
		return celular;
	}

	/**
	 * @param celular the celular to set
	 */
	public void setCelular(TelefoneDTO celular) {
		this.celular = celular;
	}

	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * @param email the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * @return the telefoneFixo
	 */
	public TelefoneDTO getTelefoneFixo() {
		return telefoneFixo;
	}

	/**
	 * @param telefoneFixo the telefoneFixo to set
	 */
	public void setTelefoneFixo(TelefoneDTO telefoneFixo) {
		this.telefoneFixo = telefoneFixo;
	}
}