/**
 * 
 */
package br.com.bicbanco.pou.planos.dto;

import java.io.Serializable;
import java.util.Date;

import br.com.bicbanco.bicbase.dto.BaseDTO;

/**
 * @author opah01
 *
 */
public class DepositoJudicialDTO extends BaseDTO {
	
	private static final long serialVersionUID = 1L;
	
	private Long id;
	private Integer banco;
    private String nomeBanco;
    private String idDepositoJudicial;
    private Date dataValidade;

	@Override
	public Serializable getKey() {
		return id;
	}

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}
	
	/**
	 * @return the banco
	 */
	public Integer getBanco() {
		return banco;
	}

	/**
	 * @param banco the banco to set
	 */
	public void setBanco(Integer banco) {
		this.banco = banco;
	}

	/**
	 * @return the nomeBanco
	 */
	public String getNomeBanco() {
		return nomeBanco;
	}

	/**
	 * @param nomeBanco the nomeBanco to set
	 */
	public void setNomeBanco(String nomeBanco) {
		this.nomeBanco = nomeBanco;
	}

	/**
	 * @return the idDepositoJudicial
	 */
	public String getIdDepositoJudicial() {
		return idDepositoJudicial;
	}

	/**
	 * @param idDepositoJudicial the idDepositoJudicial to set
	 */
	public void setIdDepositoJudicial(String idDepositoJudicial) {
		this.idDepositoJudicial = idDepositoJudicial;
	}

	/**
	 * @return the dataValidade
	 */
	public Date getDataValidade() {
		return dataValidade;
	}

	/**
	 * @param dataValidade the dataValidade to set
	 */
	public void setDataValidade(Date dataValidade) {
		this.dataValidade = dataValidade;
	}
}