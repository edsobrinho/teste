/**
 * 
 */
package br.com.bicbanco.pou.planos.dto;

import java.io.Serializable;

import br.com.bicbanco.bicbase.dto.BaseDTO;
import br.com.bicbanco.pou.planos.enums.ContextoEnum;
import br.com.bicbanco.pou.planos.enums.TipoDocumentoEnum;

/**
 * @author opah01
 *
 */
public class DocumentoDTO extends BaseDTO {

	private static final long serialVersionUID = 1L;

	private Integer id;
    private String nomeDocumento;
    private TipoDocumentoEnum tipoDocumento;
    private ContextoEnum contexto;
    private Integer idChaveContexto;
	
	@Override
	public Serializable getKey() {
		return id;
	}

	/**
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}

	/**
	 * @return the nomeDocumento
	 */
	public String getNomeDocumento() {
		return nomeDocumento;
	}

	/**
	 * @param nomeDocumento the nomeDocumento to set
	 */
	public void setNomeDocumento(String nomeDocumento) {
		this.nomeDocumento = nomeDocumento;
	}

	/**
	 * @return the tipoDocumento
	 */
	public TipoDocumentoEnum getTipoDocumento() {
		return tipoDocumento;
	}

	/**
	 * @param tipoDocumento the tipoDocumento to set
	 */
	public void setTipoDocumento(TipoDocumentoEnum tipoDocumento) {
		this.tipoDocumento = tipoDocumento;
	}

	/**
	 * @return the contexto
	 */
	public ContextoEnum getContexto() {
		return contexto;
	}

	/**
	 * @param contexto the contexto to set
	 */
	public void setContexto(ContextoEnum contexto) {
		this.contexto = contexto;
	}

	/**
	 * @return the idChaveContexto
	 */
	public Integer getIdChaveContexto() {
		return idChaveContexto;
	}

	/**
	 * @param idChaveContexto the idChaveContexto to set
	 */
	public void setIdChaveContexto(Integer idChaveContexto) {
		this.idChaveContexto = idChaveContexto;
	}
}