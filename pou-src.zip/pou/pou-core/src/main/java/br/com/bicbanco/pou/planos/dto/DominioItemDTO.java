/**
 * 
 */
package br.com.bicbanco.pou.planos.dto;

/**
 * @author opah01
 *
 */
public class DominioItemDTO {

	private Integer id;
    private String descricao;
    private Boolean ativo;
    
	/**
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}
	
	/**
	 * @param id the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}
	
	/**
	 * @return the descricao
	 */
	public String getDescricao() {
		return descricao;
	}
	
	/**
	 * @param descricao the descricao to set
	 */
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	
	/**
	 * @return the ativo
	 */
	public Boolean getAtivo() {
		return ativo;
	}
	
	/**
	 * @param ativo the ativo to set
	 */
	public void setAtivo(Boolean ativo) {
		this.ativo = ativo;
	}
}
