/**
 * 
 */
package br.com.bicbanco.pou.planos.dto;

import java.io.Serializable;

import br.com.bicbanco.bicbase.dto.BaseDTO;

/**
 * @author opah01
 *
 */
public class HabilitacaoDTO  extends BaseDTO {

	private static final long serialVersionUID = 1L;

	private String protocolo;
	
	@Override
	public Serializable getKey() {
		return protocolo;
	}

	/**
	 * @return the protocolo
	 */
	public String getProtocolo() {
		return protocolo;
	}

	/**
	 * @param protocolo the protocolo to set
	 */
	public void setProtocolo(String protocolo) {
		this.protocolo = protocolo;
	}

}
