/**
 * 
 */
package br.com.bicbanco.pou.planos.dto;

import java.io.Serializable;

import br.com.bicbanco.bicbase.dto.BaseDTO;
import br.com.bicbanco.pou.planos.enums.TipoIdentidadeEnum;

/**
 * @author opah01
 *
 */
public class IdentidadeDTO extends BaseDTO {

	private static final long serialVersionUID = 1L;

	private Integer id;
	private String numero;
	private String orgao;
	private String UF;
	private TipoIdentidadeEnum tipo;
	private String classificacao;
	private String validade;
	

	@Override
	public Serializable getKey() {
		return id;
	}


	/**
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}


	/**
	 * @param id the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}


	/**
	 * @return the numero
	 */
	public String getNumero() {
		return numero;
	}


	/**
	 * @param numero the numero to set
	 */
	public void setNumero(String numero) {
		this.numero = numero;
	}


	/**
	 * @return the orgao
	 */
	public String getOrgao() {
		return orgao;
	}


	/**
	 * @param orgao the orgao to set
	 */
	public void setOrgao(String orgao) {
		this.orgao = orgao;
	}


	/**
	 * @return the uF
	 */
	public String getUF() {
		return UF;
	}


	/**
	 * @param uF the uF to set
	 */
	public void setUF(String uF) {
		UF = uF;
	}


	/**
	 * @return the tipo
	 */
	public TipoIdentidadeEnum getTipo() {
		return tipo;
	}


	/**
	 * @param tipo the tipo to set
	 */
	public void setTipo(TipoIdentidadeEnum tipo) {
		this.tipo = tipo;
	}


	/**
	 * @return the classificacao
	 */
	public String getClassificacao() {
		return classificacao;
	}


	/**
	 * @param classificacao the classificacao to set
	 */
	public void setClassificacao(String classificacao) {
		this.classificacao = classificacao;
	}


	/**
	 * @return the validade
	 */
	public String getValidade() {
		return validade;
	}


	/**
	 * @param validade the validade to set
	 */
	public void setValidade(String validade) {
		this.validade = validade;
	}
}