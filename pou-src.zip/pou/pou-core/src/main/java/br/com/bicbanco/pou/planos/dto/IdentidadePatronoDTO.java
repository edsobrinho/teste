/**
 * 
 */
package br.com.bicbanco.pou.planos.dto;

import java.io.Serializable;

import br.com.bicbanco.bicbase.dto.BaseDTO;
import br.com.bicbanco.pou.planos.enums.EsferaEnum;

/**
 * @author opah01
 *
 */
public class IdentidadePatronoDTO extends BaseDTO {
	
	private static final long serialVersionUID = 1L;
	
	private Integer id;
	
	/**
	 * Esfera: ESTADUAL; FEDERAL (para OAB sempre ESTADUAL).
	 */
	private EsferaEnum esfera;

	/**
	 * UF da OAB.
	 */
	private String UF;
	
	/**
	 * N�mero da OAB.
	 */
	private String numero;
	
	@Override
	public Serializable getKey() {
		return id;
	}
	
	/**
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}
	
	/**
	 * @return the esfera
	 */
	public EsferaEnum getEsfera() {
		return esfera;
	}
	
	/**
	 * @param esfera the esfera to set
	 */
	public void setEsfera(EsferaEnum esfera) {
		this.esfera = esfera;
	}
	
	/**
	 * @return the uF
	 */
	public String getUF() {
		return UF;
	}
	
	/**
	 * @param uF the uF to set
	 */
	public void setUF(String uF) {
		UF = uF;
	}
	
	/**
	 * @return the numero
	 */
	public String getNumero() {
		return numero;
	}
	
	/**
	 * @param numero the numero to set
	 */
	public void setNumero(String numero) {
		this.numero = numero;
	}
}