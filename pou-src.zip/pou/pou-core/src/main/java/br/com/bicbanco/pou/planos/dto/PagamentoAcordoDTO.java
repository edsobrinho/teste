/**
 * 
 */
package br.com.bicbanco.pou.planos.dto;

import java.io.Serializable;

import br.com.bicbanco.bicbase.dto.BaseDTO;
import br.com.bicbanco.bicbase.types.Money;
import br.com.bicbanco.pou.planos.enums.StatusPagamentoEnum;

/**
 * @author opah01
 *
 */
public class PagamentoAcordoDTO extends BaseDTO {

	
	private static final long serialVersionUID = 1L;
	
	private String guidPedido;
    private Integer idPropostaBanco;
    private String dataPagamento;
    private Money valorPagamento;
    private Integer numeroParcela;
    private ArquivoDTO comprovante;
    private StatusPagamentoEnum statusPagamento;
    private String observacoesPagamento;
    private ContaPagamentoDTO contaPagamentoAcordo;

	@Override
	public Serializable getKey() {
		return null;
	}

	/**
	 * @return the guidPedido
	 */
	public String getGuidPedido() {
		return guidPedido;
	}

	/**
	 * @param guidPedido the guidPedido to set
	 */
	public void setGuidPedido(String guidPedido) {
		this.guidPedido = guidPedido;
	}

	/**
	 * @return the idPropostaBanco
	 */
	public Integer getIdPropostaBanco() {
		return idPropostaBanco;
	}

	/**
	 * @param idPropostaBanco the idPropostaBanco to set
	 */
	public void setIdPropostaBanco(Integer idPropostaBanco) {
		this.idPropostaBanco = idPropostaBanco;
	}

	/**
	 * @return the dataPagamento
	 */
	public String getDataPagamento() {
		return dataPagamento;
	}

	/**
	 * @param dataPagamento the dataPagamento to set
	 */
	public void setDataPagamento(String dataPagamento) {
		this.dataPagamento = dataPagamento;
	}

	/**
	 * @return the valorPagamento
	 */
	public Money getValorPagamento() {
		return valorPagamento;
	}

	/**
	 * @param valorPagamento the valorPagamento to set
	 */
	public void setValorPagamento(Money valorPagamento) {
		this.valorPagamento = valorPagamento;
	}

	/**
	 * @return the numeroParcela
	 */
	public Integer getNumeroParcela() {
		return numeroParcela;
	}

	/**
	 * @param numeroParcela the numeroParcela to set
	 */
	public void setNumeroParcela(Integer numeroParcela) {
		this.numeroParcela = numeroParcela;
	}

	/**
	 * @return the comprovante
	 */
	public ArquivoDTO getComprovante() {
		return comprovante;
	}

	/**
	 * @param comprovante the comprovante to set
	 */
	public void setComprovante(ArquivoDTO comprovante) {
		this.comprovante = comprovante;
	}

	/**
	 * @return the statusPagamento
	 */
	public StatusPagamentoEnum getStatusPagamento() {
		return statusPagamento;
	}

	/**
	 * @param statusPagamento the statusPagamento to set
	 */
	public void setStatusPagamento(StatusPagamentoEnum statusPagamento) {
		this.statusPagamento = statusPagamento;
	}

	/**
	 * @return the observacoesPagamento
	 */
	public String getObservacoesPagamento() {
		return observacoesPagamento;
	}

	/**
	 * @param observacoesPagamento the observacoesPagamento to set
	 */
	public void setObservacoesPagamento(String observacoesPagamento) {
		this.observacoesPagamento = observacoesPagamento;
	}

	/**
	 * @return the contaPagamentoAcordo
	 */
	public ContaPagamentoDTO getContaPagamentoAcordo() {
		return contaPagamentoAcordo;
	}

	/**
	 * @param contaPagamentoAcordo the contaPagamentoAcordo to set
	 */
	public void setContaPagamentoAcordo(ContaPagamentoDTO contaPagamentoAcordo) {
		this.contaPagamentoAcordo = contaPagamentoAcordo;
	}
}