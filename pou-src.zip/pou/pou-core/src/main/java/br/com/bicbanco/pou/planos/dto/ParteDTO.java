/**
 * 
 */
package br.com.bicbanco.pou.planos.dto;

import java.io.Serializable;
import java.util.Date;

import br.com.bicbanco.bicbase.dto.BaseDTO;
import br.com.bicbanco.pou.planos.enums.QualificacaoEnvolvidoEnum;

/**
 * @author opah01
 *
 */
public class ParteDTO extends BaseDTO {
	
	private static final long serialVersionUID = 1L;

	private Integer id;
    private String cpf;
    private String nome;
    private IdentidadeDTO identidade;
    private Date dataNascimento;
    private Boolean falecido;
    private String dataObito;
    private EnderecoDTO enderecoCorrespondencia;
    private ContatoDTO contato;
    private QualificacaoEnvolvidoEnum qualificacao;
	
	@Override
	public Serializable getKey() {
		return id;
	}

	/**
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}

	/**
	 * @return the cpf
	 */
	public String getCpf() {
		return cpf;
	}

	/**
	 * @param cpf the cpf to set
	 */
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	/**
	 * @return the nome
	 */
	public String getNome() {
		return nome;
	}

	/**
	 * @param nome the nome to set
	 */
	public void setNome(String nome) {
		this.nome = nome;
	}

	/**
	 * @return the identidade
	 */
	public IdentidadeDTO getIdentidade() {
		return identidade;
	}

	/**
	 * @param identidade the identidade to set
	 */
	public void setIdentidade(IdentidadeDTO identidade) {
		this.identidade = identidade;
	}

	/**
	 * @return the dataNascimento
	 */
	public Date getDataNascimento() {
		return dataNascimento;
	}

	/**
	 * @param dataNascimento the dataNascimento to set
	 */
	public void setDataNascimento(Date dataNascimento) {
		this.dataNascimento = dataNascimento;
	}

	/**
	 * @return the falecido
	 */
	public Boolean getFalecido() {
		return falecido;
	}

	/**
	 * @param falecido the falecido to set
	 */
	public void setFalecido(Boolean falecido) {
		this.falecido = falecido;
	}

	/**
	 * @return the dataObito
	 */
	public String getDataObito() {
		return dataObito;
	}

	/**
	 * @param dataObito the dataObito to set
	 */
	public void setDataObito(String dataObito) {
		this.dataObito = dataObito;
	}

	/**
	 * @return the enderecoCorrespondencia
	 */
	public EnderecoDTO getEnderecoCorrespondencia() {
		return enderecoCorrespondencia;
	}

	/**
	 * @param enderecoCorrespondencia the enderecoCorrespondencia to set
	 */
	public void setEnderecoCorrespondencia(EnderecoDTO enderecoCorrespondencia) {
		this.enderecoCorrespondencia = enderecoCorrespondencia;
	}

	/**
	 * @return the contato
	 */
	public ContatoDTO getContato() {
		return contato;
	}

	/**
	 * @param contato the contato to set
	 */
	public void setContato(ContatoDTO contato) {
		this.contato = contato;
	}

	/**
	 * @return the qualificacao
	 */
	public QualificacaoEnvolvidoEnum getQualificacao() {
		return qualificacao;
	}

	/**
	 * @param qualificacao the qualificacao to set
	 */
	public void setQualificacao(QualificacaoEnvolvidoEnum qualificacao) {
		this.qualificacao = qualificacao;
	}
}