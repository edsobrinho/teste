/**
 * 
 */
package br.com.bicbanco.pou.planos.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import br.com.bicbanco.bicbase.dto.BaseDTO;
import br.com.bicbanco.bicbase.types.Money;
import br.com.bicbanco.pou.planos.enums.DestinatarioContaEnum;
import br.com.bicbanco.pou.planos.enums.StatusPedidoEnum;

/**
 * @author opah01
 *
 */
public class PedidoDTO extends BaseDTO {
	
	private static final long serialVersionUID = 1L;

	private String guidPedido;
    private String protocolo;
    private Integer idLoteHabilitacao;
    private Date dataAbertura;
    private StatusPedidoEnum statusPedido;
    private Money valorCustasProcessuais;
    private Date dataConfimacaoLeituraBanco;
    private Money valorTotalSimulado;
    private DestinatarioContaEnum destinatarioPagamentoAcordo;
    private ParteDTO poupador;
    private List<ParteDTO> envolvidosEspolio;
    private AdvogadoDTO patrono;
    private ContaPagamentoDTO contaPagamentoAcordo;
    private ContaPagamentoDTO contaPagamentoHonorario;
    private ProcessoDTO processo;
    private List<ContaPlanoDTO> contasContempladas;
    private List<DocumentoDTO> documentos;
    private BPODTO resultadoBPO;
	
	@Override
	public Serializable getKey() {
		return new Serializable[]{guidPedido, protocolo};
	}

	/**
	 * @return the guidPedido
	 */
	public String getGuidPedido() {
		return guidPedido;
	}

	/**
	 * @param guidPedido the guidPedido to set
	 */
	public void setGuidPedido(String guidPedido) {
		this.guidPedido = guidPedido;
	}

	/**
	 * @return the protocolo
	 */
	public String getProtocolo() {
		return protocolo;
	}

	/**
	 * @param protocolo the protocolo to set
	 */
	public void setProtocolo(String protocolo) {
		this.protocolo = protocolo;
	}

	/**
	 * @return the idLoteHabilitacao
	 */
	public Integer getIdLoteHabilitacao() {
		return idLoteHabilitacao;
	}

	/**
	 * @param idLoteHabilitacao the idLoteHabilitacao to set
	 */
	public void setIdLoteHabilitacao(Integer idLoteHabilitacao) {
		this.idLoteHabilitacao = idLoteHabilitacao;
	}

	/**
	 * @return the dataAbertura
	 */
	public Date getDataAbertura() {
		return dataAbertura;
	}

	/**
	 * @param dataAbertura the dataAbertura to set
	 */
	public void setDataAbertura(Date dataAbertura) {
		this.dataAbertura = dataAbertura;
	}

	/**
	 * @return the statusPedido
	 */
	public StatusPedidoEnum getStatusPedido() {
		return statusPedido;
	}

	/**
	 * @param statusPedido the statusPedido to set
	 */
	public void setStatusPedido(StatusPedidoEnum statusPedido) {
		this.statusPedido = statusPedido;
	}

	/**
	 * @return the valorCustasProcessuais
	 */
	public Money getValorCustasProcessuais() {
		return valorCustasProcessuais;
	}

	/**
	 * @param valorCustasProcessuais the valorCustasProcessuais to set
	 */
	public void setValorCustasProcessuais(Money valorCustasProcessuais) {
		this.valorCustasProcessuais = valorCustasProcessuais;
	}

	/**
	 * @return the dataConfimacaoLeituraBanco
	 */
	public Date getDataConfimacaoLeituraBanco() {
		return dataConfimacaoLeituraBanco;
	}

	/**
	 * @param dataConfimacaoLeituraBanco the dataConfimacaoLeituraBanco to set
	 */
	public void setDataConfimacaoLeituraBanco(Date dataConfimacaoLeituraBanco) {
		this.dataConfimacaoLeituraBanco = dataConfimacaoLeituraBanco;
	}

	/**
	 * @return the valorTotalSimulado
	 */
	public Money getValorTotalSimulado() {
		return valorTotalSimulado;
	}

	/**
	 * @param valorTotalSimulado the valorTotalSimulado to set
	 */
	public void setValorTotalSimulado(Money valorTotalSimulado) {
		this.valorTotalSimulado = valorTotalSimulado;
	}

	/**
	 * @return the destinatarioPagamentoAcordo
	 */
	public DestinatarioContaEnum getDestinatarioPagamentoAcordo() {
		return destinatarioPagamentoAcordo;
	}

	/**
	 * @param destinatarioPagamentoAcordo the destinatarioPagamentoAcordo to set
	 */
	public void setDestinatarioPagamentoAcordo(DestinatarioContaEnum destinatarioPagamentoAcordo) {
		this.destinatarioPagamentoAcordo = destinatarioPagamentoAcordo;
	}

	/**
	 * @return the poupador
	 */
	public ParteDTO getPoupador() {
		return poupador;
	}

	/**
	 * @param poupador the poupador to set
	 */
	public void setPoupador(ParteDTO poupador) {
		this.poupador = poupador;
	}

	/**
	 * @return the envolvidosEspolio
	 */
	public List<ParteDTO> getEnvolvidosEspolio() {
		return envolvidosEspolio;
	}

	/**
	 * @param envolvidosEspolio the envolvidosEspolio to set
	 */
	public void setEnvolvidosEspolio(List<ParteDTO> envolvidosEspolio) {
		this.envolvidosEspolio = envolvidosEspolio;
	}

	/**
	 * @return the patrono
	 */
	public AdvogadoDTO getPatrono() {
		return patrono;
	}

	/**
	 * @param patrono the patrono to set
	 */
	public void setPatrono(AdvogadoDTO patrono) {
		this.patrono = patrono;
	}

	/**
	 * @return the contaPagamentoAcordo
	 */
	public ContaPagamentoDTO getContaPagamentoAcordo() {
		return contaPagamentoAcordo;
	}

	/**
	 * @param contaPagamentoAcordo the contaPagamentoAcordo to set
	 */
	public void setContaPagamentoAcordo(ContaPagamentoDTO contaPagamentoAcordo) {
		this.contaPagamentoAcordo = contaPagamentoAcordo;
	}

	/**
	 * @return the contaPagamentoHonorario
	 */
	public ContaPagamentoDTO getContaPagamentoHonorario() {
		return contaPagamentoHonorario;
	}

	/**
	 * @param contaPagamentoHonorario the contaPagamentoHonorario to set
	 */
	public void setContaPagamentoHonorario(ContaPagamentoDTO contaPagamentoHonorario) {
		this.contaPagamentoHonorario = contaPagamentoHonorario;
	}

	/**
	 * @return the processo
	 */
	public ProcessoDTO getProcesso() {
		return processo;
	}

	/**
	 * @param processo the processo to set
	 */
	public void setProcesso(ProcessoDTO processo) {
		this.processo = processo;
	}

	/**
	 * @return the contasContempladas
	 */
	public List<ContaPlanoDTO> getContasContempladas() {
		return contasContempladas;
	}

	/**
	 * @param contasContempladas the contasContempladas to set
	 */
	public void setContasContempladas(List<ContaPlanoDTO> contasContempladas) {
		this.contasContempladas = contasContempladas;
	}

	/**
	 * @return the documentos
	 */
	public List<DocumentoDTO> getDocumentos() {
		return documentos;
	}

	/**
	 * @param documentos the documentos to set
	 */
	public void setDocumentos(List<DocumentoDTO> documentos) {
		this.documentos = documentos;
	}

	/**
	 * @return the resultadoBPO
	 */
	public BPODTO getResultadoBPO() {
		return resultadoBPO;
	}

	/**
	 * @param resultadoBPO the resultadoBPO to set
	 */
	public void setResultadoBPO(BPODTO resultadoBPO) {
		this.resultadoBPO = resultadoBPO;
	}
}