/**
 * 
 */
package br.com.bicbanco.pou.planos.dto;

import java.io.Serializable;
import java.util.Date;

import br.com.bicbanco.bicbase.dto.BaseDTO;
import br.com.bicbanco.pou.planos.enums.TipoAcaoEnum;
import br.com.bicbanco.pou.planos.enums.TipoProcessoEnum;

/**
 * @author opah01
 *
 */
public class ProcessoDTO extends BaseDTO {

	private static final long serialVersionUID = 1L;
	
	private Integer id;
    private String numeroProcessoCNJ;
    private String numeroProcessoAntigo;
    private String identificadorProcessoSistemaLegado;
    private TipoProcessoEnum orgaoLegal;
    private TipoAcaoEnum tipoAcao;
    private String varaDeOrigem;
    private String comarcaDeOrigem;
    private String UF;
    private Date ajuizadoEm;
    private Date dataProcuracao;
    private String instituicaoNome;
    
	@Override
	public Serializable getKey() {
		return id;
	}

	/**
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}

	/**
	 * @return the numeroProcessoCNJ
	 */
	public String getNumeroProcessoCNJ() {
		return numeroProcessoCNJ;
	}

	/**
	 * @param numeroProcessoCNJ the numeroProcessoCNJ to set
	 */
	public void setNumeroProcessoCNJ(String numeroProcessoCNJ) {
		this.numeroProcessoCNJ = numeroProcessoCNJ;
	}

	/**
	 * @return the numeroProcessoAntigo
	 */
	public String getNumeroProcessoAntigo() {
		return numeroProcessoAntigo;
	}

	/**
	 * @param numeroProcessoAntigo the numeroProcessoAntigo to set
	 */
	public void setNumeroProcessoAntigo(String numeroProcessoAntigo) {
		this.numeroProcessoAntigo = numeroProcessoAntigo;
	}

	/**
	 * @return the identificadorProcessoSistemaLegado
	 */
	public String getIdentificadorProcessoSistemaLegado() {
		return identificadorProcessoSistemaLegado;
	}

	/**
	 * @param identificadorProcessoSistemaLegado the identificadorProcessoSistemaLegado to set
	 */
	public void setIdentificadorProcessoSistemaLegado(String identificadorProcessoSistemaLegado) {
		this.identificadorProcessoSistemaLegado = identificadorProcessoSistemaLegado;
	}

	/**
	 * @return the orgaoLegal
	 */
	public TipoProcessoEnum getOrgaoLegal() {
		return orgaoLegal;
	}

	/**
	 * @param orgaoLegal the orgaoLegal to set
	 */
	public void setOrgaoLegal(TipoProcessoEnum orgaoLegal) {
		this.orgaoLegal = orgaoLegal;
	}

	/**
	 * @return the tipoAcao
	 */
	public TipoAcaoEnum getTipoAcao() {
		return tipoAcao;
	}

	/**
	 * @param tipoAcao the tipoAcao to set
	 */
	public void setTipoAcao(TipoAcaoEnum tipoAcao) {
		this.tipoAcao = tipoAcao;
	}

	/**
	 * @return the varaDeOrigem
	 */
	public String getVaraDeOrigem() {
		return varaDeOrigem;
	}

	/**
	 * @param varaDeOrigem the varaDeOrigem to set
	 */
	public void setVaraDeOrigem(String varaDeOrigem) {
		this.varaDeOrigem = varaDeOrigem;
	}

	/**
	 * @return the comarcaDeOrigem
	 */
	public String getComarcaDeOrigem() {
		return comarcaDeOrigem;
	}

	/**
	 * @param comarcaDeOrigem the comarcaDeOrigem to set
	 */
	public void setComarcaDeOrigem(String comarcaDeOrigem) {
		this.comarcaDeOrigem = comarcaDeOrigem;
	}

	/**
	 * @return the uF
	 */
	public String getUF() {
		return UF;
	}

	/**
	 * @param uF the uF to set
	 */
	public void setUF(String uF) {
		UF = uF;
	}

	/**
	 * @return the ajuizadoEm
	 */
	public Date getAjuizadoEm() {
		return ajuizadoEm;
	}

	/**
	 * @param ajuizadoEm the ajuizadoEm to set
	 */
	public void setAjuizadoEm(Date ajuizadoEm) {
		this.ajuizadoEm = ajuizadoEm;
	}

	/**
	 * @return the dataProcuracao
	 */
	public Date getDataProcuracao() {
		return dataProcuracao;
	}

	/**
	 * @param dataProcuracao the dataProcuracao to set
	 */
	public void setDataProcuracao(Date dataProcuracao) {
		this.dataProcuracao = dataProcuracao;
	}

	/**
	 * @return the instituicaoNome
	 */
	public String getInstituicaoNome() {
		return instituicaoNome;
	}

	/**
	 * @param instituicaoNome the instituicaoNome to set
	 */
	public void setInstituicaoNome(String instituicaoNome) {
		this.instituicaoNome = instituicaoNome;
	}
}