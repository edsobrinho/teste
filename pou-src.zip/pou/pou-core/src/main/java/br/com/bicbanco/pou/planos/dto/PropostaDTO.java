/**
 * 
 */
package br.com.bicbanco.pou.planos.dto;

import java.io.Serializable;

import br.com.bicbanco.bicbase.dto.BaseDTO;
import br.com.bicbanco.bicbase.types.Money;

/**
 * @author opah01
 *
 */
public class PropostaDTO extends BaseDTO {

	private static final long serialVersionUID = 1L;
	
	private String idPropostaBanco;
    private Money valorTotalAcordo;
    private Money valorPoupador;
    private Money valorHonorariosAdvogado;
    private Money valorHonorariosFebrapo;
    private Money valorReembolsoCustas;
    private Integer quantidadeParcelas;
    private Money valorParcela;
    private String dataPrimeiraParcela;
    private String observacoes;
    private ArquivoDTO demonstrativoCalculo;

	@Override
	public Serializable getKey() {
		return idPropostaBanco;
	}

	/**
	 * @return the idPropostaBanco
	 */
	public String getIdPropostaBanco() {
		return idPropostaBanco;
	}

	/**
	 * @param idPropostaBanco the idPropostaBanco to set
	 */
	public void setIdPropostaBanco(String idPropostaBanco) {
		this.idPropostaBanco = idPropostaBanco;
	}

	/**
	 * @return the valorTotalAcordo
	 */
	public Money getValorTotalAcordo() {
		return valorTotalAcordo;
	}

	/**
	 * @param valorTotalAcordo the valorTotalAcordo to set
	 */
	public void setValorTotalAcordo(Money valorTotalAcordo) {
		this.valorTotalAcordo = valorTotalAcordo;
	}

	/**
	 * @return the valorPoupador
	 */
	public Money getValorPoupador() {
		return valorPoupador;
	}

	/**
	 * @param valorPoupador the valorPoupador to set
	 */
	public void setValorPoupador(Money valorPoupador) {
		this.valorPoupador = valorPoupador;
	}

	/**
	 * @return the valorHonorariosAdvogado
	 */
	public Money getValorHonorariosAdvogado() {
		return valorHonorariosAdvogado;
	}

	/**
	 * @param valorHonorariosAdvogado the valorHonorariosAdvogado to set
	 */
	public void setValorHonorariosAdvogado(Money valorHonorariosAdvogado) {
		this.valorHonorariosAdvogado = valorHonorariosAdvogado;
	}

	/**
	 * @return the valorHonorariosFebrapo
	 */
	public Money getValorHonorariosFebrapo() {
		return valorHonorariosFebrapo;
	}

	/**
	 * @param valorHonorariosFebrapo the valorHonorariosFebrapo to set
	 */
	public void setValorHonorariosFebrapo(Money valorHonorariosFebrapo) {
		this.valorHonorariosFebrapo = valorHonorariosFebrapo;
	}

	/**
	 * @return the valorReembolsoCustas
	 */
	public Money getValorReembolsoCustas() {
		return valorReembolsoCustas;
	}

	/**
	 * @param valorReembolsoCustas the valorReembolsoCustas to set
	 */
	public void setValorReembolsoCustas(Money valorReembolsoCustas) {
		this.valorReembolsoCustas = valorReembolsoCustas;
	}

	/**
	 * @return the quantidadeParcelas
	 */
	public Integer getQuantidadeParcelas() {
		return quantidadeParcelas;
	}

	/**
	 * @param quantidadeParcelas the quantidadeParcelas to set
	 */
	public void setQuantidadeParcelas(Integer quantidadeParcelas) {
		this.quantidadeParcelas = quantidadeParcelas;
	}

	/**
	 * @return the valorParcela
	 */
	public Money getValorParcela() {
		return valorParcela;
	}

	/**
	 * @param valorParcela the valorParcela to set
	 */
	public void setValorParcela(Money valorParcela) {
		this.valorParcela = valorParcela;
	}

	/**
	 * @return the dataPrimeiraParcela
	 */
	public String getDataPrimeiraParcela() {
		return dataPrimeiraParcela;
	}

	/**
	 * @param dataPrimeiraParcela the dataPrimeiraParcela to set
	 */
	public void setDataPrimeiraParcela(String dataPrimeiraParcela) {
		this.dataPrimeiraParcela = dataPrimeiraParcela;
	}

	/**
	 * @return the observacoes
	 */
	public String getObservacoes() {
		return observacoes;
	}

	/**
	 * @param observacoes the observacoes to set
	 */
	public void setObservacoes(String observacoes) {
		this.observacoes = observacoes;
	}

	/**
	 * @return the demonstrativoCalculo
	 */
	public ArquivoDTO getDemonstrativoCalculo() {
		return demonstrativoCalculo;
	}

	/**
	 * @param demonstrativoCalculo the demonstrativoCalculo to set
	 */
	public void setDemonstrativoCalculo(ArquivoDTO demonstrativoCalculo) {
		this.demonstrativoCalculo = demonstrativoCalculo;
	}
}