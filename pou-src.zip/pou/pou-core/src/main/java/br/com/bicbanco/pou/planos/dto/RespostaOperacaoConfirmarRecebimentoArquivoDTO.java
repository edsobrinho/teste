/**
 * 
 */
package br.com.bicbanco.pou.planos.dto;

import java.io.Serializable;

import br.com.bicbanco.bicbase.dto.BaseDTO;

/**
 * @author opah01
 *
 */
public class RespostaOperacaoConfirmarRecebimentoArquivoDTO extends BaseDTO {

	private static final long serialVersionUID = 1L;
	
	private String guidPedido;
	private Integer idDocumento;
	
	@Override
	public Serializable getKey() {
		return new Serializable[]{guidPedido, idDocumento};
	}

	/**
	 * @return the guidPedido
	 */
	public String getGuidPedido() {
		return guidPedido;
	}

	/**
	 * @param guidPedido the guidPedido to set
	 */
	public void setGuidPedido(String guidPedido) {
		this.guidPedido = guidPedido;
	}

	/**
	 * @return the idDocumento
	 */
	public Integer getIdDocumento() {
		return idDocumento;
	}

	/**
	 * @param idDocumento the idDocumento to set
	 */
	public void setIdDocumento(Integer idDocumento) {
		this.idDocumento = idDocumento;
	}
}