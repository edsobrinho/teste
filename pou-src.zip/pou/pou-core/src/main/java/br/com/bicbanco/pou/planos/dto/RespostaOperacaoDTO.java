/**
 * 
 */
package br.com.bicbanco.pou.planos.dto;

import java.io.Serializable;

import br.com.bicbanco.bicbase.dto.BaseDTO;
import br.com.bicbanco.pou.planos.enums.RetornoProcessamentoEnum;

/**
 * @author opah01
 *
 */
public class RespostaOperacaoDTO extends BaseDTO {
	
	private static final long serialVersionUID = 1L;

	private String codigoRetorno;
    private RetornoProcessamentoEnum retorno;
    private String descricaoRetorno;
	
	@Override
	public Serializable getKey() {
		return codigoRetorno;
	}

	/**
	 * @return the codigoRetorno
	 */
	public String getCodigoRetorno() {
		return codigoRetorno;
	}

	/**
	 * @param codigoRetorno the codigoRetorno to set
	 */
	public void setCodigoRetorno(String codigoRetorno) {
		this.codigoRetorno = codigoRetorno;
	}

	/**
	 * @return the retorno
	 */
	public RetornoProcessamentoEnum getRetorno() {
		return retorno;
	}

	/**
	 * @param retorno the retorno to set
	 */
	public void setRetorno(RetornoProcessamentoEnum retorno) {
		this.retorno = retorno;
	}

	/**
	 * @return the descricaoRetorno
	 */
	public String getDescricaoRetorno() {
		return descricaoRetorno;
	}

	/**
	 * @param descricaoRetorno the descricaoRetorno to set
	 */
	public void setDescricaoRetorno(String descricaoRetorno) {
		this.descricaoRetorno = descricaoRetorno;
	}
}