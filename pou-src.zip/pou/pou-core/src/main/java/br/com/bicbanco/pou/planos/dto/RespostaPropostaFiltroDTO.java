/**
 * 
 */
package br.com.bicbanco.pou.planos.dto;

import java.io.Serializable;
import java.util.Calendar;

import br.com.bicbanco.bicbase.dto.BaseDTO;

/**
 * @author opah01
 *
 */
public class RespostaPropostaFiltroDTO extends BaseDTO {
	
	private static final long serialVersionUID = 1L;
	
	private Calendar dataInicio;
    private Calendar dataFim;
    private String guidPedido;

	@Override
	public Serializable getKey() {
		return guidPedido;
	}

	/**
	 * @return the dataInicio
	 */
	public Calendar getDataInicio() {
		return dataInicio;
	}

	/**
	 * @param dataInicio the dataInicio to set
	 */
	public void setDataInicio(Calendar dataInicio) {
		this.dataInicio = dataInicio;
	}

	/**
	 * @return the dataFim
	 */
	public Calendar getDataFim() {
		return dataFim;
	}

	/**
	 * @param dataFim the dataFim to set
	 */
	public void setDataFim(Calendar dataFim) {
		this.dataFim = dataFim;
	}

	/**
	 * @return the guidPedido
	 */
	public String getGuidPedido() {
		return guidPedido;
	}

	/**
	 * @param guidPedido the guidPedido to set
	 */
	public void setGuidPedido(String guidPedido) {
		this.guidPedido = guidPedido;
	}
}