/**
 * 
 */
package br.com.bicbanco.pou.planos.dto;

import java.io.Serializable;
import java.util.List;

import br.com.bicbanco.bicbase.dto.BaseDTO;
import br.com.bicbanco.pou.planos.enums.ContextoEnum;
import br.com.bicbanco.pou.planos.enums.MotivoNCEnum;
import br.com.bicbanco.pou.planos.enums.ResultadoAnaliseBPOEnum;
import br.com.bicbanco.pou.planos.enums.TipoDocumentoEnum;


/**
 * @author opah01
 *
 */
public class ResultadoAnaliseBPODTO extends BaseDTO {
	
	private static final long serialVersionUID = 1L;
	
	private Integer idItem;
    private String descricaoItem;
    private ContextoEnum contexto;
    private Integer idChaveContexto;
    private ResultadoAnaliseBPOEnum resultado;
    private TipoDocumentoEnum tipoDocumento;
    private List<MotivoNCEnum> motivosNC;
    
    @Override
	public Serializable getKey() {
		return idItem;
	}
    
	/**
	 * @return the idItem
	 */
	public Integer getIdItem() {
		return idItem;
	}
	
	/**
	 * @param idItem the idItem to set
	 */
	public void setIdItem(Integer idItem) {
		this.idItem = idItem;
	}
	
	/**
	 * @return the descricaoItem
	 */
	public String getDescricaoItem() {
		return descricaoItem;
	}
	
	/**
	 * @param descricaoItem the descricaoItem to set
	 */
	public void setDescricaoItem(String descricaoItem) {
		this.descricaoItem = descricaoItem;
	}
	
	/**
	 * @return the contexto
	 */
	public ContextoEnum getContexto() {
		return contexto;
	}
	
	/**
	 * @param contexto the contexto to set
	 */
	public void setContexto(ContextoEnum contexto) {
		this.contexto = contexto;
	}
	
	/**
	 * @return the idChaveContexto
	 */
	public Integer getIdChaveContexto() {
		return idChaveContexto;
	}
	
	/**
	 * @param idChaveContexto the idChaveContexto to set
	 */
	public void setIdChaveContexto(Integer idChaveContexto) {
		this.idChaveContexto = idChaveContexto;
	}
	
	/**
	 * @return the resultado
	 */
	public ResultadoAnaliseBPOEnum getResultado() {
		return resultado;
	}
	
	/**
	 * @param resultado the resultado to set
	 */
	public void setResultado(ResultadoAnaliseBPOEnum resultado) {
		this.resultado = resultado;
	}
	
	/**
	 * @return the tipoDocumento
	 */
	public TipoDocumentoEnum getTipoDocumento() {
		return tipoDocumento;
	}
	
	/**
	 * @param tipoDocumento the tipoDocumento to set
	 */
	public void setTipoDocumento(TipoDocumentoEnum tipoDocumento) {
		this.tipoDocumento = tipoDocumento;
	}
	/**
	 * @return the motivosNC
	 */
	public List<MotivoNCEnum> getMotivosNC() {
		return motivosNC;
	}
	
	/**
	 * @param motivosNC the motivosNC to set
	 */
	public void setMotivosNC(List<MotivoNCEnum> motivosNC) {
		this.motivosNC = motivosNC;
	}
}