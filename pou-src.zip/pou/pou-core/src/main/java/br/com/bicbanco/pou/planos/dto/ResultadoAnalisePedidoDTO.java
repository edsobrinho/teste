/**
 * 
 */
package br.com.bicbanco.pou.planos.dto;

import java.io.Serializable;
import java.util.Date;

import br.com.bicbanco.bicbase.dto.BaseDTO;
import br.com.bicbanco.pou.planos.enums.MotivoRecusaPedidoEnum;
import br.com.bicbanco.pou.planos.enums.TipoResultadoAnaliseHabilitacaoEnum;

/**
 * @author opah01
 *
 */
public class ResultadoAnalisePedidoDTO extends BaseDTO {
	
	private static final long serialVersionUID = 1L;
	
	private String guidPedido;
    private TipoResultadoAnaliseHabilitacaoEnum resultado;
    private MotivoRecusaPedidoEnum motivoRecusaPedido;
    private String subMotivoRecusa;
    private PropostaDTO proposta;
    private Date dataAnalise;

	@Override
	public Serializable getKey() {
		return guidPedido;
	}

	/**
	 * @return the guidPedido
	 */
	public String getGuidPedido() {
		return guidPedido;
	}

	/**
	 * @param guidPedido the guidPedido to set
	 */
	public void setGuidPedido(String guidPedido) {
		this.guidPedido = guidPedido;
	}

	/**
	 * @return the resultado
	 */
	public TipoResultadoAnaliseHabilitacaoEnum getResultado() {
		return resultado;
	}

	/**
	 * @param resultado the resultado to set
	 */
	public void setResultado(TipoResultadoAnaliseHabilitacaoEnum resultado) {
		this.resultado = resultado;
	}

	/**
	 * @return the motivoRecusaPedido
	 */
	public MotivoRecusaPedidoEnum getMotivoRecusaPedido() {
		return motivoRecusaPedido;
	}

	/**
	 * @param motivoRecusaPedido the motivoRecusaPedido to set
	 */
	public void setMotivoRecusaPedido(MotivoRecusaPedidoEnum motivoRecusaPedido) {
		this.motivoRecusaPedido = motivoRecusaPedido;
	}

	/**
	 * @return the subMotivoRecusa
	 */
	public String getSubMotivoRecusa() {
		return subMotivoRecusa;
	}

	/**
	 * @param subMotivoRecusa the subMotivoRecusa to set
	 */
	public void setSubMotivoRecusa(String subMotivoRecusa) {
		this.subMotivoRecusa = subMotivoRecusa;
	}

	/**
	 * @return the proposta
	 */
	public PropostaDTO getProposta() {
		return proposta;
	}

	/**
	 * @param proposta the proposta to set
	 */
	public void setProposta(PropostaDTO proposta) {
		this.proposta = proposta;
	}

	/**
	 * @return the dataAnalise
	 */
	public Date getDataAnalise() {
		return dataAnalise;
	}

	/**
	 * @param dataAnalise the dataAnalise to set
	 */
	public void setDataAnalise(Date dataAnalise) {
		this.dataAnalise = dataAnalise;
	}
}