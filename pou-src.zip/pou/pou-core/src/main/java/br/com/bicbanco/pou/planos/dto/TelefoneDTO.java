/**
 * 
 */
package br.com.bicbanco.pou.planos.dto;

import java.io.Serializable;

import br.com.bicbanco.bicbase.dto.BaseDTO;

/**
 * @author opah01
 *
 */
public class TelefoneDTO extends BaseDTO {
	
	private static final long serialVersionUID = 1L;
	
	private Integer id; 
	
	/***
	 * DDD do Telefone 
	 */
	private String DDD;
	
	/**
	 * N�mero do Telefone
	 */
    private String numero;
    
    @Override
	public Serializable getKey() {
		return id;
	}
    
	/**
	 * @return the dDD
	 */
	public String getDDD() {
		return DDD;
	}
	
	/**
	 * @param dDD the dDD to set
	 */
	public void setDDD(String dDD) {
		DDD = dDD;
	}
	
	/**
	 * @return the numero
	 */
	public String getNumero() {
		return numero;
	}
	
	/**
	 * @param numero the numero to set
	 */
	public void setNumero(String numero) {
		this.numero = numero;
	}
	
	/**
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}
	
	/**
	 * @param id the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}
}