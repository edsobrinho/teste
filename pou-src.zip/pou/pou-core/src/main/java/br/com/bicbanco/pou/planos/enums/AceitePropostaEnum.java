/**
 * 
 */
package br.com.bicbanco.pou.planos.enums;

/**
 * Aceite do Poupador: 1 - ACEITE; 
 * 					   2 - RECUSADO.
 * 
 * @author opah01
 */
public enum AceitePropostaEnum {
	
	
	ACEITO(1,"ACEITO"),
	RECUSADO(2,"RECUSADO");
	
	private Integer codigo; 
	private String descricao;
	
	private AceitePropostaEnum(Integer codigo, String descricao) {
		this.codigo = codigo;
		this.descricao = descricao;
	}

	public static AceitePropostaEnum getInstance(Integer codigo) {
		
		if (codigo == null) {
			return null;
		}
		
		for (AceitePropostaEnum aceiteProposta : AceitePropostaEnum.values()) {
			if (aceiteProposta.getCodigo().equals(codigo)) {
				return aceiteProposta;
			}
		}
		
		return null;		
	}
	
	public static AceitePropostaEnum getInstance(String descricao) {
		
		if (descricao == null) {
			return null;
		}
		
		for (AceitePropostaEnum aceiteProposta : AceitePropostaEnum.values()) {
			if (aceiteProposta.getDescricao().equals(descricao)) {
				return aceiteProposta;
			}
		}
		
		return null;		
	}
	
	/**
	 * @return the codigo
	 */
	public Integer getCodigo() {
		return codigo;
	}

	/**
	 * @param codigo the codigo to set
	 */
	public void setCodigo(Integer codigo) {
		this.codigo = codigo;
	}

	/**
	 * @return the descricao
	 */
	public String getDescricao() {
		return descricao;
	}

	/**
	 * @param descricao the descricao to set
	 */
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

}
