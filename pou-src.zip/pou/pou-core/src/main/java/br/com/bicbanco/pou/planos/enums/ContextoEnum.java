/**
 * 
 */
package br.com.bicbanco.pou.planos.enums;

/**
 * @author opah01
 *
 */
public enum ContextoEnum {
	
    POUPADOR(1,"POUPADOR"),
    INVENTARIANTE(2,"INVENTARIANTE"),
    ADVOGADO(3,"ADVOGADO"),
    PROCESSO(4,"PROCESSO"),
    CONTA_PLANO(5,"CONTA_PLANO"),
    PAGAMENTO(6,"PAGAMENTO"),
    RESUMO(7,"RESUMO"),
    TERMO(8,"TERMO"),
    ADESAO(9,"ADESAO"),
    OUTROS_DOCUMENTOS(10,"OUTROS_DOCUMENTOS"),
    PROPOSTA(11,"PROPOSTA"),
    SUCESSOR(12,"SUCESSOR");
 	
	private Integer codigo; 
	private String descricao;
	
	private ContextoEnum(Integer codigo, String descricao) {
		this.codigo = codigo;
		this.descricao = descricao;
	}

	public static ContextoEnum getInstance(Integer codigo) {
		
		if (codigo == null) {
			return null;
		}
		
		for (ContextoEnum contexto : ContextoEnum.values()) {
			if (contexto.getCodigo().equals(codigo)) {
				return contexto;
			}
		}
		
		return null;		
	}
	
	public static ContextoEnum getInstance(String descricao) {
		
		if (descricao == null) {
			return null;
		}
		
		for (ContextoEnum contexto : ContextoEnum.values()) {
			if (contexto.getDescricao().equals(descricao)) {
				return contexto;
			}
		}
		
		return null;		
	}
	
	/**
	 * @return the codigo
	 */
	public Integer getCodigo() {
		return codigo;
	}

	/**
	 * @param codigo the codigo to set
	 */
	public void setCodigo(Integer codigo) {
		this.codigo = codigo;
	}

	/**
	 * @return the descricao
	 */
	public String getDescricao() {
		return descricao;
	}

	/**
	 * @param descricao the descricao to set
	 */
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
}