/**
 * 
 */
package br.com.bicbanco.pou.planos.enums;

/**
 * @author opah01
 *
 */
public enum DestinatarioContaEnum {
    
    CONTA_POUPADOR(1,"CONTA_POUPADOR"),
    CONTA_ADVOGADO(2,"CONTA_ADVOGADO"),
    DEPOSITO_JUDICIAL(3,"DEPOSITO_JUDICIAL"),
    BOLETO(4,"BOLETO");
	
	private Integer codigo; 
	private String descricao;
	
	private DestinatarioContaEnum(Integer codigo, String descricao) {
		this.codigo = codigo;
		this.descricao = descricao;
	}

	public static DestinatarioContaEnum getInstance(Integer codigo) {
		
		if (codigo == null) {
			return null;
		}
		
		for (DestinatarioContaEnum destinatarioConta : DestinatarioContaEnum.values()) {
			if (destinatarioConta.getCodigo().equals(codigo)) {
				return destinatarioConta;
			}
		}
		return null;		
	}
	
	public static DestinatarioContaEnum getInstance(String descricao) {
		
		if (descricao == null) {
			return null;
		}
		
		for (DestinatarioContaEnum destinatarioConta : DestinatarioContaEnum.values()) {
			if (destinatarioConta.getDescricao().equals(descricao)) {
				return destinatarioConta;
			}
		}
		return null;		
	}
	
	/**
	 * @return the codigo
	 */
	public Integer getCodigo() {
		return codigo;
	}

	/**
	 * @param codigo the codigo to set
	 */
	public void setCodigo(Integer codigo) {
		this.codigo = codigo;
	}

	/**
	 * @return the descricao
	 */
	public String getDescricao() {
		return descricao;
	}

	/**
	 * @param descricao the descricao to set
	 */
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
}
