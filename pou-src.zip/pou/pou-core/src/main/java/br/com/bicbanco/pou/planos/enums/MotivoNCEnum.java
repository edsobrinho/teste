/**
 * 
 */
package br.com.bicbanco.pou.planos.enums;

/**
 * @author opah01
 *
 */
public enum MotivoNCEnum {
    
    HABILITACAO_DUPLICADA_PARA_MESMO_CPF_PROCESSO(1,"HABILITACAO_DUPLICADA_PARA_MESMO_CPF_PROCESSO"),
    HABILITACAO_DUPLICADA_PEDIDO_PLEITEADO_PELO_MESMO_CPF_EM_PROCESSO_DIFERENTE(2,"HABILITACAO_DUPLICADA_PEDIDO_PLEITEADO_PELO_MESMO_CPF_EM_PROCESSO_DIFERENTE"),
    HABILITACAO_DUPLICADA_PEDIDO_PLEITEADO_CPF_DISTINTO_EM_PROCESSO_DIFERENTE(3,"HABILITACAO_DUPLICADA_PEDIDO_PLEITEADO_CPF_DISTINTO_EM_PROCESSO_DIFERENTE"),
    PROCESSO_NAO_LOCALIZADO_NO_JUDICIARIO(4,"PROCESSO_NAO_LOCALIZADO_NO_JUDICIARIO"),
    INFORMACAO_DIVERGENTE(5,"INFORMACAO_DIVERGENTE"),
    INFORMACAO_NAO_LEGIVEL(6,"INFORMACAO_NAO_LEGIVEL"),
    INFORMACAO_NAO_DISPONIVEL(7,"INFORMACAO_NAO_DISPONIVEL");

	private Integer codigo; 
	private String descricao;
	
	private MotivoNCEnum(Integer codigo, String descricao) {
		this.codigo = codigo;
		this.descricao = descricao;
	}

	public static MotivoNCEnum getInstance(Integer codigo) {
		
		if (codigo == null) {
			return null;
		}
		
		for (MotivoNCEnum tipoDocumento : MotivoNCEnum.values()) {
			if (tipoDocumento.getCodigo().equals(codigo)) {
				return tipoDocumento;
			}
		}
		
		return null;		
	}
	
	public static MotivoNCEnum getInstance(String descricao) {
		
		if (descricao == null) {
			return null;
		}
		
		for (MotivoNCEnum tipoDocumento : MotivoNCEnum.values()) {
			if (tipoDocumento.getDescricao().equals(descricao)) {
				return tipoDocumento;
			}
		}
		
		return null;		
	}
	
	/**
	 * @return the codigo
	 */
	public Integer getCodigo() {
		return codigo;
	}

	/**
	 * @param codigo the codigo to set
	 */
	public void setCodigo(Integer codigo) {
		this.codigo = codigo;
	}

	/**
	 * @return the descricao
	 */
	public String getDescricao() {
		return descricao;
	}

	/**
	 * @param descricao the descricao to set
	 */
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	
}
