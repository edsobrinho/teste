package br.com.bicbanco.pou.planos.enums;

public enum MotivoRecusaPedidoEnum {
	
    PROCESSO_NAO_ELEGIVEL(1,"PROCESSO_NAO_ELEGIVEL"),
    CONTA_NAO_ELEGIVEL(2,"CONTA_NAO_ELEGIVEL"),
    BANCO_NAO_ELEGIVEL(3,"BANCO_NAO_ELEGIVEL"),
    AUSENCIA_DOCUMENTO_OBRIGATORIO(4,"AUSENCIA_DOCUMENTO_OBRIGATORIO");
	
	private Integer codigo; 
	private String descricao;
	
	private MotivoRecusaPedidoEnum(Integer codigo, String descricao) {
		this.codigo = codigo;
		this.descricao = descricao;
	}

	public static MotivoRecusaPedidoEnum getInstance(Integer codigo) {
		
		if (codigo == null) {
			return null;
		}
		
		for (MotivoRecusaPedidoEnum tipoIdentidade : MotivoRecusaPedidoEnum.values()) {
			if (tipoIdentidade.getCodigo().equals(codigo)) {
				return tipoIdentidade;
			}
		}
		return null;		
	}
	
	public static MotivoRecusaPedidoEnum getInstance(String descricao) {
		
		if (descricao == null) {
			return null;
		}
		
		for (MotivoRecusaPedidoEnum tipoIdentidade : MotivoRecusaPedidoEnum.values()) {
			if (tipoIdentidade.getDescricao().equals(descricao)) {
				return tipoIdentidade;
			}
		}
		return null;		
	}
	
	/**
	 * @return the codigo
	 */
	public Integer getCodigo() {
		return codigo;
	}

	/**
	 * @param codigo the codigo to set
	 */
	public void setCodigo(Integer codigo) {
		this.codigo = codigo;
	}

	/**
	 * @return the descricao
	 */
	public String getDescricao() {
		return descricao;
	}

	/**
	 * @param descricao the descricao to set
	 */
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

}
