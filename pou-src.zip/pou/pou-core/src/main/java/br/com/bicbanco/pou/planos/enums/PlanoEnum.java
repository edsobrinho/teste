/**
 * 
 */
package br.com.bicbanco.pou.planos.enums;

/**
 * @author opah01
 *
 */
public enum PlanoEnum {
    
    BRESSER(1,"BRESSER"),
    COLLOR_I(2,"COLLOR_I"),
    COLLOR_II(3,"COLLOR_II"),
    VERAO(4,"VERAO");
	 	
	private Integer codigo; 
	private String descricao;
	
	private PlanoEnum(Integer codigo, String descricao) {
		this.codigo = codigo;
		this.descricao = descricao;
	}

	public static PlanoEnum getInstance(Integer codigo) {
		
		if (codigo == null) {
			return null;
		}
		
		for (PlanoEnum plano : PlanoEnum.values()) {
			if (plano.getCodigo().equals(codigo)) {
				return plano;
			}
		}
		
		return null;		
	}
	
	public static PlanoEnum getInstance(String descricao) {
		
		if (descricao == null) {
			return null;
		}
		
		for (PlanoEnum plano : PlanoEnum.values()) {
			if (plano.getDescricao().equals(descricao)) {
				return plano;
			}
		}
		
		return null;		
	}
	
	/**
	 * @return the codigo
	 */
	public Integer getCodigo() {
		return codigo;
	}

	/**
	 * @param codigo the codigo to set
	 */
	public void setCodigo(Integer codigo) {
		this.codigo = codigo;
	}

	/**
	 * @return the descricao
	 */
	public String getDescricao() {
		return descricao;
	}

	/**
	 * @param descricao the descricao to set
	 */
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
}