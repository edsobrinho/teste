/**
 * 
 */
package br.com.bicbanco.pou.planos.enums;

/**
 * Qualifica��o do Patrono: ADVOGADO; DEFENSOR.
 * @author opah01
 *
 */
public enum QualificacaoPatronoEnum {
	
	ADVOGADO(1,"ADVOGADO"),
	DEFENSOR(2,"DEFENSOR");
	
	private Integer codigo; 
	private String descricao;
	
	private QualificacaoPatronoEnum(Integer codigo, String descricao) {
		this.codigo = codigo;
		this.descricao = descricao;
	}

	public static QualificacaoPatronoEnum getInstance(Integer codigo) {
		
		if (codigo == null) {
			return null;
		}
		
		for (QualificacaoPatronoEnum qualificacaoPatrono : QualificacaoPatronoEnum.values()) {
			if (qualificacaoPatrono.getCodigo().equals(codigo)) {
				return qualificacaoPatrono;
			}
		}
		
		return null;		
	}
	
	public static QualificacaoPatronoEnum getInstance(String descricao) {
		
		if (descricao == null) {
			return null;
		}
		
		for (QualificacaoPatronoEnum qualificacaoPatrono : QualificacaoPatronoEnum.values()) {
			if (qualificacaoPatrono.getDescricao().equals(descricao)) {
				return qualificacaoPatrono;
			}
		}
		
		return null;		
	}
	
	/**
	 * @return the codigo
	 */
	public Integer getCodigo() {
		return codigo;
	}

	/**
	 * @param codigo the codigo to set
	 */
	public void setCodigo(Integer codigo) {
		this.codigo = codigo;
	}

	/**
	 * @return the descricao
	 */
	public String getDescricao() {
		return descricao;
	}

	/**
	 * @param descricao the descricao to set
	 */
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

}
