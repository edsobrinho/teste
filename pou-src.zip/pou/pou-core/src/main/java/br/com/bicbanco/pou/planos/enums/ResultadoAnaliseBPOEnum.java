/**
 * 
 */
package br.com.bicbanco.pou.planos.enums;

/**
 * @author opah01
 *
 */
public enum ResultadoAnaliseBPOEnum {
	
	CONFORME(1,"CONFORME"),
	NAO_CONFORME(2,"NAO_CONFORME");
	 	
	private Integer codigo; 
	private String descricao;
	
	private ResultadoAnaliseBPOEnum(Integer codigo, String descricao) {
		this.codigo = codigo;
		this.descricao = descricao;
	}

	public static ResultadoAnaliseBPOEnum getInstance(Integer codigo) {
		
		if (codigo == null) {
			return null;
		}
		
		for (ResultadoAnaliseBPOEnum resultAnaliseBPO : ResultadoAnaliseBPOEnum.values()) {
			if (resultAnaliseBPO.getCodigo().equals(codigo)) {
				return resultAnaliseBPO;
			}
		}
		
		return null;		
	}
	
	public static ResultadoAnaliseBPOEnum getInstance(String descricao) {
		
		if (descricao == null) {
			return null;
		}
		
		for (ResultadoAnaliseBPOEnum resultAnaliseBPO : ResultadoAnaliseBPOEnum.values()) {
			if (resultAnaliseBPO.getDescricao().equals(descricao)) {
				return resultAnaliseBPO;
			}
		}
		
		return null;		
	}
	
	/**
	 * @return the codigo
	 */
	public Integer getCodigo() {
		return codigo;
	}

	/**
	 * @param codigo the codigo to set
	 */
	public void setCodigo(Integer codigo) {
		this.codigo = codigo;
	}

	/**
	 * @return the descricao
	 */
	public String getDescricao() {
		return descricao;
	}

	/**
	 * @param descricao the descricao to set
	 */
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

}
