package br.com.bicbanco.pou.planos.enums;

public enum RetornoProcessamentoEnum {
	
    ERRO(1,"ERRO"),
    FALHA(1,"FALHA"),
    SUCESSO(3,"SUCESSO");
	
	private Integer codigo; 
	private String descricao;
	
	private RetornoProcessamentoEnum(Integer codigo, String descricao) {
		this.codigo = codigo;
		this.descricao = descricao;
	}

	public static RetornoProcessamentoEnum getInstance(Integer codigo) {
		
		if (codigo == null) {
			return null;
		}
		
		for (RetornoProcessamentoEnum tipoIdentidade : RetornoProcessamentoEnum.values()) {
			if (tipoIdentidade.getCodigo().equals(codigo)) {
				return tipoIdentidade;
			}
		}
		return null;		
	}
	
	public static RetornoProcessamentoEnum getInstance(String descricao) {
		
		if (descricao == null) {
			return null;
		}
		
		for (RetornoProcessamentoEnum tipoIdentidade : RetornoProcessamentoEnum.values()) {
			if (tipoIdentidade.getDescricao().equals(descricao)) {
				return tipoIdentidade;
			}
		}
		return null;		
	}
	
	/**
	 * @return the codigo
	 */
	public Integer getCodigo() {
		return codigo;
	}

	/**
	 * @param codigo the codigo to set
	 */
	public void setCodigo(Integer codigo) {
		this.codigo = codigo;
	}

	/**
	 * @return the descricao
	 */
	public String getDescricao() {
		return descricao;
	}

	/**
	 * @param descricao the descricao to set
	 */
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

}
