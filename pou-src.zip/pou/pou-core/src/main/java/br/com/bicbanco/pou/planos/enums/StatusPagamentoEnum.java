package br.com.bicbanco.pou.planos.enums;

public enum StatusPagamentoEnum {
	
    REALIZADO(1,"REALIZADO"),
    NAO_REALIZADO(2,"NAO_REALIZADO");
	
	private Integer codigo; 
	private String descricao;
	
	private StatusPagamentoEnum(Integer codigo, String descricao) {
		this.codigo = codigo;
		this.descricao = descricao;
	}

	public static StatusPagamentoEnum getInstance(Integer codigo) {
		
		if (codigo == null) {
			return null;
		}
		
		for (StatusPagamentoEnum tipoIdentidade : StatusPagamentoEnum.values()) {
			if (tipoIdentidade.getCodigo().equals(codigo)) {
				return tipoIdentidade;
			}
		}
		return null;		
	}
	
	public static StatusPagamentoEnum getInstance(String descricao) {
		
		if (descricao == null) {
			return null;
		}
		
		for (StatusPagamentoEnum tipoIdentidade : StatusPagamentoEnum.values()) {
			if (tipoIdentidade.getDescricao().equals(descricao)) {
				return tipoIdentidade;
			}
		}
		return null;		
	}
	
	/**
	 * @return the codigo
	 */
	public Integer getCodigo() {
		return codigo;
	}

	/**
	 * @param codigo the codigo to set
	 */
	public void setCodigo(Integer codigo) {
		this.codigo = codigo;
	}

	/**
	 * @return the descricao
	 */
	public String getDescricao() {
		return descricao;
	}

	/**
	 * @param descricao the descricao to set
	 */
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
}