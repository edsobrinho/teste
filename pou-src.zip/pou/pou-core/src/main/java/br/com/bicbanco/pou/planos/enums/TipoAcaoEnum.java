package br.com.bicbanco.pou.planos.enums;

public enum TipoAcaoEnum {
	
    ORDINARIA(1,"ORDINARIA"),
    CUMPRIMENTO_SENTENCA_ORIGINARIO_ACAO_CIVIL_PUBLICA(2,"CUMPRIMENTO_SENTENCA_ORIGINARIO_ACAO_CIVIL_PUBLICA"),
    EXIBICAO_DOCUMENTOS(3,"EXIBICAO_DOCUMENTOS");
	
	private Integer codigo; 
	private String descricao;
	
	private TipoAcaoEnum(Integer codigo, String descricao) {
		this.codigo = codigo;
		this.descricao = descricao;
	}

	public static TipoAcaoEnum getInstance(Integer codigo) {
		
		if (codigo == null) {
			return null;
		}
		
		for (TipoAcaoEnum tipoIdentidade : TipoAcaoEnum.values()) {
			if (tipoIdentidade.getCodigo().equals(codigo)) {
				return tipoIdentidade;
			}
		}
		return null;		
	}
	
	public static TipoAcaoEnum getInstance(String descricao) {
		
		if (descricao == null) {
			return null;
		}
		
		for (TipoAcaoEnum tipoIdentidade : TipoAcaoEnum.values()) {
			if (tipoIdentidade.getDescricao().equals(descricao)) {
				return tipoIdentidade;
			}
		}
		return null;		
	}
	
	/**
	 * @return the codigo
	 */
	public Integer getCodigo() {
		return codigo;
	}

	/**
	 * @param codigo the codigo to set
	 */
	public void setCodigo(Integer codigo) {
		this.codigo = codigo;
	}

	/**
	 * @return the descricao
	 */
	public String getDescricao() {
		return descricao;
	}

	/**
	 * @param descricao the descricao to set
	 */
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
}