/**
 * 
 */
package br.com.bicbanco.pou.planos.enums;

/**
 * @author opah01
 *
 */
public enum TipoContaEnum {

	CONTA_CORRENTE(1,"CONTA_CORRENTE"),
	POUPANCA(2,"POUPANCA");
	
	private Integer codigo; 
	private String descricao;
	
	private TipoContaEnum(Integer codigo, String descricao) {
		this.codigo = codigo;
		this.descricao = descricao;
	}

	public static TipoContaEnum getInstance(Integer codigo) {
		
		if (codigo == null) {
			return null;
		}
		
		for (TipoContaEnum tipoConta : TipoContaEnum.values()) {
			if (tipoConta.getCodigo().equals(codigo)) {
				return tipoConta;
			}
		}
		return null;		
	}
	
	public static TipoContaEnum getInstance(String descricao) {
		
		if (descricao == null) {
			return null;
		}
		
		for (TipoContaEnum tipoContaEnum : TipoContaEnum.values()) {
			if (tipoContaEnum.getDescricao().equals(descricao)) {
				return tipoContaEnum;
			}
		}
		return null;		
	}
	
	/**
	 * @return the codigo
	 */
	public Integer getCodigo() {
		return codigo;
	}

	/**
	 * @param codigo the codigo to set
	 */
	public void setCodigo(Integer codigo) {
		this.codigo = codigo;
	}

	/**
	 * @return the descricao
	 */
	public String getDescricao() {
		return descricao;
	}

	/**
	 * @param descricao the descricao to set
	 */
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
}