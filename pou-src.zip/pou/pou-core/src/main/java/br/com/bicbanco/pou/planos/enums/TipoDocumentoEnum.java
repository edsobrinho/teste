/**
 * 
 */
package br.com.bicbanco.pou.planos.enums;

/**
 * @author opah01
 *
 */
public enum TipoDocumentoEnum {
    
    RG(1,"RG"),
    RNE(2,"RNE"),
    CPF(3,"CPF"),
    OAB(4,"OAB"),
    OAB_SUPLEMENTAR(5,"OAB_SUPLEMENTAR"),
    TERMO_INVENTARIANTE(6,"TERMO_INVENTARIANTE"),
    COPIA_INVENTARIO(7,"COPIA_INVENTARIO"),
    CERTIDAO_OBITO(8,"CERTIDAO_OBITO"),
    PROCURACAO(9,"PROCURACAO"),
    INICIAL(10,"INICIAL"),
    COPIA_AUTOS(11,"COPIA_AUTOS"),
    TERMO_QUITACAO_PLANOS_ECONOMICOS(12,"TERMO_QUITACAO_PLANOS_ECONOMICOS"),
    PETICAO_REGULARIZACAO_POLO_ATIVO(13,"PETICAO_REGULARIZACAO_POLO_ATIVO"),
    CERTIDAO_CUSTAS(14,"CERTIDAO_CUSTAS"),
    DECLARACAO_VALORES_ACORDOS_PLANOS_ECONOMICOS(15,"DECLARACAO_VALORES_ACORDOS_PLANOS_ECONOMICOS"),
    DIRPF(16,"DIRPF"),
    EXTRATO(17,"EXTRATO"),
    TERMO_ADESAO(18,"TERMO_ADESAO"),
    COMPROVANTE_PAGAMENTO(19,"COMPROVANTE_PAGAMENTO"),
    RACIONAL_CALCULO(20,"RACIONAL_CALCULO");
	
	private Integer codigo; 
	private String descricao;
	
	private TipoDocumentoEnum(Integer codigo, String descricao) {
		this.codigo = codigo;
		this.descricao = descricao;
	}

	public static TipoDocumentoEnum getInstance(Integer codigo) {
		
		if (codigo == null) {
			return null;
		}
		
		for (TipoDocumentoEnum tipoDocumento : TipoDocumentoEnum.values()) {
			if (tipoDocumento.getCodigo().equals(codigo)) {
				return tipoDocumento;
			}
		}
		
		return null;		
	}
	
	public static TipoDocumentoEnum getInstance(String descricao) {
		
		if (descricao == null) {
			return null;
		}
		
		for (TipoDocumentoEnum tipoDocumento : TipoDocumentoEnum.values()) {
			if (tipoDocumento.getDescricao().equals(descricao)) {
				return tipoDocumento;
			}
		}
		
		return null;		
	}
	
	/**
	 * @return the codigo
	 */
	public Integer getCodigo() {
		return codigo;
	}

	/**
	 * @param codigo the codigo to set
	 */
	public void setCodigo(Integer codigo) {
		this.codigo = codigo;
	}

	/**
	 * @return the descricao
	 */
	public String getDescricao() {
		return descricao;
	}

	/**
	 * @param descricao the descricao to set
	 */
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
}