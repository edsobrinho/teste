package br.com.bicbanco.pou.planos.enums;

public enum TipoIdentidadeEnum {
	
    IDENTIDADE(1,"IDENTIDADE"),
    RNE(2,"RNE");
	
	private Integer codigo; 
	private String descricao;
	
	private TipoIdentidadeEnum(Integer codigo, String descricao) {
		this.codigo = codigo;
		this.descricao = descricao;
	}

	public static TipoIdentidadeEnum getInstance(Integer codigo) {
		
		if (codigo == null) {
			return null;
		}
		
		for (TipoIdentidadeEnum tipoIdentidade : TipoIdentidadeEnum.values()) {
			if (tipoIdentidade.getCodigo().equals(codigo)) {
				return tipoIdentidade;
			}
		}
		return null;		
	}
	
	public static TipoIdentidadeEnum getInstance(String descricao) {
		
		if (descricao == null) {
			return null;
		}
		
		for (TipoIdentidadeEnum tipoIdentidade : TipoIdentidadeEnum.values()) {
			if (tipoIdentidade.getDescricao().equals(descricao)) {
				return tipoIdentidade;
			}
		}
		return null;		
	}
	
	/**
	 * @return the codigo
	 */
	public Integer getCodigo() {
		return codigo;
	}

	/**
	 * @param codigo the codigo to set
	 */
	public void setCodigo(Integer codigo) {
		this.codigo = codigo;
	}

	/**
	 * @return the descricao
	 */
	public String getDescricao() {
		return descricao;
	}

	/**
	 * @param descricao the descricao to set
	 */
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

}
