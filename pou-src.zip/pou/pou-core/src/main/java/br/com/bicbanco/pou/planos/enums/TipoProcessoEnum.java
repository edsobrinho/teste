package br.com.bicbanco.pou.planos.enums;

public enum TipoProcessoEnum {
	
	VARA_CIVEL(1,"VARA_CIVEL"),
	VARA_FEDERAL(2,"VARA_FEDERAL"),
	JEF_SEM_ADVOGADO(3,"JEF_SEM_ADVOGADO"),
	JEF_COM_ADVOGADO(4,"JEF_COM_ADVOGADO"),
	JEC_SEM_ADVOGADO(5,"JEC_SEM_ADVOGADO"),
	JEC_COM_ADVOGADO(6,"JEC_COM_ADVOGADO");
	
	private Integer codigo; 
	private String descricao;
	
	private TipoProcessoEnum(Integer codigo, String descricao) {
		this.codigo = codigo;
		this.descricao = descricao;
	}

	public static TipoProcessoEnum getInstance(Integer codigo) {
		
		if (codigo == null) {
			return null;
		}
		
		for (TipoProcessoEnum tipoIdentidade : TipoProcessoEnum.values()) {
			if (tipoIdentidade.getCodigo().equals(codigo)) {
				return tipoIdentidade;
			}
		}
		return null;		
	}
	
	public static TipoProcessoEnum getInstance(String descricao) {
		
		if (descricao == null) {
			return null;
		}
		
		for (TipoProcessoEnum tipoIdentidade : TipoProcessoEnum.values()) {
			if (tipoIdentidade.getDescricao().equals(descricao)) {
				return tipoIdentidade;
			}
		}
		return null;		
	}
	
	/**
	 * @return the codigo
	 */
	public Integer getCodigo() {
		return codigo;
	}

	/**
	 * @param codigo the codigo to set
	 */
	public void setCodigo(Integer codigo) {
		this.codigo = codigo;
	}

	/**
	 * @return the descricao
	 */
	public String getDescricao() {
		return descricao;
	}

	/**
	 * @param descricao the descricao to set
	 */
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
}