package br.com.bicbanco.pou.planos.enums;

public enum TipoResultadoAnaliseHabilitacaoEnum {
	
    HABILITACAO_NEGADA(1,"HABILITACAO_NEGADA"),
    PROPOSTA_DE_ACORDO(2,"PROPOSTA_DE_ACORDO"),
    PROPOSTA_DE_ACORDO_COM_VALOR_DIVERGENTE_SIMULADO(2,"PROPOSTA_DE_ACORDO_COM_VALOR_DIVERGENTE_SIMULADO");
	
	private Integer codigo; 
	private String descricao;
	
	private TipoResultadoAnaliseHabilitacaoEnum(Integer codigo, String descricao) {
		this.codigo = codigo;
		this.descricao = descricao;
	}

	public static TipoResultadoAnaliseHabilitacaoEnum getInstance(Integer codigo) {
		
		if (codigo == null) {
			return null;
		}
		
		for (TipoResultadoAnaliseHabilitacaoEnum tipoIdentidade : TipoResultadoAnaliseHabilitacaoEnum.values()) {
			if (tipoIdentidade.getCodigo().equals(codigo)) {
				return tipoIdentidade;
			}
		}
		return null;		
	}
	
	public static TipoResultadoAnaliseHabilitacaoEnum getInstance(String descricao) {
		
		if (descricao == null) {
			return null;
		}
		
		for (TipoResultadoAnaliseHabilitacaoEnum tipoIdentidade : TipoResultadoAnaliseHabilitacaoEnum.values()) {
			if (tipoIdentidade.getDescricao().equals(descricao)) {
				return tipoIdentidade;
			}
		}
		return null;		
	}
	
	/**
	 * @return the codigo
	 */
	public Integer getCodigo() {
		return codigo;
	}

	/**
	 * @param codigo the codigo to set
	 */
	public void setCodigo(Integer codigo) {
		this.codigo = codigo;
	}

	/**
	 * @return the descricao
	 */
	public String getDescricao() {
		return descricao;
	}

	/**
	 * @param descricao the descricao to set
	 */
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

}
