/**
 * 
 */
package br.com.bicbanco.pou.planos.service;

import java.util.List;

import br.com.bicbanco.bicbase.exceptions.ServiceException;
import br.com.bicbanco.bicbase.service.Service;
import br.com.bicbanco.pou.planos.to.InformacoesPedidoTO;

/**
 * @author opah01
 *
 */
public interface InformacoesPedidoService extends Service {

	/**
	 * @return
	 * @throws ServiceException
	 */
	List<InformacoesPedidoTO> listInformacoesPedido() throws ServiceException;
}
