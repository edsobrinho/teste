package br.com.bicbanco.pou.service;

import java.util.List;

import br.com.bicbanco.bicbase.exceptions.ServiceException;
import br.com.bicbanco.bicbase.service.Service;
import br.com.bicbanco.ctt.exceptions.ProdutoClienteContaException;
import br.com.bicbanco.pou.to.InformacoesContaTO;

public interface InformacoesContaService extends Service {

	/**
	 * @param codSuc
	 * @return
	 * @throws ServiceException
	 */
	List<InformacoesContaTO> listInformacoesConta(Integer codSuc) throws ServiceException;

	/**
	 * @param to
	 * @throws ProdutoClienteContaException
	 * @throws ServiceException
	 */
	void insertCoTitular(InformacoesContaTO to) throws ProdutoClienteContaException, ServiceException;

	/**
	 * @param to
	 * @throws ProdutoClienteContaException
	 * @throws ServiceException
	 */
	void updateCoTitular(InformacoesContaTO to) throws ProdutoClienteContaException, ServiceException;

	/**
	 * @param to
	 * @throws ProdutoClienteContaException
	 * @throws ServiceException
	 */
	void deleteCoTitular(InformacoesContaTO to) throws ProdutoClienteContaException, ServiceException;

	/**
	 * @param suc
	 * @return
	 * @throws ServiceException
	 */
	String getNomePessoa(Integer suc) throws ServiceException;

	/**
	 * @param codigoOrgao
	 * @param codSuc
	 * @param numeroConta
	 * @return
	 * @throws ServiceException 
	 */
	InformacoesContaTO getInformacoesConta(Integer codigoOrgao, Integer codSuc, Integer numeroConta) throws ServiceException;

}
