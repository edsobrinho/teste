/**
 * 
 */
package br.com.bicbanco.pou.service;

import java.util.Collection;
import java.util.Date;

import br.com.bicbanco.bicbase.exceptions.ServiceException;
import br.com.bicbanco.bicbase.service.Service;
import br.com.bicbanco.pou.dto.AniversarioDTO;
import br.com.bicbanco.pou.dto.ContaPoupancaDTO;
import br.com.bicbanco.pou.dto.ExtratoContaPoupancaDTO;
import br.com.bicbanco.pou.dto.MovimentoDTO;

/**
 * @author b090020
 *
 */
public interface PoupancaService extends Service {

	/**
	 * @param codOrgao
	 * @param codPlataforma
	 * @param codModalidade
	 * @param numConta
	 * @return
	 */
	Collection<AniversarioDTO> listAniversarios(Integer codOrgao,
			Integer codPlataforma, Integer numConta);

	/**
	 * @param codOrgao
	 * @param codPlataforma
	 * @param codModalidade
	 * @param numConta
	 * @param dataAniversario
	 * @return
	 */
	Collection<MovimentoDTO> listMovimentos(Integer codOrgao,
			Integer codPlataforma, Integer numConta, Date dataAniversario);

	/**
	 * List conta poupanca por agencia conta.
	 * 
	 * @param codOrgao the cod orgao
	 * @param numConta the num conta
	 * @return the collection
	 * @throws ServiceException the service exception
	 */
	Collection<ContaPoupancaDTO> listContaPoupancaPorAgenciaConta(Integer codOrgao, Integer numConta) throws ServiceException;

	/**
	 * List conta poupanca por cnpj.
	 * 
	 * @param raizCnpj the raiz cnpj
	 * @param filialCnpj the filial cnpj
	 * @param digitoCnpj the digito cnpj
	 * @return the collection
	 * @throws ServiceException the service exception
	 */
	Collection<ContaPoupancaDTO> listContaPoupancaPorCnpj(Integer raizCnpj, Integer filialCnpj, Integer digitoCnpj) throws ServiceException;

	/**
	 * List conta poupanca por cpf.
	 * 
	 * @param raizCpf the raiz cpf
	 * @param digitoCpf the digito cpf
	 * @return the collection
	 * @throws ServiceException the service exception
	 */
	Collection<ContaPoupancaDTO> listContaPoupancaPorCpf(Integer raizCpf, Integer digitoCpf) throws ServiceException;

	/**
	 * List extrato conta poupanca.
	 *
	 * @param codOrgao the cod orgao
	 * @param numConta the num conta
	 * @param dataLanctoInicial the data lancto inicial
	 * @param dataLanctoFinal the data lancto final
	 * @return the collection
	 * @throws ServiceException the service exception
	 */
	public Collection<ExtratoContaPoupancaDTO> listExtratoContaPoupanca(Integer codOrgao, Integer numConta, Date dataLanctoInicial,
			Date dataLanctoFinal) throws ServiceException;

}
