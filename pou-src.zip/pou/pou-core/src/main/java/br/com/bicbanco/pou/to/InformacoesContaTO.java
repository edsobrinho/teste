package br.com.bicbanco.pou.to;

import java.io.Serializable;
import java.util.Date;

import br.com.bicbanco.bicbase.dto.BaseTO;

public class InformacoesContaTO extends BaseTO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5882176868025253651L;
	
	private Integer codOrgao;
	private Integer codPlataforma;
	private Integer numConta;
	private Date dataAbertura;
	private Integer codGerente;
	private Boolean isPFTitular;
	private Integer sucTitular;
	private Date dataNascimentoTitular;
	private String nomeTitular;
	private Long cpfCnpjTitular;
	private Boolean isClienteCCBTitular;
	private Boolean isDadosFATCAInformadoTitular;
	private Boolean isClienteVencidoTitular;
	private Boolean isPFCoTitular;
	private Integer sucCoTitular;
	private Integer sucCoTitularAnterior;
	private Date dataNascimentoCoTitular;
	private String nomeCoTitular;
	private Long cpfCnpjCoTitular;
	private Boolean isClienteCCBCoTitular;
	private Boolean isDadosFATCAInformadoCoTitular;
	private Boolean isClienteVencidoCoTitular;
	



	/**
	 * @return the codOrgao
	 */
	public Integer getCodOrgao() {
		return codOrgao;
	}



	/**
	 * @param codOrgao the codOrgao to set
	 */
	public void setCodOrgao(Integer codOrgao) {
		this.codOrgao = codOrgao;
	}



	/**
	 * @return the numConta
	 */
	public Integer getNumConta() {
		return numConta;
	}



	/**
	 * @param numConta the numConta to set
	 */
	public void setNumConta(Integer numConta) {
		this.numConta = numConta;
	}



	/**
	 * @return the dataAbertura
	 */
	public Date getDataAbertura() {
		return dataAbertura;
	}



	/**
	 * @param dataAbertura the dataAbertura to set
	 */
	public void setDataAbertura(Date dataAbertura) {
		this.dataAbertura = dataAbertura;
	}



	/**
	 * @return the sucTitular
	 */
	public Integer getSucTitular() {
		return sucTitular;
	}



	/**
	 * @param sucTitular the sucTitular to set
	 */
	public void setSucTitular(Integer sucTitular) {
		this.sucTitular = sucTitular;
	}



	/**
	 * @return the nomeTitular
	 */
	public String getNomeTitular() {
		return nomeTitular;
	}



	/**
	 * @param nomeTitular the nomeTitular to set
	 */
	public void setNomeTitular(String nomeTitular) {
		this.nomeTitular = nomeTitular;
	}



	/**
	 * @return the sucCoTitular
	 */
	public Integer getSucCoTitular() {
		return sucCoTitular;
	}



	/**
	 * @param sucCoTitular the sucCoTitular to set
	 */
	public void setSucCoTitular(Integer sucCoTitular) {
		this.sucCoTitular = sucCoTitular;
	}



	/**
	 * @return the nomeCoTitular
	 */
	public String getNomeCoTitular() {
		return nomeCoTitular;
	}



	/**
	 * @param nomeCoTitular the nomeCoTitular to set
	 */
	public void setNomeCoTitular(String nomeCoTitular) {
		this.nomeCoTitular = nomeCoTitular;
	}


	public Integer getCodPlataforma() {
		return codPlataforma;
	}
	
	
	
	public void setCodPlataforma(Integer codPlataforma) {
		this.codPlataforma = codPlataforma;
	}
	
	public Integer getCodGerente() {
		return codGerente;
	}
	
	
	
	public void setCodGerente(Integer codGerente) {
		this.codGerente = codGerente;
	}
	
	


	/**
	 * @return the dataNascimentoTitular
	 */
	public Date getDataNascimentoTitular() {
		return dataNascimentoTitular;
	}



	/**
	 * @param dataNascimentoTitular the dataNascimentoTitular to set
	 */
	public void setDataNascimentoTitular(Date dataNascimentoTitular) {
		this.dataNascimentoTitular = dataNascimentoTitular;
	}



	/**
	 * @return the cpfCnpjTitular
	 */
	public Long getCpfCnpjTitular() {
		return cpfCnpjTitular;
	}



	/**
	 * @param cpfCnpjTitular the cpfCnpjTitular to set
	 */
	public void setCpfCnpjTitular(Long cpfCnpjTitular) {
		this.cpfCnpjTitular = cpfCnpjTitular;
	}



	/**
	 * @return the dataNascimentoCoTitular
	 */
	public Date getDataNascimentoCoTitular() {
		return dataNascimentoCoTitular;
	}



	/**
	 * @param dataNascimentoCoTitular the dataNascimentoCoTitular to set
	 */
	public void setDataNascimentoCoTitular(Date dataNascimentoCoTitular) {
		this.dataNascimentoCoTitular = dataNascimentoCoTitular;
	}



	/**
	 * @return the cpfCnpjCoTitular
	 */
	public Long getCpfCnpjCoTitular() {
		return cpfCnpjCoTitular;
	}



	/**
	 * @param cpfCnpjCoTitular the cpfCnpjCoTitular to set
	 */
	public void setCpfCnpjCoTitular(Long cpfCnpjCoTitular) {
		this.cpfCnpjCoTitular = cpfCnpjCoTitular;
	}



	@Override
	public Serializable getKey() {
		// TODO Auto-generated method stub
		return new Serializable[]{codOrgao, codPlataforma, numConta};
	}


	/**
	 * @return the isClienteCCBTitular
	 */
	public Boolean getIsClienteCCBTitular() {
		return isClienteCCBTitular;
	}



	/**
	 * @param isClienteCCBTitular the isClienteCCBTitular to set
	 */
	public void setIsClienteCCBTitular(Boolean isClienteCCBTitular) {
		this.isClienteCCBTitular = isClienteCCBTitular;
	}



	/**
	 * @return the isDadosFATCAInformadoTitular
	 */
	public Boolean getIsDadosFATCAInformadoTitular() {
		return isDadosFATCAInformadoTitular;
	}



	/**
	 * @param isDadosFATCAInformadoTitular the isDadosFATCAInformadoTitular to set
	 */
	public void setIsDadosFATCAInformadoTitular(Boolean isDadosFATCAInformadoTitular) {
		this.isDadosFATCAInformadoTitular = isDadosFATCAInformadoTitular;
	}



	/**
	 * @return the isClienteVencidoTitular
	 */
	public Boolean getIsClienteVencidoTitular() {
		return isClienteVencidoTitular;
	}



	/**
	 * @param isClienteVencidoTitular the isClienteVencidoTitular to set
	 */
	public void setIsClienteVencidoTitular(Boolean isClienteVencidoTitular) {
		this.isClienteVencidoTitular = isClienteVencidoTitular;
	}



	/**
	 * @return the isClienteCCBCoTitular
	 */
	public Boolean getIsClienteCCBCoTitular() {
		return isClienteCCBCoTitular;
	}



	/**
	 * @param isClienteCCBCoTitular the isClienteCCBCoTitular to set
	 */
	public void setIsClienteCCBCoTitular(Boolean isClienteCCBCoTitular) {
		this.isClienteCCBCoTitular = isClienteCCBCoTitular;
	}



	/**
	 * @return the isDadosFATCAInformadoCoTitular
	 */
	public Boolean getIsDadosFATCAInformadoCoTitular() {
		return isDadosFATCAInformadoCoTitular;
	}



	/**
	 * @param isDadosFATCAInformadoCoTitular the isDadosFATCAInformadoCoTitular to set
	 */
	public void setIsDadosFATCAInformadoCoTitular(Boolean isDadosFATCAInformadoCoTitular) {
		this.isDadosFATCAInformadoCoTitular = isDadosFATCAInformadoCoTitular;
	}



	/**
	 * @return the isClienteVencidoCoTitular
	 */
	public Boolean getIsClienteVencidoCoTitular() {
		return isClienteVencidoCoTitular;
	}



	/**
	 * @param isClienteVencidoCoTitular the isClienteVencidoCoTitular to set
	 */
	public void setIsClienteVencidoCoTitular(Boolean isClienteVencidoCoTitular) {
		this.isClienteVencidoCoTitular = isClienteVencidoCoTitular;
	}



	public Boolean getIsPFTitular() {
		return isPFTitular;
	}



	public void setIsPFTitular(Boolean isPFTitular) {
		this.isPFTitular = isPFTitular;
	}



	public Boolean getIsPFCoTitular() {
		return isPFCoTitular;
	}



	public void setIsPFCoTitular(Boolean isPFCoTitular) {
		this.isPFCoTitular = isPFCoTitular;
	}



	public Integer getSucCoTitularAnterior() {
		return sucCoTitularAnterior;
	}



	public void setSucCoTitularAnterior(Integer sucCoTitularAnterior) {
		this.sucCoTitularAnterior = sucCoTitularAnterior;
	}

	public void zerarDadosCoTitular(){
		isPFCoTitular = null;
		sucCoTitular = null;
		sucCoTitularAnterior = null;
		dataNascimentoCoTitular = null;
		nomeCoTitular = null;
		cpfCnpjCoTitular = null;
		isClienteCCBCoTitular = null;
		isDadosFATCAInformadoCoTitular = null;
		isClienteVencidoCoTitular = null;
	}
}
