package br.com.bicbanco.pou.to;

import java.io.Serializable;
import java.util.Date;

import br.com.bicbanco.bicbase.dto.BaseTO;
import net.sf.layoutParser.util.annotation.ParsableBean;

@ParsableBean
public class MensagemFepScadTO
extends BaseTO
{

	/**
	 * 
	 */
	private static final long serialVersionUID = -1423359526557817497L;
	private String codigoTransacao;
	private String identificacaoCanal;
	private Integer anoMovimento;
	private Integer mesMovimento;
	private Integer diaMovimento;
	private Integer numeroSequencialUnico;
	private String meioOrigem;
	private Integer codigoAgencia;
	private Integer numeroConta;
	private Integer codigoGerente;
	private String tipoPessoa;
	private Integer codigoPrimeiroTitular;
	private Date dataNascimentoPrimeiroTitular;
	private String nomePrimeiroTitular;
	private Long cpfCnpjPrimeiroTitular;
	private Integer codigoSegundoTitular;
	private Date dataNascimentoSegundoTitular;
	private String nomeSegundoTitular;
	private Long cpfCnpjSegundoTitular;
	private String indicadorTalaoCheques;
	private String indicadorVencimentoCadastralPrimeiroTitular;
	private String indicadorVencimentoCadastralSegundoTitular;
	private String indicadorFatcaPrimeiroTitular;
	private String indicadorFatcaSegundoTitular;
	private String indicadorTipoClientePrimeiroTitular;
	private String indicadorTipoClienteSegundoTitular;

	public Serializable getKey()
	{
		return this.numeroSequencialUnico;
	}

	public String getCodigoTransacao()
	{
		return this.codigoTransacao;
	}

	public void setCodigoTransacao(String codigoTransacao)
	{
		this.codigoTransacao = codigoTransacao;
	}

	public String getIdentificacaoCanal()
	{
		return this.identificacaoCanal;
	}

	public void setIdentificacaoCanal(String identificacaoCanal)
	{
		this.identificacaoCanal = identificacaoCanal;
	}

	public Integer getAnoMovimento()
	{
		return this.anoMovimento;
	}

	public void setAnoMovimento(Integer anoMovimento)
	{
		this.anoMovimento = anoMovimento;
	}

	public Integer getMesMovimento()
	{
		return this.mesMovimento;
	}

	public void setMesMovimento(Integer mesMovimento)
	{
		this.mesMovimento = mesMovimento;
	}

	public Integer getDiaMovimento()
	{
		return this.diaMovimento;
	}

	public void setDiaMovimento(Integer diaMovimento)
	{
		this.diaMovimento = diaMovimento;
	}

	public Integer getNumeroSequencialUnico()
	{
		return this.numeroSequencialUnico;
	}

	public void setNumeroSequencialUnico(Integer numeroSequencialUnico)
	{
		this.numeroSequencialUnico = numeroSequencialUnico;
	}

	public String getMeioOrigem()
	{
		return this.meioOrigem;
	}

	public void setMeioOrigem(String meioOrigem)
	{
		this.meioOrigem = meioOrigem;
	}

	public Integer getCodigoAgencia()
	{
		return this.codigoAgencia;
	}

	public void setCodigoAgencia(Integer codigoAgencia)
	{
		this.codigoAgencia = codigoAgencia;
	}

	public Integer getNumeroConta()
	{
		return this.numeroConta;
	}

	public void setNumeroConta(Integer numeroConta)
	{
		this.numeroConta = numeroConta;
	}

	public Integer getCodigoGerente()
	{
		return this.codigoGerente;
	}

	public void setCodigoGerente(Integer codigoGerente)
	{
		this.codigoGerente = codigoGerente;
	}

	public String getTipoPessoa()
	{
		return this.tipoPessoa;
	}

	public void setTipoPessoa(String tipoPessoa)
	{
		this.tipoPessoa = tipoPessoa;
	}

	public Integer getCodigoPrimeiroTitular()
	{
		return this.codigoPrimeiroTitular;
	}

	public void setCodigoPrimeiroTitular(Integer codigoPrimeiroTitular)
	{
		this.codigoPrimeiroTitular = codigoPrimeiroTitular;
	}

	public Date getDataNascimentoPrimeiroTitular()
	{
		return this.dataNascimentoPrimeiroTitular;
	}

	public void setDataNascimentoPrimeiroTitular(Date dataNascimentoPrimeiroTitular)
	{
		this.dataNascimentoPrimeiroTitular = dataNascimentoPrimeiroTitular;
	}

	public String getNomePrimeiroTitular()
	{
		return this.nomePrimeiroTitular;
	}

	public void setNomePrimeiroTitular(String nomePrimeiroTitular)
	{
		this.nomePrimeiroTitular = nomePrimeiroTitular;
	}

	public Long getCpfCnpjPrimeiroTitular()
	{
		return this.cpfCnpjPrimeiroTitular;
	}

	public void setCpfCnpjPrimeiroTitular(Long cpfCnpjPrimeiroTitular)
	{
		this.cpfCnpjPrimeiroTitular = cpfCnpjPrimeiroTitular;
	}

	public Integer getCodigoSegundoTitular()
	{
		return this.codigoSegundoTitular;
	}

	public void setCodigoSegundoTitular(Integer codigoSegundoTitular)
	{
		this.codigoSegundoTitular = codigoSegundoTitular;
	}

	public Date getDataNascimentoSegundoTitular()
	{
		return this.dataNascimentoSegundoTitular;
	}

	public void setDataNascimentoSegundoTitular(Date dataNascimentoSegundoTitular)
	{
		this.dataNascimentoSegundoTitular = dataNascimentoSegundoTitular;
	}

	public String getNomeSegundoTitular()
	{
		return this.nomeSegundoTitular;
	}

	public void setNomeSegundoTitular(String nomeSegundoTitular)
	{
		this.nomeSegundoTitular = nomeSegundoTitular;
	}

	public Long getCpfCnpjSegundoTitular()
	{
		return this.cpfCnpjSegundoTitular;
	}

	public void setCpfCnpjSegundoTitular(Long cpfCnpjSegundoTitular)
	{
		this.cpfCnpjSegundoTitular = cpfCnpjSegundoTitular;
	}

	public String getIndicadorTalaoCheques()
	{
		return this.indicadorTalaoCheques;
	}

	public void setIndicadorTalaoCheques(String indicadorTalaoCheques)
	{
		this.indicadorTalaoCheques = indicadorTalaoCheques;
	}

	public String getIndicadorVencimentoCadastralPrimeiroTitular()
	{
		return this.indicadorVencimentoCadastralPrimeiroTitular;
	}

	public void setIndicadorVencimentoCadastralPrimeiroTitular(String indicadorVencimentoCadastralPrimeiroTitular)
	{
		this.indicadorVencimentoCadastralPrimeiroTitular = indicadorVencimentoCadastralPrimeiroTitular;
	}

	public String getIndicadorVencimentoCadastralSegundoTitular()
	{
		return this.indicadorVencimentoCadastralSegundoTitular;
	}

	public void setIndicadorVencimentoCadastralSegundoTitular(String indicadorVencimentoCadastralSegundoTitular)
	{
		this.indicadorVencimentoCadastralSegundoTitular = indicadorVencimentoCadastralSegundoTitular;
	}

	public String getIndicadorFatcaPrimeiroTitular()
	{
		return this.indicadorFatcaPrimeiroTitular;
	}

	public void setIndicadorFatcaPrimeiroTitular(String indicadorFatcaPrimeiroTitular)
	{
		this.indicadorFatcaPrimeiroTitular = indicadorFatcaPrimeiroTitular;
	}

	public String getIndicadorFatcaSegundoTitular()
	{
		return this.indicadorFatcaSegundoTitular;
	}

	public void setIndicadorFatcaSegundoTitular(String indicadorFatcaSegundoTitular)
	{
		this.indicadorFatcaSegundoTitular = indicadorFatcaSegundoTitular;
	}

	public String getIndicadorTipoClientePrimeiroTitular()
	{
		return this.indicadorTipoClientePrimeiroTitular;
	}

	public void setIndicadorTipoClientePrimeiroTitular(String indicadorTipoClientePrimeiroTitular)
	{
		this.indicadorTipoClientePrimeiroTitular = indicadorTipoClientePrimeiroTitular;
	}

	public String getIndicadorTipoClienteSegundoTitular()
	{
		return this.indicadorTipoClienteSegundoTitular;
	}

	public void setIndicadorTipoClienteSegundoTitular(String indicadorTipoClienteSegundoTitular)
	{
		this.indicadorTipoClienteSegundoTitular = indicadorTipoClienteSegundoTitular;
	}
}
