/**
 * 
 */
package br.com.bicbanco.pou.impl.service.test;

import org.apache.commons.lang.ArrayUtils;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import org.junit.Ignore;

/**
 * @author b090020
 *
 */
@Ignore
public final class BeanFactory {
	private static ApplicationContext context;
	private static String[]lastContext;
	private BeanFactory (){	}		
	
	@SuppressWarnings("unchecked")
	public static <T> T getBean(Class<T> beanInterface) {

		String className = beanInterface.getSimpleName();
		String attributeName = className.substring(0, 1).toLowerCase() + className.substring(1, className.length());
		return (T) getBean(attributeName);
	}
	
	public static Object getBean(String nome) {		
		
		if(context == null)throw new IllegalStateException("Contexto Nulo.");
		
		return context.getBean(nome);
		
	}
	
	public static void setContext(String...strings){
		if(context==null || !ArrayUtils.isEquals(strings, lastContext)){
			context = new ClassPathXmlApplicationContext(strings);
		
		}
	}
}
