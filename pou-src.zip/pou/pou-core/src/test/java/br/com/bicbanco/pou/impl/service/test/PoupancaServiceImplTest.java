/**
 * 
 */
package br.com.bicbanco.pou.impl.service.test;

import static br.com.bicbanco.pou.impl.service.test.BeanFactory.getBean;
import static br.com.bicbanco.pou.impl.service.test.BeanFactory.setContext;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;

import org.junit.Before;
import org.junit.Test;

import br.com.bicbanco.bicbase.exceptions.ServiceException;
import br.com.bicbanco.pou.dto.AniversarioDTO;
import br.com.bicbanco.pou.dto.ContaPoupancaDTO;
import br.com.bicbanco.pou.dto.ExtratoContaPoupancaDTO;
import br.com.bicbanco.pou.dto.MovimentoDTO;
import br.com.bicbanco.pou.service.PoupancaService;

import org.junit.Ignore;

/**
 * @author b090020
 * 
 */

 @Ignore
public class PoupancaServiceImplTest {

	private PoupancaService poupancaService;
	private Integer codOrgao;
	private Integer codPlataforma;
	private Integer numConta;
	private Date dataAniversario;

	//@Test
	public void listAniversarios() {
		Collection<AniversarioDTO> listAniversarios = poupancaService.listAniversarios(codOrgao, codPlataforma, numConta);
		assertNotNull(listAniversarios);
		assertTrue(!listAniversarios.isEmpty());
	}

	//@Test
	public void listMovimentos() {
		Collection<MovimentoDTO> listMovimentos = poupancaService.listMovimentos(codOrgao, codPlataforma, numConta, dataAniversario);
		assertNotNull(listMovimentos);
		assertTrue(!listMovimentos.isEmpty());
	}

	//@Test
	public void listContaPoupancaAgenciaConta() {
		// Primeiro where
		Collection<ContaPoupancaDTO> list = null;
		try {
			list = poupancaService.listContaPoupancaPorAgenciaConta(3, 1389);
		} catch (ServiceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		assertNotNull(list);
		assertTrue(!list.isEmpty());
		assertTrue(list.size() == 1);
	}

	@Test
	public void listContaPoupancaCpf() {
		Collection<ContaPoupancaDTO> list = null;
		try {
			list = poupancaService.listContaPoupancaPorCpf(141041213, 4);
		} catch (ServiceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		assertNotNull(list);
		assertTrue(!list.isEmpty());
		assertTrue(list.size() == 1);
	}

	//@Test
	public void listContaPoupancaCnpj() {
		Collection<ContaPoupancaDTO> list = null;
		try {
			list = poupancaService.listContaPoupancaPorCnpj(76486828, 1, 63);
		} catch (ServiceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		assertNotNull(list);
		assertTrue(!list.isEmpty());
		assertTrue(list.size() == 1);
	}
	
	//@Test
	public void listExtratoContaPoupanca() {
		Collection<ExtratoContaPoupancaDTO> list = null;
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		try {
			Date dataLanctoInicial = sdf.parse("13/10/2012");
			Date dataLanctoFinal = sdf.parse("20/10/2012");
			list = poupancaService.listExtratoContaPoupanca(3, 625, dataLanctoInicial, dataLanctoFinal);
			assertTrue(!list.isEmpty());
			assertTrue(list.size() == 1);
		}
		catch (ServiceException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		}
	}
	

	public String[] getSpringContext() {
		return new String[] { "/spring/POU-applicationContext-test.xml" };
	}

	@Before
	public void setUp() throws Exception {
		setContext(getSpringContext());
		poupancaService = (PoupancaService) getBean(PoupancaService.class);
		codOrgao = 7;
		codPlataforma = 7;
		numConta = 55490;
		dataAniversario = new Date(109, 7, 21);
	}

}
