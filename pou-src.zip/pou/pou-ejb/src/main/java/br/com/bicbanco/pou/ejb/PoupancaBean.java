/**
 * 
 */
package br.com.bicbanco.pou.ejb;

import java.util.Collection;
import java.util.Date;

import javax.ejb.CreateException;

import org.apache.log4j.Logger;

import br.com.bicbanco.bicbase.ejb.BicBaseEJBSession;
import br.com.bicbanco.bicbase.exceptions.ServiceException;
import br.com.bicbanco.pou.dto.AniversarioDTO;
import br.com.bicbanco.pou.dto.ContaPoupancaDTO;
import br.com.bicbanco.pou.dto.ExtratoContaPoupancaDTO;
import br.com.bicbanco.pou.dto.MovimentoDTO;
import br.com.bicbanco.pou.facade.PoupancaFacade;
import br.com.bicbanco.pou.service.PoupancaService;

/**
 * @ejb.bean name="Poupanca" type="Stateless" view-type="both" display-name="Poupanca" jndi-name="ejb/Poupanca" transaction-type="Bean"
 * @ejb.home extends="br.com.bicbanco.bicbase.service.Service, javax.ejb.EJBHome" local-extends="javax.ejb.EJBLocalHome"
 * @ejb.interface extends="br.com.bicbanco.bicbase.service.Service,  javax.ejb.EJBObject" local-extends="javax.ejb.EJBLocalObject"
 */
public class PoupancaBean extends BicBaseEJBSession implements PoupancaFacade{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final Logger	logger				= Logger.getLogger(PoupancaBean.class);
	
	private PoupancaService poupancaService;
	
	/**
	 * @ejb.interface-method view-type="both"
	 */
	public Collection<AniversarioDTO> listAniversarios(Integer codOrgao, Integer codPlataforma, Integer numConta) {
		return poupancaService.listAniversarios(codOrgao, codPlataforma, numConta);
	}
	
	/**
	 * @ejb.interface-method view-type="both"
	 */
	public Collection<MovimentoDTO> listMovimentos(Integer codOrgao, Integer codPlataforma, Integer numConta, Date dataAniversario) {
		return poupancaService.listMovimentos(codOrgao, codPlataforma, numConta, dataAniversario);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see br.com.bicbanco.bicbase.ejb.BicBaseEJBSession#getBeanRefContextName()
	 */
	@Override
	public String getBeanRefContextName() {
		return "/spring/beanRefPOUContext.xml";
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.springframework.ejb.support.AbstractStatelessSessionBean#onEjbCreate()
	 */
	@Override
	protected void onEjbCreate() throws CreateException {
		logger.info("PoupancaServiceBean.onEjbCreate()");
		poupancaService = (PoupancaService) getBeanFactory().getBean("poupancaService");
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see br.com.bicbanco.pou.facade.PoupancaFacade#listContaPoupancaPorAgenciaConta(java.lang.Integer, java.lang.Integer)
	 */
	/**
	 * @ejb.interface-method view-type="both"
	 */
	public Collection<ContaPoupancaDTO> listContaPoupancaPorAgenciaConta(Integer codOrgao, Integer numConta) throws ServiceException {
		return poupancaService.listContaPoupancaPorAgenciaConta(codOrgao, numConta);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see br.com.bicbanco.pou.facade.PoupancaFacade#listContaPoupancaPorCnpj(java.lang.Integer, java.lang.Integer, java.lang.Integer)
	 */
	/**
	 * @ejb.interface-method view-type="both"
	 */
	public Collection<ContaPoupancaDTO> listContaPoupancaPorCnpj(Integer raizCnpj, Integer filialCnpj, Integer digitoCnpj) throws ServiceException {
		return poupancaService.listContaPoupancaPorCnpj(raizCnpj, filialCnpj, digitoCnpj);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see br.com.bicbanco.pou.facade.PoupancaFacade#listContaPoupancaPorCpf(java.lang.Integer, java.lang.Integer)
	 */
	/**
	 * @ejb.interface-method view-type="both"
	 */
	public Collection<ContaPoupancaDTO> listContaPoupancaPorCpf(Integer raizCpf, Integer digitoCpf) throws ServiceException {
		return poupancaService.listContaPoupancaPorCpf(raizCpf, digitoCpf);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see br.com.bicbanco.pou.facade.PoupancaFacade#listExtratoContaPoupanca(java.lang.Integer, java.lang.Integer, java.util.Date, java.util.Date)
	 */
	/**
	 * @ejb.interface-method view-type="both"
	 */
	public Collection<ExtratoContaPoupancaDTO> listExtratoContaPoupanca(Integer codOrgao, Integer numConta, Date dataLanctoInicial,
			Date dataLanctoFinal) throws ServiceException {
		return poupancaService.listExtratoContaPoupanca(codOrgao, numConta, dataLanctoInicial, dataLanctoFinal);
	}

}
