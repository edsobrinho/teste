/**
 * 
 */
package br.com.bicbanco.pou.facade;

import java.util.Collection;
import java.util.Date;

import br.com.bicbanco.bicbase.exceptions.ServiceException;
import br.com.bicbanco.pou.dto.AniversarioDTO;
import br.com.bicbanco.pou.dto.ContaPoupancaDTO;
import br.com.bicbanco.pou.dto.ExtratoContaPoupancaDTO;
import br.com.bicbanco.pou.dto.MovimentoDTO;

/**
 * @author b090020
 *
 */
public interface PoupancaFacade {

	public Collection<AniversarioDTO> listAniversarios(Integer codOrgao, Integer codPlataforma, Integer numConta);
	
	public Collection<MovimentoDTO> listMovimentos(Integer codOrgao, Integer codPlataforma, Integer numConta, Date dataAniversario);

	public Collection<ContaPoupancaDTO> listContaPoupancaPorAgenciaConta(Integer codOrgao, Integer numConta) throws ServiceException;

	public Collection<ContaPoupancaDTO> listContaPoupancaPorCnpj(Integer raizCnpj, Integer filialCnpj, Integer digitoCnpj) throws ServiceException;

	public Collection<ContaPoupancaDTO> listContaPoupancaPorCpf(Integer raizCpf, Integer digitoCpf) throws ServiceException;

	public Collection<ExtratoContaPoupancaDTO> listExtratoContaPoupanca(Integer codOrgao, Integer numConta, Date dataLanctoInicial,
			Date dataLanctoFinal) throws ServiceException;
	
}
