package br.com.bicbanco.pou.facade;

import java.util.Collection;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import br.com.bicbanco.pou.dto.AniversarioDTO;

import org.junit.Ignore;

@Ignore
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:/spring/POU-applicationContextEJB-test.xml" })
public class PoupancaFacadeTest {                      


    private ApplicationContext applicationContext;
    private  PoupancaFacade  poupancaFacade;

    @Autowired
    public void setApplicationContext(ApplicationContext applicationContext) {
        this.applicationContext = applicationContext;
    }

    @Before
    public void init() throws Exception {
    	 poupancaFacade = applicationContext.getBean( PoupancaFacade.class);
    }

    @Test
    public void testFindAniversario() throws Exception {    	
    	Integer codOrgao = 7;
    	Integer codPlataforma = 7;
    	Integer numConta = 55490;
    	Collection<AniversarioDTO> listAniversarios = poupancaFacade.listAniversarios(codOrgao, codPlataforma, numConta);
        System.out.println(">>" + listAniversarios.size());
        for (AniversarioDTO aniversarioDTO : listAniversarios) {
			System.out.println(aniversarioDTO.getDataAniversario());
		}
    }    
}
