package br.com.bicbanco.pou.converter;
/**
 * 
 */


import java.text.DecimalFormat;
import java.text.MessageFormat;
import java.util.Locale;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;

/**
*
* @jsf.converter name="contaCorrenteConverter"
*/
public class ContaCorrenteConverter implements Converter {

	private static final DecimalFormat df = new DecimalFormat("000000000");
	private static final MessageFormat msgFormat = new MessageFormat("{0}.{1}-{2}", new Locale("pt","BR"));
	
	/* (non-Javadoc)
	 * @see javax.faces.convert.Converter#getAsObject(javax.faces.context.FacesContext, javax.faces.component.UIComponent, java.lang.String)
	 */
	public Object getAsObject(FacesContext context, UIComponent component,
			String value) {
		throw new UnsupportedOperationException();
	}

	/* (non-Javadoc)
	 * @see javax.faces.convert.Converter#getAsString(javax.faces.context.FacesContext, javax.faces.component.UIComponent, java.lang.Object)
	 */
	public String getAsString(FacesContext context, UIComponent component,
			Object value) {
		String result = "";
		if(value != null && value instanceof Number){
			result = getFormatado((Number) value);
		}else if(value != null && value instanceof String){
			String valueString = (String) value;
			result = getFormatado(new Long(valueString.trim()));
		}
		return result;
	}
	
	private String getFormatado(Number value){
			String valueString= df.format(value);
			String[] valueArr={valueString.substring(0, 2),
					valueString.substring(2,8),
				valueString.substring(8,valueString.length())};
		return  msgFormat.format(valueArr);
	}
}
