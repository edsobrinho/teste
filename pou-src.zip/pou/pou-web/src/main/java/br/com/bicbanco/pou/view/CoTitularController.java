package br.com.bicbanco.pou.view;

import java.util.List;

import org.ajax4jsf.model.KeepAlive;
import org.apache.log4j.Logger;

import br.com.bicbanco.bicbase.exceptions.ServiceException;
import br.com.bicbanco.bicbase.view.component.PaginatedExecution;
import br.com.bicbanco.bicbase.view.component.PaginatingDataModel;
import br.com.bicbanco.bicbase.view.controller.BaseController;
import br.com.bicbanco.ctt.exceptions.ProdutoClienteContaException;
import br.com.bicbanco.pou.service.InformacoesContaService;
import br.com.bicbanco.pou.to.InformacoesContaTO;

/**
 * @jsf.bean name="coTitularController" scope="request"
 * 
 * @jsf.navigation from="*" result="ContasPoupancaFilterList" to="/pages/coTitular/pesquisaContasPoupancaFilterList.xhtml"
 * 
 * @jsf.navigation from="*" result="ContaPoupancaDetail" to="/pages/coTitular/contaPoupancaDetail.xhtml"
 * 
 * @jsf.navigation from="*" result="CoTitularPoupancaDetail" to="/pages/coTitular/coTitularPoupancaDetail.xhtml"
 * 
 */
@KeepAlive   
public class CoTitularController extends BaseController {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4118987134375462226L;
	private static final Logger logger = Logger.getLogger(CoTitularController.class);
	private Integer sucTitular;
	private PaginatingDataModel<InformacoesContaTO, InformacoesContaService> scrollableTable;
	private InformacoesContaTO contaSelecionada;
	private Boolean isInclusao;
	private Integer totalLinhas = new Integer(7);
	
	public String init(){
		sucTitular = null;
		contaSelecionada = null;
		scrollableTable = null;		
		return "ContasPoupancaFilterList";
	}
	
	public String applyFilterList() throws ServiceException{
		InformacoesContaService informacoesContaService = getBean(InformacoesContaService.class);
		if(sucTitular == null){
			addErrorMessage("erro.campo.suc.titular.e.obrigatorio");
		}else{
			String nomePessoa = informacoesContaService.getNomePessoa(sucTitular);
			if(nomePessoa == null){
				addErrorMessage("erro.suc.nao.encontrado");
			}else{
				setPaginatingDataModel();
			}
		}
		return "ContasPoupancaFilterList";
	}
	
	private void setPaginatingDataModel(){
		scrollableTable = new PaginatingDataModel<InformacoesContaTO, InformacoesContaService>();
		scrollableTable.setPaginatedExecution(new PaginatedExecution() {
			public List<InformacoesContaTO> execute(Integer from, Integer to, String orderBy) {
				List<InformacoesContaTO> result = null;
				InformacoesContaService informacoesContaService = getBean(InformacoesContaService.class);
				try {
					result = informacoesContaService.listInformacoesConta(sucTitular);
				} catch (ServiceException e){
					logger.error(e.getMessage(), e);
					addErrorMessage(e.getMessage());
				} 
				return result;
			}
		});
	}
	
	public String returnToFilterList(){
		return "ContasPoupancaFilterList";
	}
	
	public String viewDetail() throws ServiceException{
		contaSelecionada = (InformacoesContaTO) this.scrollableTable.getRowData();
		return returnToConta();
	}
	
	public String returnToConta() throws ServiceException{
		InformacoesContaService informacoesContaService = getBean(InformacoesContaService.class);
		contaSelecionada = informacoesContaService.getInformacoesConta(contaSelecionada.getCodOrgao(), contaSelecionada.getSucTitular(), contaSelecionada.getNumConta());
		if(contaSelecionada.getSucCoTitular() == null){
			isInclusao = Boolean.TRUE;
		}else{
			isInclusao = Boolean.FALSE;
		}
		return "ContaPoupancaDetail";
	}
	
	public String visualizarCoTitular(){
		return "CoTitularPoupancaDetail";
	}
	
	public String update() throws ServiceException{
		InformacoesContaService informacoesContaService = getBean(InformacoesContaService.class);
		if(contaSelecionada.getSucCoTitular() == null ){
			addErrorMessage("erro.campo.suc.co.titular.e.obrigatorio");
			return "CoTitularPoupancaDetail";
		}else if(contaSelecionada.getSucCoTitular().equals(contaSelecionada.getSucTitular())){
			addErrorMessage("erro.suc.titular.igual.suc.coTitular");
			return "CoTitularPoupancaDetail";
		}else if(contaSelecionada.getSucCoTitular().equals(contaSelecionada.getSucCoTitularAnterior())){
			addErrorMessage("erro.suc.cotitular.igual.suc.coTitularAnterior");
			return "CoTitularPoupancaDetail";
		}
		try {
			String nomePessoa = informacoesContaService.getNomePessoa(contaSelecionada.getSucCoTitular());
			if(nomePessoa == null){
				addErrorMessage("erro.suc.nao.encontrado");
				return "CoTitularPoupancaDetail";
			}
			if(isInclusao){
				informacoesContaService.insertCoTitular(contaSelecionada);
				addInfoMessage("insert_ok");
			}else{
				informacoesContaService.updateCoTitular(contaSelecionada);
				addInfoMessage("update_ok");
			}
		} catch (ProdutoClienteContaException e) {
			addErrorMessage(e.getMessageKey());
		} 
		return returnToConta();
	}
	
	public String delete() throws ServiceException{
		InformacoesContaService informacoesContaService = getBean(InformacoesContaService.class);
		try {
			informacoesContaService.deleteCoTitular(contaSelecionada);
			addInfoMessage("delete_ok");
		} catch (ProdutoClienteContaException e) {
			addErrorMessage(e.getMessageKey());
		} 
		return returnToConta();
	}
	
	@Override
	public String getBundleName() {
		return "CoTitular";
	}

	public void setSucTitular(Integer sucTitular) {
		this.sucTitular = sucTitular;
	}

	public Integer getSucTitular() {
		return sucTitular;
	}

	public InformacoesContaTO getContaSelecionada() {
		return contaSelecionada;
	}

	public PaginatingDataModel<InformacoesContaTO, InformacoesContaService> getScrollableTable() {
		return scrollableTable;
	}
	
	public Integer getTotalLinhas(){
		return totalLinhas;
	}

	public void setTotalLinhas(Integer totalLinhas) {
		this.totalLinhas = totalLinhas;
	}
}
