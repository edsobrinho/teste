function setHighlight(ids) {
	var idsArray = ids.split(",");
	for (var i = 0; i < idsArray.length; i++) {
		var elementDateName = idsArray[i].indexOf("date");
		var elementDataName = idsArray[i].indexOf("data");
		if (elementDateName != -1 || elementDataName != -1) {
			setInputClass(document.getElementById(idsArray[i] + 'InputDate'));
			continue;
		}
		setInputClass(document.getElementById(idsArray[i]));
	}
}

function setInputClass(element) {
	if (element) {
		jQuery(element).addClass(" inputInvalid");
	}
}
