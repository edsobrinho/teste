function autoSkip(prior, next) {
    if (prior && prior.value.length >= prior.maxLength) {
        el = document.getElementById(next);
        if (el) {
            el.focus();
        }
    }
}

function upper(theElement){
	theElement.value = theElement.value.toUpperCase();
}

function padDigits(obj) {
	var newValue = "";
   	if (obj && obj.value.length > 0 && obj.value.length < obj.maxLength) {
		for (var i = obj.value.length; i < obj.maxLength;i++) { 
			newValue = newValue + "0";	
		}
	}
   	newValue = newValue + obj.value;
   	obj.value = newValue;
}

function textCounter(field, cntfield, maxlimit) {
	if (field.value.length > maxlimit) { 
		field.value = field.value.substring(0, maxlimit);
	} else {
		cntfield.value = maxlimit - field.value.length;
	}
}

function somenteNumero(e){
	var tecla=(window.event)?event.keyCode:e.which;   
	if((tecla>47 && tecla<58)) return true;
	else{
		if (tecla==8 || tecla==0) return true;
		else  return false;
	}
}	