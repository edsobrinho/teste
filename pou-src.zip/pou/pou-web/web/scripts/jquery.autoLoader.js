﻿jQuery(function($) {
	$('input.auto').autoNumeric();
	// please see the following pages:
	// (http://www.decorplanit.com/plugin/autoLoaderFunction.htm) information on the starting autoNumeric() and loading values
	// (http://www.decorplanit.com/plugin/specialCharacters.htm) information id's with special characters
});